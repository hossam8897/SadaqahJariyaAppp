/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  BookOpen, 
  Award, 
  Heart, 
  HelpCircle, 
  Sparkles, 
  ArrowRight,
  Bookmark,
  Share2,
  Copy,
  VolumeX,
  Volume2
} from 'lucide-react';
import { azkarData, duasData, hadithsData, staticReminders } from '../data/islamicData';
import { surahsList } from '../data/surahList';
import { copyToClipboard } from '../utils/helpers';

interface HeroProps {
  darkMode: boolean;
  setTab: (tab: string) => void;
  onSearchSelect: (type: string, id: any) => void;
}

export default function Hero({ darkMode, setTab, onSearchSelect }: HeroProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [copiedText, setCopiedText] = useState<string | null>(null);

  // Pick deterministic items based on the day of the month
  const dayIndex = new Date().getDate();

  // Selected featured daily verses
  const dailyVerses = [
    { text: "اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ", reference: "سورة البقرة - الآية ٢٥٥ (آية الكرسي)" },
    { text: "إِنَّ الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ كَانَتْ لَهُمْ جَنَّاتُ الْفِرْدَوْسِ نُزُلًا", reference: "سورة الكهف - الآية ١٠٧" },
    { text: "وَبَشِّرِ الصَّابِرِينَ * الَّذِينَ إِذَا أَصَابَتْهُم مُّصِيبَةٌ قَالُواْ إِنَّا لِلَّهِ وَإِنَّا إِلَيْهِ رَاجِعُونَ", reference: "سورة البقرة - الآية ١٥٥-١٥٦" },
    { text: "ادْعُوا رَبَّكُمْ تَضَرُّعًا وَخُفْيَةً ۚ إِنَّهُ لَا يُحِبُّ الْمُعْتَدِينَ", reference: "سورة الأعراف - الآية ٥٥" }
  ];

  const dailyVerse = dailyVerses[dayIndex % dailyVerses.length];
  const dailyHadith = hadithsData[dayIndex % hadithsData.length];
  const dailyDua = duasData[dayIndex % duasData.length];
  const dailyReminder = staticReminders[dayIndex % staticReminders.length];

  // Search across Surah names, Azkar, Duas, and Hadiths
  const handleSearch = (q: string) => {
    setSearchQuery(q);
    if (!q.trim()) {
      setSearchResults([]);
      return;
    }

    const results: any[] = [];

    // 1. Search Surah names
    surahsList.forEach(s => {
      if (s.name.includes(q) || s.englishName.toLowerCase().includes(q.toLowerCase())) {
        results.push({ type: 'quran', title: `سورة ${s.name}`, subtitle: `عدد آياتها: ${s.numberOfAyahs} - ${s.revelationType === 'Meccan' ? 'مكية' : 'مدنية'}`, id: s.number });
      }
    });

    // 2. Search Azkar
    azkarData.forEach(a => {
      if (a.text.includes(q)) {
        const categoryMap: any = { morning: 'أذكار الصباح', evening: 'أذكار المساء', sleep: 'أذكار النوم', prayer: 'أذكار الصلاة' };
        results.push({ type: 'azkar', title: a.text.substring(0, 60) + '...', subtitle: categoryMap[a.category] || 'أذكار', id: a.id });
      }
    });

    // 3. Search Duas
    duasData.forEach(d => {
      if (d.text.includes(q) || d.title.includes(q)) {
        results.push({ type: 'duas', title: d.title, subtitle: `دعاء: ${d.text.substring(0, 40)}...`, id: d.id });
      }
    });

    // 4. Search Hadiths
    hadithsData.forEach(h => {
      if (h.text.includes(q) || h.category.includes(q)) {
        results.push({ type: 'hadith', title: h.category, subtitle: h.text.substring(0, 50) + '...', id: h.id });
      }
    });

    setSearchResults(results.slice(0, 6)); // limit to top 6 results
  };

  const triggerCopy = (text: string, label: string) => {
    copyToClipboard(text).then(() => {
      setCopiedText(label);
      setTimeout(() => setCopiedText(null), 2000);
    });
  };

  return (
    <div className="relative islamic-pattern overflow-hidden py-12 md:py-20 px-4 sm:px-6 lg:px-8">
      {/* Decorative Golden Ornaments in background */}
      <div className="absolute top-10 left-10 w-48 h-48 rounded-full border border-yellow-500/10 pointer-events-none flex items-center justify-center animate-spin" style={{ animationDuration: '60s' }}>
        <div className="w-40 h-40 border border-dashed border-yellow-500/10 rounded-full" />
      </div>
      <div className="absolute bottom-10 right-10 w-48 h-48 rounded-full border border-yellow-500/10 pointer-events-none flex items-center justify-center animate-spin" style={{ animationDuration: '45s' }}>
        <div className="w-40 h-40 border border-dashed border-yellow-500/10 rounded-full" />
      </div>

      <div className="max-w-4xl mx-auto text-center relative z-10">
        
        {/* Memorial Header Shield */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[#D4AF37]/30 bg-emerald-500/10 text-[#D4AF37] mb-6 text-sm font-semibold backdrop-blur-sm"
        >
          <Sparkles className="w-4 h-4 text-[#D4AF37]" />
          <span>صدقة جارية مستمرة - تقبله الله في الصالحين</span>
        </motion.div>

        {/* Main Website Heading */}
        <motion.h1 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="font-quran text-3xl sm:text-4xl md:text-5xl font-extrabold text-[#D4AF37] tracking-tight leading-normal"
        >
          صدقة جارية على روح عبدالناصر عمران
        </motion.h1>

        {/* The Beautiful Sacred Memorial Dua */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className={`mt-6 p-6 sm:p-8 rounded-2xl border ${
            darkMode 
              ? 'glass-dark bg-emerald-950/20 border-[#D4AF37]/20 text-emerald-100' 
              : 'glass-light bg-emerald-50/50 border-emerald-100 text-emerald-950'
          } relative overflow-hidden`}
        >
          <div className="absolute top-0 right-0 p-4 font-quran text-4xl opacity-5 text-[#D4AF37]">﷽</div>
          <p className="font-quran text-lg sm:text-xl md:text-2xl leading-relaxed font-semibold italic text-center max-w-3xl mx-auto">
            "اللهم اغفر لعبدالناصر عمران وارحمه، وعافه واعف عنه، وأكرم نزله، ووسع مدخله، واجعل قبره روضة من رياض الجنة."
          </p>
          <div className="mt-4 flex justify-center gap-4">
            <button
              onClick={() => triggerCopy("اللهم اغفر لعبدالناصر عمران وارحمه، وعافه واعف عنه، وأكرم نزله، ووسع مدخله، واجعل قبره روضة من رياض الجنة.", 'dua')}
              className="px-3 py-1.5 rounded-lg text-xs font-semibold border border-[#D4AF37]/30 text-[#D4AF37] hover:bg-[#D4AF37]/10 transition-all duration-200 flex items-center gap-1.5 cursor-pointer"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>{copiedText === 'dua' ? 'تم النسخ' : 'نسخ الدعاء'}</span>
            </button>
            <button
              onClick={() => {
                setTab('memorial');
              }}
              className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white transition-all duration-200 flex items-center gap-1.5 cursor-pointer"
            >
              <span>أضف دعاء لفقيدنا</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </motion.div>

        {/* Unified Search Engine */}
        <div className="mt-8 relative max-w-xl mx-auto">
          <div className="relative">
            <input
              type="text"
              placeholder="ابحث عن سور، أذكار، أدعية، أو أحاديث نبوية..."
              value={searchQuery}
              onChange={(e) => handleSearch(e.target.value)}
              className={`w-full py-4 pr-12 pl-4 rounded-xl border text-base focus:outline-none focus:ring-2 transition-all duration-200 text-right ${
                darkMode 
                  ? 'bg-emerald-950/40 border-[#D4AF37]/30 text-white placeholder-emerald-300/40 focus:ring-[#D4AF37]/50 focus:border-[#D4AF37]' 
                  : 'bg-white border-emerald-100 text-emerald-950 placeholder-emerald-950/40 focus:ring-emerald-500/50 focus:border-emerald-500'
              }`}
            />
            <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#D4AF37]" />
          </div>

          {/* Floating Search Results */}
          <AnimatePresence>
          {searchResults.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              className={`absolute top-full right-0 left-0 mt-2 rounded-xl border p-2 z-30 max-h-80 overflow-y-auto text-right ${
                darkMode 
                  ? 'bg-[#0a1510] border-[#D4AF37]/30 shadow-2xl' 
                  : 'bg-white border-emerald-100 shadow-xl'
              }`}
            >
              <div className="px-3 py-1.5 text-xs text-[#D4AF37] font-semibold border-b border-dashed border-[#D4AF37]/10 mb-1">نتائج البحث المستخرجة:</div>
              {searchResults.map((item, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    onSearchSelect(item.type, item.id);
                    setSearchQuery('');
                    setSearchResults([]);
                  }}
                  className={`w-full text-right px-3 py-2.5 rounded-lg flex flex-col gap-0.5 hover:bg-[#D4AF37]/10 cursor-pointer border-b border-transparent last:border-0 transition-colors duration-200`}
                >
                  <div className="flex justify-between items-center w-full">
                    <span className={`text-sm font-semibold ${darkMode ? 'text-white' : 'text-emerald-950'}`}>{item.title}</span>
                    <span className="text-[10px] bg-emerald-500/10 text-[#D4AF37] px-2 py-0.5 rounded-full border border-[#D4AF37]/20 font-medium">{item.subtitle}</span>
                  </div>
                </button>
              ))}
            </motion.div>
          )}
          </AnimatePresence>
        </div>

        {/* Daily Spiritual Board (Bento style grid of Daily Verse, Hadith, Dua, and Reminder) */}
        <div className="mt-14 grid grid-cols-1 md:grid-cols-2 gap-6 text-right">
          
          {/* Daily Verse */}
          <motion.div
            whileHover={{ y: -4 }}
            className={`p-6 rounded-2xl border text-right relative overflow-hidden flex flex-col justify-between ${
              darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950'
            }`}
          >
            <div className="absolute top-2 left-2 px-2.5 py-0.5 rounded-full text-[10px] bg-emerald-500/10 border border-[#D4AF37]/20 text-[#D4AF37] font-semibold font-mono">الورد اليومي</div>
            <div>
              <h3 className="text-sm font-bold text-[#D4AF37] mb-3 flex items-center gap-1.5">
                <BookOpen className="w-4 h-4 text-[#D4AF37]" />
                <span>آية قرآنية مختارة</span>
              </h3>
              <p className="font-quran text-lg leading-relaxed text-emerald-800 dark:text-emerald-100 font-semibold italic">
                {dailyVerse.text}
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-dashed border-[#D4AF37]/10 flex items-center justify-between">
              <span className="text-xs text-gray-400 font-medium">{dailyVerse.reference}</span>
              <button
                onClick={() => triggerCopy(`قال الله تعالى: ${dailyVerse.text} [${dailyVerse.reference}]`, 'verse')}
                className="p-1.5 rounded-lg hover:bg-emerald-500/10 text-[#D4AF37] transition-all cursor-pointer"
                title="نسخ الآية"
              >
                <Copy className="w-4 h-4" />
              </button>
            </div>
          </motion.div>

          {/* Daily Hadith */}
          <motion.div
            whileHover={{ y: -4 }}
            className={`p-6 rounded-2xl border text-right relative overflow-hidden flex flex-col justify-between ${
              darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950'
            }`}
          >
            <div className="absolute top-2 left-2 px-2.5 py-0.5 rounded-full text-[10px] bg-emerald-500/10 border border-[#D4AF37]/20 text-[#D4AF37] font-semibold font-mono">الحديث الشريف</div>
            <div>
              <h3 className="text-sm font-bold text-[#D4AF37] mb-3 flex items-center gap-1.5">
                <Award className="w-4 h-4 text-[#D4AF37]" />
                <span>الحديث اليومي</span>
              </h3>
              <p className="font-sans text-sm leading-relaxed text-emerald-800 dark:text-gray-200">
                "{dailyHadith.text}"
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-dashed border-[#D4AF37]/10 flex items-center justify-between">
              <span className="text-xs text-gray-400 font-medium">رواه: {dailyHadith.narrator} | {dailyHadith.source}</span>
              <button
                onClick={() => triggerCopy(`عن ${dailyHadith.narrator} قال: قال رسول الله ﷺ: "${dailyHadith.text}" [${dailyHadith.source}]`, 'hadith')}
                className="p-1.5 rounded-lg hover:bg-emerald-500/10 text-[#D4AF37] transition-all cursor-pointer"
                title="نسخ الحديث"
              >
                <Copy className="w-4 h-4" />
              </button>
            </div>
          </motion.div>

          {/* Daily Dua */}
          <motion.div
            whileHover={{ y: -4 }}
            className={`p-6 rounded-2xl border text-right relative overflow-hidden flex flex-col justify-between ${
              darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950'
            }`}
          >
            <div className="absolute top-2 left-2 px-2.5 py-0.5 rounded-full text-[10px] bg-emerald-500/10 border border-[#D4AF37]/20 text-[#D4AF37] font-semibold font-mono">الدعاء اليومي</div>
            <div>
              <h3 className="text-sm font-bold text-[#D4AF37] mb-3 flex items-center gap-1.5">
                <Heart className="w-4 h-4 text-[#D4AF37]" />
                <span>من أدعية القرآن والسنة</span>
              </h3>
              <p className="font-quran text-base leading-relaxed text-emerald-800 dark:text-emerald-100 font-medium">
                "{dailyDua.text}"
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-dashed border-[#D4AF37]/10 flex items-center justify-between">
              <span className="text-xs text-gray-400 font-medium">{dailyDua.title}</span>
              <button
                onClick={() => triggerCopy(`دعاء: "${dailyDua.text}" [${dailyDua.source || ''}]`, 'ddua')}
                className="p-1.5 rounded-lg hover:bg-emerald-500/10 text-[#D4AF37] transition-all cursor-pointer"
                title="نسخ الدعاء"
              >
                <Copy className="w-4 h-4" />
              </button>
            </div>
          </motion.div>

          {/* Daily Reminder */}
          <motion.div
            whileHover={{ y: -4 }}
            className={`p-6 rounded-2xl border text-right relative overflow-hidden flex flex-col justify-between ${
              darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950'
            }`}
          >
            <div className="absolute top-2 left-2 px-2.5 py-0.5 rounded-full text-[10px] bg-emerald-500/10 border border-[#D4AF37]/20 text-[#D4AF37] font-semibold font-mono">التنبيهات</div>
            <div>
              <h3 className="text-sm font-bold text-[#D4AF37] mb-3 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-[#D4AF37]" />
                <span>تذكرة إسلامية اليوم</span>
              </h3>
              <p className="font-sans text-sm leading-relaxed text-emerald-800 dark:text-emerald-100 font-medium">
                {dailyReminder}
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-dashed border-[#D4AF37]/10 flex items-center justify-between">
              <span className="text-xs text-gray-400 font-medium">صدقة جارية مستمرة</span>
              <button
                onClick={() => setTab('azkar')}
                className="text-xs font-semibold text-[#D4AF37] hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span>الذهاب للأذكار</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </motion.div>

        </div>

        {/* Featured Section Shortcuts */}
        <div className="mt-14 pt-8 border-t border-dashed border-[#D4AF37]/20">
          <h2 className={`text-lg font-bold mb-6 ${darkMode ? 'text-[#D4AF37]' : 'text-emerald-950'}`}>أبرز أقسام الصدقة الجارية</h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              { id: 'quran', title: 'القرآن الكريم', desc: 'تلاوة، تفسير واستماع', icon: BookOpen },
              { id: 'azkar', title: 'الأذكار اليومية', desc: 'حصن المسلم المتكامل', icon: Award },
              { id: 'duas', title: 'الأدعية والمناجاة', desc: 'أدعية للمتوفى والمأثور', icon: Heart },
              { id: 'memorial', title: 'صفحة الفقيد 🕯️', desc: 'لوحة الدعاء والختمات', icon: Sparkles },
            ].map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => setTab(item.id)}
                  className={`p-4 rounded-xl border transition-all duration-300 text-right cursor-pointer flex flex-col justify-between group h-28 ${
                    darkMode 
                      ? 'bg-white/5 border-white/10 hover:bg-white/10 backdrop-blur-sm' 
                      : 'bg-white/60 border-emerald-100 hover:bg-white/90 shadow-sm backdrop-blur-sm'
                  }`}
                >
                  <Icon className="w-6 h-6 text-[#D4AF37] group-hover:scale-110 transition-transform duration-300" />
                  <div>
                    <div className={`text-sm font-bold ${darkMode ? 'text-white' : 'text-emerald-950'}`}>{item.title}</div>
                    <div className="text-[10px] text-gray-400 mt-0.5">{item.desc}</div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

      </div>
    </div>
  );
}
