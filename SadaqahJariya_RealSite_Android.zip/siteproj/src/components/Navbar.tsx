/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BookOpen, 
  Moon, 
  Sun, 
  Menu, 
  X, 
  Clock, 
  Heart, 
  Award, 
  Compass, 
  Tv, 
  FileText,
  User,
  Volume2,
  Calendar,
  Lock
} from 'lucide-react';

interface NavbarProps {
  currentTab: string;
  setTab: (tab: string) => void;
  darkMode: boolean;
  setDarkMode: (dark: boolean) => void;
  stats: { tasbeehCount: number; quranReadCount: number };
}

export default function Navbar({ currentTab, setTab, darkMode, setDarkMode, stats }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { id: 'home', label: 'الرئيسية', icon: BookOpen },
    { id: 'quran', label: 'القرآن الكريم', icon: BookOpen },
    { id: 'azkar', label: 'الأذكار', icon: Award },
    { id: 'duas', label: 'الأدعية', icon: Heart },
    { id: 'tasbeeh', label: 'السبحة', icon: Award },
    { id: 'prayer', label: 'المواقيت والقبلة', icon: Clock },
    { id: 'hadith', label: 'الأحاديث والأسماء', icon: Compass },
    { id: 'stories', label: 'القصص والسيرة', icon: FileText },
    { id: 'audio', label: 'الصوتيات', icon: Volume2 },
    { id: 'live', label: 'البث المباشر', icon: Tv },
    { id: 'memorial', label: 'عبدالناصر عمران 🕯️', icon: User },
    { id: 'admin', label: 'الإدارة', icon: Lock },
  ];

  return (
    <header className={`sticky top-0 z-50 w-full transition-all duration-300 border-b ${
      darkMode 
        ? 'bg-[#040c08]/85 border-[#D4AF37]/10 backdrop-blur-md text-white' 
        : 'bg-[#faf8f4]/85 border-[#D4AF37]/15 backdrop-blur-md text-emerald-950'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Brand Logo and Memorial Header */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setTab('home')}>
            <div className="relative flex items-center justify-center w-12 h-12 rounded-full border border-[#D4AF37]/30 bg-emerald-500/10">
              <span className="font-quran text-xl font-bold text-[#D4AF37]">ع</span>
              <span className="absolute -top-1 -right-1 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-[#D4AF37]"></span>
              </span>
            </div>
            <div>
              <h1 className="font-sans font-bold text-base sm:text-lg text-[#D4AF37] leading-tight tracking-tight">
                صدقة جارية
              </h1>
              <p className={`text-xs ${darkMode ? 'text-emerald-300/80' : 'text-emerald-700/80'} font-medium`}>
                على روح عبدالناصر عمران
              </p>
            </div>
          </div>

          {/* Desktop Navigation (Scrollable list if it exceeds width, with beautiful gold indicators) */}
          <nav className="hidden xl:flex items-center gap-1 overflow-x-auto py-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setTab(item.id)}
                  className={`relative px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                    isActive 
                      ? 'text-[#D4AF37]' 
                      : darkMode ? 'text-gray-300 hover:text-white hover:bg-emerald-950/40' : 'text-emerald-900 hover:text-emerald-700 hover:bg-emerald-50'
                  }`}
                  id={`nav-tab-${item.id}`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                  {isActive && (
                    <motion.div 
                      layoutId="activeNavIndicator"
                      className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-[#D4AF37] to-transparent"
                    />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Secondary Actions (Dark Mode, Statistics Quick View, Mobile Menu toggle) */}
          <div className="flex items-center gap-3">
            {/* Quick stats badges for desktop */}
            <div className="hidden md:flex items-center gap-2 text-xs font-mono">
              <div className={`px-2.5 py-1.5 rounded-full border flex items-center gap-1 ${
                darkMode ? 'bg-[#0f241a] border-[#D4AF37]/20 text-[#D4AF37]' : 'bg-emerald-50 border-emerald-100 text-emerald-800'
              }`}>
                <span>📿 السبحة:</span>
                <span className="font-bold">{stats.tasbeehCount}</span>
              </div>
              <div className={`px-2.5 py-1.5 rounded-full border flex items-center gap-1 ${
                darkMode ? 'bg-[#0f241a] border-[#D4AF37]/20 text-[#D4AF37]' : 'bg-emerald-50 border-emerald-100 text-emerald-800'
              }`}>
                <span>📖 التلاوة:</span>
                <span className="font-bold">{stats.quranReadCount}</span>
              </div>
            </div>

            {/* Dark Mode toggle button */}
            <button
              onClick={() => setDarkMode(!darkMode)}
              className={`p-2.5 rounded-full transition-all duration-200 cursor-pointer ${
                darkMode ? 'bg-[#0f241a] hover:bg-emerald-900/30 text-[#D4AF37]' : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-800'
              }`}
              title={darkMode ? "تبديل المظهر المضيء" : "تبديل المظهر الداكن"}
              id="theme-toggle-btn"
            >
              {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>

            {/* Mobile Menu button */}
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="xl:hidden p-2.5 rounded-full hover:bg-emerald-500/10 text-emerald-500 cursor-pointer"
              id="mobile-menu-toggle-btn"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Sidebar Navigation Drawer */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className={`xl:hidden overflow-hidden border-t ${
              darkMode ? 'bg-[#06241a]/90 backdrop-blur-xl border-white/10' : 'bg-white/90 backdrop-blur-xl border-emerald-100'
            }`}
          >
            <div className="px-4 pt-3 pb-6 space-y-1.5">
              {/* Quick stats for mobile */}
              <div className="grid grid-cols-2 gap-2 pb-3 mb-3 border-b border-dashed border-[#D4AF37]/10">
                <div className={`p-2.5 rounded-lg text-center ${darkMode ? 'bg-[#0f241a]' : 'bg-white'} border border-[#D4AF37]/10`}>
                  <div className="text-[10px] text-gray-400">التسبيحات اليومية</div>
                  <div className="text-sm font-bold text-[#D4AF37] font-mono">{stats.tasbeehCount}</div>
                </div>
                <div className={`p-2.5 rounded-lg text-center ${darkMode ? 'bg-[#0f241a]' : 'bg-white'} border border-[#D4AF37]/10`}>
                  <div className="text-[10px] text-gray-400">الصفحات والآيات</div>
                  <div className="text-sm font-bold text-[#D4AF37] font-mono">{stats.quranReadCount}</div>
                </div>
              </div>

              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = currentTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setTab(item.id);
                      setIsOpen(false);
                    }}
                    className={`w-full text-right px-4 py-3 rounded-xl text-base font-medium transition-all duration-200 flex items-center gap-3 cursor-pointer ${
                      isActive 
                        ? 'bg-gradient-to-l from-emerald-900/10 to-[#D4AF37]/10 text-[#D4AF37] border-r-4 border-r-[#D4AF37]' 
                        : darkMode ? 'text-gray-300 hover:bg-[#0f241a]' : 'text-emerald-950 hover:bg-emerald-100/50'
                    }`}
                  >
                    <Icon className="w-5 h-5 text-[#D4AF37]" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
