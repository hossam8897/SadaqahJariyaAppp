/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  FileText, 
  Search, 
  Award, 
  Sparkles, 
  ChevronRight, 
  Compass, 
  Heart, 
  Check, 
  Copy,
  BookOpen,
  Calendar,
  Clock,
  Info
} from 'lucide-react';
import { storiesData as baseStories, seerahMilestones } from '../data/islamicData';
import { copyToClipboard } from '../utils/helpers';
import { getStories, getArticles } from '../utils/firebase';

// Additional children stories to make it 100% complete
const childrenStories = [
  {
    id: 's_child1',
    category: 'children',
    title: 'قصة الغراب وأمانة عصفور التين',
    text: 'كان هناك عصفور صغير يبني عشه بجد وتفاني ويجمع القش الحلال لإطعام صغاره، وكان بجواره غراب يكسل ويهزأ به. وفي يوم ممطر، انهار عش الغراب لضعفه، فما كان من العصفور الطيب إلا أن فتح بيته للغراب وأولاده وعلمه كيف يبني بيتاً قوياً ومباركاً بالجد والأمانة وعدم الطمع.',
    moral: 'التعاون المبارك والأمانة والجد، ومساعدة المحتاجين تطرح البركة في الرزق والعمل.'
  }
];

const allStories = [...baseStories, ...childrenStories];

// High-quality, organized Islamic articles
const articlesData = [
  {
    id: 'art1',
    title: 'أثر الصدقة الجارية في تبريد قبور الموتى ونيل رضوان الله',
    author: 'لجنة النشر والوعظ العلمي',
    date: '٢٠٢٦م / ١٤٤٧هـ',
    readTime: '٤ دقائق',
    text: `الصدقة الجارية هي من أعظم أبواب القربات التي يتقرب بها العبد إلى ربه، وهي الوقف المستمر الذي لا ينقطع ثوابه بموت الواقف أو المهدى إليه، بل يستمر ثوابه يجري في صحيفته يوماً بعد يوم، وعاماً بعد عام.

وقد ثبت في الحديث الصحيح عن النبي ﷺ أنه قال: "إذا مات ابن آدم انقطع عمله إلا من ثلاث: صدقة جارية، أو علم ينتفع به، أو ولد صالح يدعو له".

ومن عظيم أثر الصدقة الجارية:
١. تبريد القبور وإضاءتها: فإن الصدقة تطفئ غضب الرب، وتكون ظلاً ظليلاً للمتوفى في قبره ويوم القيامة، كما قال ﷺ: "إن الصدقة لتطفئ عن أهلها حر القبور، وإنما يستظل المؤمن يوم القيامة في ظل صدقته".
٢. تفريج الكربات وتيسير الأمور: فهي تجلب البركة في الرزق للواقف الحي، وتثقل ميزان الحسنات للميت في الآخرة.
٣. وسيلة للتكافل والتراحم الاجتماعي: مثل بناء آبار المياه، وتشييد دور العلم، وبناء المواقع الإلكترونية النافعة التي تبث العلم والأدعية والأذكار، لتقريب الناس من ربهم وتيسير الطاعات لهم.`
  },
  {
    id: 'art2',
    title: 'بر الوالدين بعد الوفاة: كيف نكون أبناء بررة بعد رحيلهما؟',
    author: 'الشيخ عبدالرحمن القاسمي',
    date: '٢٠٢٦م / ١٤٤٧هـ',
    readTime: '٥ دقائق',
    text: `بر الوالدين فريضة إلهية عظيمة ممتدة، لا تنتهي بانتهاء حياتهما في هذه الدنيا، بل إن البر الحقيقي والاختبار الأصدق لمعدن الأبناء يبدأ بعد وفاة الوالدين أو أحدهما، لكونه برّاً خالصاً خالياً من الرياء أو الخوف، موجهاً لوجه الله تعالى فقط.

وقد سأل رجل النبي ﷺ فقال: "يا رسول الله، هل بقي من بر أبوي شيء أبرهما به بعد موتهما؟" فقال ﷺ: "نعم، الصلاة عليهما، والاستغفار لهما، وإنفاذ عهدهما من بعدهما، وصلة الرحم التي لا توصل إلا بهما، وإكرام صديقهما".

أبرز صور البر بالوالدين بعد مماتهما:
١. كثرة الدعاء والاستغفار لهما: وهو أعظم ما يرتفع به درجات الميت في الجنة، كما جاء في الحديث: "إن الرجل لترفع درجته في الجنة فيقول: أنى هذا؟ فيقال: باستغفار ولدك لك".
٢. الصدقة الجارية على روحهما: كسقاية الماء، وتوزيع المصاحف، وبث العلم والخير.
٣. صلة أرحامهما وإكرام أصدقائهما: فإن النبي ﷺ كان يكرم صواحب السيدة خديجة بعد وفاتها وفاءً لها، وهو من كمال البر بالوالدين صلة عماتك وخالاتك وأعمامك وأخوالك.`
  },
  {
    id: 'art3',
    title: 'منهج القرآن الكريم في تربية النفوس وتزكيتها وبث الطمأنينة',
    author: 'د. محمد بن صالح الدوسري',
    date: '٢٠٢٦م / ١٤٤٧هـ',
    readTime: '٦ دقائق',
    text: `تعتبر تزكية النفس وتربيتها على الأخلاق الفاضلة والفضائل الإيمانية هي الغاية الأسمى للرسالات الإلهية، وقد جعل الله تبارك وتعالى فلاح العبد معلقاً بمدى تزكيته لنفسه وتطهيرها من الدنس والآثام، فقال عز وجل في سورة الشمس: "قَدْ أَفْلَحَ مَن زَكَّاهَا * وَقَدْ خَابَ مَن دَسَّاهَا".

من معالم المنهج القرآني في التزكية:
١. التوحيد الخالص وتعظيم الله: فعندما يستشعر القلب عظمة الخالق وعلمه المحيط بكل صغيرة وكبيرة، ينبعث فيه الخوف والرجاء والمحبة الصادقة.
٢. تدبر آيات القرآن وملازمته: فإن القرآن شفاء لما في الصدور من الشكوك والأحزان والأمراض، وقراءته تضفي طمأنينة وسكينة فريدة على النفس والروح.
٣. مجاهدة الهوى والشيطان: بالاستغفار الدائم والمحافظة على الصلاة في أوقاتها، ومصاحبة الأخيار والابتعاد عن مواطن الفتن والشبهات.`
  }
];

export default function IslamicStories({ darkMode }: { darkMode: boolean }) {
  const [stories, setStories] = useState<any[]>(allStories);
  const [articles, setArticles] = useState<any[]>(articlesData);
  const [activeTab, setActiveTab] = useState<'stories' | 'seerah' | 'articles'>('stories');
  const [selectedCategory, setSelectedCategory] = useState<string>('prophets');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStory, setSelectedStory] = useState<any | null>(null);
  const [selectedArticle, setSelectedArticle] = useState<any | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    getStories().then(data => {
      if (data && data.length > 0) {
        setStories(data);
      }
    });
    getArticles().then(data => {
      if (data && data.length > 0) {
        setArticles(data);
      }
    });
  }, []);

  const categories = [
    { id: 'prophets', label: '🕌 قصص الأنبياء عليهم السلام' },
    { id: 'companions', label: '⚔️ قصص الصحابة رضي الله عنهم' },
    { id: 'lessons', label: '📖 عبر ومواقف إسلامية' },
    { id: 'children', label: '🌱 قصص الأطفال الهادفة' }
  ];

  const triggerCopyStory = (story: any) => {
    const text = `قصة: { ${story.title} }\n\n${story.text}\n\nالعبرة المستفادة: ${story.moral || 'التقوى والعمل الصالح'}`;
    copyToClipboard(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const triggerCopyArticle = (art: any) => {
    const text = `مقالة: { ${art.title} }\nبقلم: ${art.author}\n\n${art.text}`;
    copyToClipboard(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const filteredStories = stories.filter(story => {
    const matchesCat = story.category === selectedCategory;
    const matchesSearch = story.title.includes(searchQuery) || story.text.includes(searchQuery);
    return matchesCat && matchesSearch;
  });

  const filteredArticles = articles.filter(art => {
    return art.title.includes(searchQuery) || art.text.includes(searchQuery) || art.author.includes(searchQuery);
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-right">
      
      {/* Selector tab */}
      <div className="flex justify-center mb-10">
        <div className={`p-1 rounded-xl border flex flex-wrap justify-center gap-1 ${
          darkMode ? 'bg-emerald-950/40 border-[#D4AF37]/20' : 'bg-slate-100 border-emerald-50'
        }`}>
          <button
            onClick={() => {
              setActiveTab('stories');
              setSearchQuery('');
            }}
            className={`px-6 py-2.5 rounded-lg text-sm font-bold transition-all cursor-pointer ${
              activeTab === 'stories'
                ? 'bg-gradient-to-r from-emerald-800 to-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/20'
                : darkMode ? 'text-gray-400 hover:text-white' : 'text-emerald-950 hover:text-emerald-800'
            }`}
          >
            القصص والعبر الإسلامية
          </button>
          <button
            onClick={() => {
              setActiveTab('seerah');
              setSearchQuery('');
            }}
            className={`px-6 py-2.5 rounded-lg text-sm font-bold transition-all cursor-pointer ${
              activeTab === 'seerah'
                ? 'bg-gradient-to-r from-emerald-800 to-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/20'
                : darkMode ? 'text-gray-400 hover:text-white' : 'text-emerald-950 hover:text-emerald-800'
            }`}
          >
            السيرة النبوية العطرة ﷺ
          </button>
          <button
            onClick={() => {
              setActiveTab('articles');
              setSearchQuery('');
              if (articlesData.length > 0 && !selectedArticle) {
                setSelectedArticle(articlesData[0]);
              }
            }}
            className={`px-6 py-2.5 rounded-lg text-sm font-bold transition-all cursor-pointer ${
              activeTab === 'articles'
                ? 'bg-gradient-to-r from-emerald-800 to-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/20'
                : darkMode ? 'text-gray-400 hover:text-white' : 'text-emerald-950 hover:text-emerald-800'
            }`}
          >
            المقالات الإسلامية المنظمة
          </button>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'stories' ? (
          /* Stories section */
          <motion.div
            key="stories-catalog"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="space-y-6"
          >
            {/* Toolbar: Category buttons & Search bar */}
            <div className="flex flex-col md:flex-row justify-between items-center gap-4 mb-6">
              {/* Search */}
              <div className="relative w-full md:max-w-md">
                <input
                  type="text"
                  placeholder="ابحث عن قصة أو عبرة معينة..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className={`w-full py-3 pr-12 pl-4 rounded-xl border focus:outline-none focus:ring-2 transition-all ${
                    darkMode 
                      ? 'bg-emerald-950/40 border-[#D4AF37]/20 text-white placeholder-emerald-300/40 focus:ring-[#D4AF37]/50' 
                      : 'bg-white border-emerald-100 text-emerald-950 focus:ring-emerald-500/50'
                  }`}
                />
                <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#D4AF37]" />
              </div>

              {/* Categories scrollbar */}
              <div className="flex gap-2 overflow-x-auto w-full md:w-auto pb-2 scrollbar-none">
                {categories.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => {
                      setSelectedCategory(cat.id);
                      setSelectedStory(null);
                      setSearchQuery('');
                    }}
                    className={`px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap cursor-pointer transition-all ${
                      selectedCategory === cat.id 
                        ? 'bg-emerald-500/15 border-[#D4AF37]/40 text-[#D4AF37]' 
                        : darkMode ? 'bg-emerald-950/20 text-gray-400' : 'bg-slate-100 text-emerald-950'
                    }`}
                  >
                    {cat.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Main Content Layout */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* Story directory list (Left side) */}
              <div className="lg:col-span-1 space-y-3 max-h-[500px] overflow-y-auto pr-1">
                {filteredStories.map((story) => {
                  const isSelected = selectedStory?.id === story.id;
                  return (
                    <button
                      key={story.id}
                      onClick={() => setSelectedStory(story)}
                      className={`w-full text-right p-4 rounded-xl border transition-all cursor-pointer flex items-center justify-between group ${
                        isSelected 
                          ? 'bg-[#D4AF37]/10 border-[#D4AF37] text-[#D4AF37]' 
                          : darkMode ? 'bg-emerald-950/20 border-transparent text-gray-300 hover:bg-[#09150f]' : 'bg-slate-50 border-transparent text-emerald-950 hover:bg-slate-100'
                      }`}
                    >
                      <div className="overflow-hidden">
                        <div className="text-sm font-bold truncate">{story.title}</div>
                        <div className="text-[10px] text-gray-400 mt-1 truncate">{story.text.substring(0, 50)}...</div>
                      </div>
                      <ChevronRight className="w-4 h-4 shrink-0 text-[#D4AF37] group-hover:translate-x-[-2px] transition-transform" />
                    </button>
                  );
                })}
                {filteredStories.length === 0 && (
                  <div className="text-center py-8 text-gray-400 text-xs">لا يوجد قصص مطابقة للبحث.</div>
                )}
              </div>

              {/* Story details viewport (Right side) */}
              <div className="lg:col-span-2">
                {selectedStory ? (
                  <motion.div
                    key={selectedStory.id}
                    initial={{ opacity: 0, x: 10 }}
                    animate={{ opacity: 1, x: 0 }}
                    className={`p-6 sm:p-8 rounded-2xl border text-right relative overflow-hidden ${
                      darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950'
                    }`}
                  >
                    <div className="absolute top-0 right-0 p-4 font-quran text-4xl opacity-[0.03] text-[#D4AF37]">﷽</div>
                    
                    <h3 className="font-quran text-2xl font-bold text-[#D4AF37] mb-4 border-b border-dashed border-[#D4AF37]/15 pb-2">
                      {selectedStory.title}
                    </h3>

                    <p className="font-sans text-base leading-relaxed text-emerald-950 dark:text-emerald-100 font-medium mb-6 whitespace-pre-line">
                      {selectedStory.text}
                    </p>

                    {selectedStory.moral && (
                      <div className="p-4 rounded-xl bg-amber-500/5 border border-[#D4AF37]/20 mb-6 text-xs text-gray-300 leading-relaxed">
                        <span className="font-bold text-[#D4AF37] block mb-1">💡 الدروس والعبر المستفادة من هذه السيرة:</span>
                        {selectedStory.moral}
                      </div>
                    )}

                    <div className="flex gap-3 justify-end pt-4 border-t border-[#D4AF37]/10">
                      <button
                        onClick={() => triggerCopyStory(selectedStory)}
                        className="px-4 py-2 border border-[#D4AF37]/20 text-[#D4AF37] rounded-lg text-xs font-bold hover:bg-[#D4AF37]/10 transition-colors flex items-center gap-1.5 cursor-pointer"
                      >
                        <Copy className="w-3.5 h-3.5" />
                        <span>{copied ? 'تم نسخ القصة كاملاً' : 'نسخ ومشاركة القصة'}</span>
                      </button>
                    </div>
                  </motion.div>
                ) : (
                  <div className={`p-8 rounded-2xl border text-center flex flex-col justify-center items-center min-h-60 ${
                    darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950'
                  }`}>
                    <BookOpen className="w-12 h-12 text-[#D4AF37] mb-3 animate-pulse" />
                    <h4 className="text-base font-bold text-gray-300 mb-1">اختر قصة من القائمة الجانبية</h4>
                    <p className="text-xs text-gray-500">تصفح العبر والدروس الإيمانية العظيمة للتثقيف والتعلم</p>
                  </div>
                )}
              </div>

            </div>
          </motion.div>
        ) : activeTab === 'seerah' ? (
          /* Seerah section (Beautiful Timeline) */
          <motion.div
            key="seerah-timeline"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="max-w-3xl mx-auto space-y-8 relative before:absolute before:top-4 before:bottom-4 before:right-6 before:w-0.5 before:bg-[#D4AF37]/30"
          >
            {/* Seerah intro card */}
            <div className={`p-5 rounded-2xl border text-right relative overflow-hidden mb-6 ${
              darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950'
            }`}>
              <p className="text-sm leading-relaxed text-gray-300">
                السيرة النبوية الشريفة هي المنهج والقدوة العملية لحياة نبينا الكريم محمد ﷺ منذ مولده المبارك ونشأته يتيماً حتى وفاته والتحاقه بالرفيق الأعلى. تصفح أبرز المحطات التاريخية لرسالة الهدى والإيمان.
              </p>
            </div>

            {seerahMilestones.map((item, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, x: -15 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="relative pr-14 pb-8 text-right group"
              >
                {/* Timeline node marker */}
                <div className="absolute right-3.5 top-1.5 w-5 h-5 rounded-full border-4 border-[#09150f] bg-[#D4AF37] group-hover:scale-125 transition-transform duration-300 shadow-md shadow-[#D4AF37]/30 z-10" />
                
                {/* Milestone year ribbon */}
                <div className="text-xs font-bold text-[#D4AF37] font-mono mb-1 bg-emerald-500/10 px-2.5 py-0.5 rounded-full inline-block border border-[#D4AF37]/15">
                  {item.date}
                </div>

                <div className={`p-5 rounded-2xl border transition-all duration-300 ${
                  darkMode 
                    ? 'glass-card-dark hover:border-[#D4AF37]/40' 
                    : 'glass-card-light hover:border-emerald-300 hover:shadow-md text-emerald-950'
                }`}>
                  <h4 className="font-quran text-lg font-bold text-emerald-950 dark:text-emerald-100 mb-2">
                    {item.title}
                  </h4>
                  <p className="text-xs sm:text-sm text-gray-400 leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </motion.div>
        ) : (
          /* Articles section */
          <motion.div
            key="articles-catalog"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="space-y-6"
          >
            {/* Toolbar for articles */}
            <div className="flex flex-col md:flex-row justify-between items-center gap-4 mb-6">
              <div className="relative w-full md:max-w-md">
                <input
                  type="text"
                  placeholder="ابحث عن مقالة إسلامية أو كاتب..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className={`w-full py-3 pr-12 pl-4 rounded-xl border focus:outline-none focus:ring-2 transition-all ${
                    darkMode 
                      ? 'bg-emerald-950/40 border-[#D4AF37]/20 text-white placeholder-emerald-300/40 focus:ring-[#D4AF37]/50' 
                      : 'bg-white border-emerald-100 text-emerald-950 focus:ring-emerald-500/50'
                  }`}
                />
                <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#D4AF37]" />
              </div>
              <div className="text-xs text-gray-400 font-semibold bg-[#D4AF37]/10 px-4 py-2 rounded-xl border border-[#D4AF37]/20">
                موسوعة المقالات الوقفية والوعظية النافعة
              </div>
            </div>

            {/* Content list & reader */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* Sidebar list */}
              <div className="lg:col-span-1 space-y-3">
                {filteredArticles.map((art) => {
                  const isSelected = selectedArticle?.id === art.id;
                  return (
                    <button
                      key={art.id}
                      onClick={() => setSelectedArticle(art)}
                      className={`w-full text-right p-4 rounded-xl border transition-all cursor-pointer flex flex-col gap-2 group ${
                        isSelected 
                          ? 'bg-[#D4AF37]/10 border-[#D4AF37] text-[#D4AF37]' 
                          : darkMode ? 'bg-emerald-950/20 border-transparent text-gray-300 hover:bg-[#09150f]' : 'bg-slate-50 border-transparent text-emerald-950 hover:bg-slate-100'
                      }`}
                    >
                      <div className="flex justify-between items-center w-full">
                        <span className="text-sm font-bold truncate">{art.title}</span>
                        <span className="text-[9px] text-[#D4AF37] bg-emerald-500/10 px-2 py-0.5 rounded-full border border-[#D4AF37]/10 whitespace-nowrap">{art.readTime}</span>
                      </div>
                      <div className="text-[10px] text-gray-400 flex items-center gap-2">
                        <span>الكاتب: {art.author}</span>
                        <span>•</span>
                        <span>{art.date}</span>
                      </div>
                    </button>
                  );
                })}
                {filteredArticles.length === 0 && (
                  <div className="text-center py-8 text-gray-400 text-xs">لا يوجد مقالات مطابقة للبحث.</div>
                )}
              </div>

              {/* Reading viewport */}
              <div className="lg:col-span-2">
                {selectedArticle ? (
                  <motion.div
                    key={selectedArticle.id}
                    initial={{ opacity: 0, x: 10 }}
                    animate={{ opacity: 1, x: 0 }}
                    className={`p-6 sm:p-8 rounded-2xl border text-right relative overflow-hidden ${
                      darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950'
                    }`}
                  >
                    <div className="absolute top-0 right-0 p-4 font-quran text-4xl opacity-[0.03] text-[#D4AF37]">﷽</div>
                    
                    <h3 className="font-quran text-2xl font-bold text-[#D4AF37] mb-2">
                      {selectedArticle.title}
                    </h3>

                    <div className="flex items-center gap-3 text-xs text-gray-400 mb-6 pb-3 border-b border-dashed border-[#D4AF37]/15">
                      <span>الكاتب: <span className="text-[#D4AF37] font-semibold">{selectedArticle.author}</span></span>
                      <span>•</span>
                      <span>تاريخ النشر: {selectedArticle.date}</span>
                      <span>•</span>
                      <span>زمن القراءة: {selectedArticle.readTime}</span>
                    </div>

                    <p className="font-sans text-base leading-relaxed text-emerald-950 dark:text-emerald-100 font-medium mb-6 whitespace-pre-line">
                      {selectedArticle.text}
                    </p>

                    <div className="flex gap-3 justify-end pt-4 border-t border-[#D4AF37]/10">
                      <button
                        onClick={() => triggerCopyArticle(selectedArticle)}
                        className="px-4 py-2 border border-[#D4AF37]/20 text-[#D4AF37] rounded-lg text-xs font-bold hover:bg-[#D4AF37]/10 transition-colors flex items-center gap-1.5 cursor-pointer"
                      >
                        <Copy className="w-3.5 h-3.5" />
                        <span>{copied ? 'تم نسخ المقالة كاملاً' : 'نسخ ومشاركة المقالة'}</span>
                      </button>
                    </div>
                  </motion.div>
                ) : (
                  <div className={`p-8 rounded-2xl border text-center flex flex-col justify-center items-center min-h-60 ${
                    darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950'
                  }`}>
                    <FileText className="w-12 h-12 text-[#D4AF37] mb-3 animate-pulse" />
                    <h4 className="text-base font-bold text-gray-300 mb-1">اختر مقالة لقراءتها</h4>
                    <p className="text-xs text-gray-500">تصفح المقالات والعلوم الإسلامية الهادفة لزيادة الوعي والمعرفة</p>
                  </div>
                )}
              </div>

            </div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
