/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface GuestbookDua {
  id: string;
  name: string;
  text: string;
  createdAt: string;
  likes: number;
}

export interface AzkarItem {
  id: string;
  category: string;
  text: string;
  count: number; // target repetitions
  reward?: string;
  description?: string;
}

export interface DuaItem {
  id: string;
  category: string;
  title: string;
  text: string;
  source?: string;
  repeatCount?: number;
  explanation?: string;
}

export interface HadithItem {
  id: string;
  category: string;
  text: string;
  narrator?: string;
  source?: string;
  explanation?: string;
}

export interface StoryItem {
  id: string;
  category: 'prophets' | 'companions' | 'lessons' | 'children';
  title: string;
  text: string;
  moral?: string;
}

export interface AsmaName {
  id: number;
  name: string;
  meaning: string;
  explanation: string;
}

export interface TasbeehPhrase {
  id: string;
  text: string;
  count: number; // personal accumulated
  limit: number; // goal
}

export interface Bookmark {
  surahNumber: number;
  surahName: string;
  verseNumber: number;
  text: string;
}

export interface AudioReciter {
  id: string;
  name: string;
  arabicName: string;
  identifier: string; // used for api (e.g. ar.alafasy)
}

export interface PrayerTimeData {
  fajr: string;
  sunrise: string;
  dhuhr: string;
  asr: string;
  maghrib: string;
  isha: string;
  date: string;
  hijriDate: string;
}

export interface UserStats {
  visitorCount: number;
  quranReadCount: number;
  duaCount: number;
  tasbeehCount: number;
  shares: number;
}

export interface AdminSettings {
  allowAnonymousDuas: boolean;
  featuredReciter: string;
  dailyReminderText: string;
  showLiveStreams: boolean;
}

export interface ArticleItem {
  id: string;
  title: string;
  author: string;
  date: string;
  readTime: string;
  text: string;
}

export interface GuestbookEntry {
  id: string;
  name: string;
  message: string;
  dateStr: string;
}
