/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { 
  getFirestore, 
  collection, 
  doc, 
  getDocs, 
  setDoc, 
  addDoc, 
  deleteDoc, 
  updateDoc, 
  query, 
  orderBy,
  writeBatch
} from 'firebase/firestore';

// Import static fallback data
import { azkarData, duasData, hadithsData, storiesData, recitersList } from '../data/islamicData';
import { surahsList } from '../data/surahList';
import { DuaItem, AzkarItem, HadithItem, StoryItem, AudioReciter } from '../types';

// Configuration loaded from firebase-applet-config.json
const firebaseConfig = {
  projectId: "astral-codex-8fjbn",
  appId: "1:659483356254:web:fe7ac99ce3e3df416f18cf",
  apiKey: "AIzaSyCFpn74ftqa80hz0PZ-rxHW1E5XM7nxjT0",
  authDomain: "astral-codex-8fjbn.firebaseapp.com",
  storageBucket: "astral-codex-8fjbn.firebasestorage.app",
  messagingSenderId: "659483356254",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firestore with the custom database ID from config
export const db = getFirestore(app, "ai-studio-fa2812ad-426b-4c15-9b6d-8940118d955d");
export const auth = getAuth(app);

// Custom error handling types as per the Firebase Integration Skill
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// System Metadata Seed check
export async function seedDatabaseIfEmpty() {
  try {
    const checkDoc = doc(db, 'system_metadata', 'seed_status');
    const checkSnap = await getDocs(collection(db, 'system_metadata'));
    
    // If metadata exists, we are already seeded
    if (!checkSnap.empty) {
      console.log('Firebase Firestore is already initialized and seeded.');
      return;
    }

    console.log('Database empty. Starting rich seeding of Islamic contents...');
    
    // Seed metadata status
    await setDoc(doc(db, 'system_metadata', 'seed_status'), {
      seeded: true,
      seededAt: new Date().toISOString()
    });

    // Write Duas
    for (const item of duasData) {
      await setDoc(doc(db, 'duas', item.id), item);
    }

    // Write Azkar
    for (const item of azkarData) {
      await setDoc(doc(db, 'azkar', item.id), item);
    }

    // Write Hadith
    for (const item of hadithsData) {
      await setDoc(doc(db, 'hadith', item.id), item);
    }

    // Write Stories
    for (const item of storiesData) {
      await setDoc(doc(db, 'stories', item.id), item);
    }

    // Write Audio Reciters
    for (const item of recitersList) {
      await setDoc(doc(db, 'reciters', item.id), item);
    }

    // Write default Quran sections metadata
    for (const surah of surahsList) {
      await setDoc(doc(db, 'quran_sections', surah.number.toString()), {
        number: surah.number,
        name: surah.name,
        englishName: surah.englishName,
        numberOfAyahs: surah.numberOfAyahs,
        revelationType: surah.revelationType,
        text: ''
      });
    }

    // Write default Islamic Articles
    const initialArticles = [
      {
        id: 'art1',
        title: 'أثر الصدقة الجارية في تبريد قبور الموتى ونيل رضوان الله',
        author: 'لجنة النشر والوعظ العلمي',
        date: '٢٠٢٦م / ١٤٤٧هـ',
        readTime: '٤ دقائق',
        text: `الصدقة الجارية هي من أعظم أبواب القربات التي يتقرب بها العبد إلى ربه، وهي الوقف المستمر الذي لا ينقطع ثوابه بموت الواقف أو المهدى إليه، بل يستمر ثوابه يجري في صحيفته يوماً بعد يوم، وعاماً بعد عام.

وقد ثبت في الحديث الصحيح عن النبي ﷺ أنه قال: "إذا مات ابن آدم انقطع عمله إلا من ثلاث: صدقة جارية، أو علم ينتفع به، أو ولد صالح يدعو له".

ومن عظيم أثر الصدقة الجارية:
١. تبريد القبور وإضاءتها: فإن الصدقة تطفئ غضب الرب، وتكون ظلاً ظليلاً للمتوفى في قبره ويوم القيامة، كما قال ﷺ: "إن الصدقة لتطفئ عن أهلها حر القبور، وإنما يستظل المؤمن يوم القيامة في ظل صدقته".
٢. تفريج الكربات وتيسير الأمور: فهي تجلب البركة في الرزق للواقف الحي، وتثقل ميزان الحسنات للميت في الآخرة.
٣. وسيلة للتكافل والتراحم الاجتماعي: مثل بناء آبار المياه، وتشييد دور العلم، وبناء المواقع الإلكترونية النافعة التي تبث العلم والأدعية والأذكار، لتقريب الناس من ربهم وتيسير الطاعات لهم.`
      },
      {
        id: 'art2',
        title: 'بر الوالدين بعد الوفاة: كيف نكون أبناء بررة بعد رحيلهما؟',
        author: 'الشيخ عبدالرحمن القاسمي',
        date: '٢٠٢٦م / ١٤٤٧هـ',
        readTime: '٥ دقائق',
        text: `بر الوالدين فريضة إلهية عظيمة ممتدة، لا تنتهي بانتهاء حياتهما في هذه الدنيا، بل إن البر الحقيقي والاختبار الأصدق لمعدن الأبناء يبدأ بعد وفاة الوالدين أو أحدهما، لكونه برّاً خالصاً خالياً من الرياء أو الخوف، موجهاً لوجه الله تعالى فقط.

وقد سأل رجل النبي ﷺ فقال: "يا رسول الله، هل بقي من بر أبوي شيء أبرهما به بعد موتهما؟" فقال ﷺ: "نعم، الصلاة عليهما، والاستغفار لهما، وإنفاذ عهدهما من بعدهما، وصلة الرحم التي لا توصل إلا بهما، وإكرام صديقهما".

أبرز صور البر بالوالدين بعد مماتهما:
١. كثرة الدعاء والاستغفار لهما: وهو أعظم ما يرتفع به درجات الميت في الجنة، كما جاء في الحديث: "إن الرجل لترفع درجته في الجنة فيقول: أنى هذا؟ فيقال: باستغفار ولدك لك".
٢. الصدقة الجارية على روحهما: كسقاية الماء، وتوزيع المصاحف، وبث العلم والخير.
٣. صلة أرحامهما وإكرام أصدقائهما: فإن النبي ﷺ كان يكرم صواحب السيدة خديجة بعد وفاتها وفاءً لها، وهو من كمال البر بالوالدين صلة عماتك وخالاتك وأعمامك وأخوالك.`
      },
      {
        id: 'art3',
        title: 'منهج القرآن الكريم في تربية النفوس وتزكيتها وبث الطمأنينة',
        author: 'د. محمد بن صالح الدوسري',
        date: '٢٠٢٦م / ١٤٤٧هـ',
        readTime: '٦ دقائق',
        text: `تعتبر تزكية النفس وتربيتها على الأخلاق الفاضلة والفضائل الإيمانية هي الغاية الأسمى للرسالات الإلهية، وقد جعل الله تبارك وتعالى فلاح العبد معلقاً بمدى تزكيته لنفسه وتطهيرها من الدنس والآثام، فقال عز وجل في سورة الشمس: "قَدْ أَفْلَحَ مَن زَكَّاهَا * وَقَدْ خَابَ مَن دَسَّاهَا".

من معالم المنهج القرآني في التزكية:
١. التوحيد الخالص وتعظيم الله: فعندما يستشعر القلب عظمة الخالق وعلمه المحيط بكل صغيرة وكبيرة، ينبعث فيه الخوف والرجاء والمحبة الصادقة.
٢. تدبر آيات القرآن وملازمته: فإن القرآن شفاء لما في الصدور من الشكوك والأحزان والأمراض، وقراءته تضفي طمأنينة وسكينة فريدة على النفس والروح.
٣. مجاهدة الهوى والشيطان: بالاستغفار الدائم والمحافظة على الصلاة في أوقاتها، ومصاحبة الأخيار والابتعاد عن مواطن الفتن والشبهات.`
      }
    ];

    for (const art of initialArticles) {
      await setDoc(doc(db, 'articles', art.id), art);
    }

    console.log('Firebase Seeding completed successfully!');
  } catch (err) {
    console.error('Error seeding Firebase:', err);
    handleFirestoreError(err, OperationType.WRITE, 'system_metadata/seed_status');
  }
}

// ==========================================
// 1. DUAS DATA LAYER
// ==========================================
export async function getDuas(): Promise<DuaItem[]> {
  try {
    const snap = await getDocs(collection(db, 'duas'));
    if (snap.empty) return duasData; // fallback
    const items: DuaItem[] = [];
    snap.forEach((docSnap) => {
      items.push({ id: docSnap.id, ...docSnap.data() } as DuaItem);
    });
    return items;
  } catch (e) {
    console.warn('Firestore fetch Duas failed, using static data:', e);
    if (e instanceof Error && (e.message.includes('permission') || e.message.includes('Permission'))) {
      handleFirestoreError(e, OperationType.LIST, 'duas');
    }
    return duasData;
  }
}

export async function saveDua(item: DuaItem): Promise<void> {
  try {
    await setDoc(doc(db, 'duas', item.id), item);
  } catch (e) {
    handleFirestoreError(e, OperationType.WRITE, `duas/${item.id}`);
  }
}

export async function removeDua(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'duas', id));
  } catch (e) {
    handleFirestoreError(e, OperationType.DELETE, `duas/${id}`);
  }
}

// ==========================================
// 2. AZKAR DATA LAYER
// ==========================================
export async function getAzkar(): Promise<AzkarItem[]> {
  try {
    const snap = await getDocs(collection(db, 'azkar'));
    if (snap.empty) return azkarData; // fallback
    const items: AzkarItem[] = [];
    snap.forEach((docSnap) => {
      items.push({ id: docSnap.id, ...docSnap.data() } as AzkarItem);
    });
    return items;
  } catch (e) {
    console.warn('Firestore fetch Azkar failed, using static data:', e);
    if (e instanceof Error && (e.message.includes('permission') || e.message.includes('Permission'))) {
      handleFirestoreError(e, OperationType.LIST, 'azkar');
    }
    return azkarData;
  }
}

export async function saveZikr(item: AzkarItem): Promise<void> {
  try {
    await setDoc(doc(db, 'azkar', item.id), item);
  } catch (e) {
    handleFirestoreError(e, OperationType.WRITE, `azkar/${item.id}`);
  }
}

export async function removeZikr(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'azkar', id));
  } catch (e) {
    handleFirestoreError(e, OperationType.DELETE, `azkar/${id}`);
  }
}

// ==========================================
// 3. HADITH DATA LAYER
// ==========================================
export async function getHadiths(): Promise<HadithItem[]> {
  try {
    const snap = await getDocs(collection(db, 'hadith'));
    if (snap.empty) return hadithsData; // fallback
    const items: HadithItem[] = [];
    snap.forEach((docSnap) => {
      items.push({ id: docSnap.id, ...docSnap.data() } as HadithItem);
    });
    return items;
  } catch (e) {
    console.warn('Firestore fetch Hadiths failed, using static data:', e);
    if (e instanceof Error && (e.message.includes('permission') || e.message.includes('Permission'))) {
      handleFirestoreError(e, OperationType.LIST, 'hadith');
    }
    return hadithsData;
  }
}

export async function saveHadith(item: HadithItem): Promise<void> {
  try {
    await setDoc(doc(db, 'hadith', item.id), item);
  } catch (e) {
    handleFirestoreError(e, OperationType.WRITE, `hadith/${item.id}`);
  }
}

export async function removeHadith(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'hadith', id));
  } catch (e) {
    handleFirestoreError(e, OperationType.DELETE, `hadith/${id}`);
  }
}

// ==========================================
// 4. STORIES DATA LAYER
// ==========================================
export async function getStories(): Promise<StoryItem[]> {
  try {
    const snap = await getDocs(collection(db, 'stories'));
    if (snap.empty) return storiesData; // fallback
    const items: StoryItem[] = [];
    snap.forEach((docSnap) => {
      items.push({ id: docSnap.id, ...docSnap.data() } as StoryItem);
    });
    return items;
  } catch (e) {
    console.warn('Firestore fetch Stories failed, using static data:', e);
    if (e instanceof Error && (e.message.includes('permission') || e.message.includes('Permission'))) {
      handleFirestoreError(e, OperationType.LIST, 'stories');
    }
    return storiesData;
  }
}

export async function saveStory(item: StoryItem): Promise<void> {
  try {
    await setDoc(doc(db, 'stories', item.id), item);
  } catch (e) {
    handleFirestoreError(e, OperationType.WRITE, `stories/${item.id}`);
  }
}

export async function removeStory(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'stories', id));
  } catch (e) {
    handleFirestoreError(e, OperationType.DELETE, `stories/${id}`);
  }
}

// ==========================================
// 5. ARTICLES DATA LAYER
// ==========================================
export interface ArticleItem {
  id: string;
  title: string;
  author: string;
  date: string;
  readTime: string;
  text: string;
}

export async function getArticles(): Promise<ArticleItem[]> {
  try {
    const snap = await getDocs(collection(db, 'articles'));
    if (snap.empty) {
      // Default fallback articles
      return [
        {
          id: 'art1',
          title: 'أثر الصدقة الجارية في تبريد قبور الموتى ونيل رضوان الله',
          author: 'لجنة النشر والوعظ العلمي',
          date: '٢٠٢٦م / ١٤٤٧هـ',
          readTime: '٤ دقائق',
          text: `الصدقة الجارية هي من أعظم أبواب القربات التي يتقرب بها العبد إلى ربه، وهي الوقف المستمر الذي لا ينقطع ثوابه بموت الواقف أو المهدى إليه، بل يستمر ثوابه يجري في صحيفته يوماً بعد يوم، وعاماً بعد عام.

وقد ثبت في الحديث الصحيح عن النبي ﷺ أنه قال: "إذا مات ابن آدم انقطع عمله إلا من ثلاث: صدقة جارية، أو علم ينتفع به، أو ولد صالح يدعو له".

ومن عظيم أثر الصدقة الجارية:
١. تبريد القبور وإضاءتها: فإن الصدقة تطفئ غضب الرب، وتكون ظلاً ظليلاً للمتوفى في قبره ويوم القيامة، كما قال ﷺ: "إن الصدقة لتطفئ عن أهلها حر القبور، وإنما يستظل المؤمن يوم القيامة في ظل صدقته".
٢. تفريج الكربات وتيسير الأمور: فهي تجلب البركة في الرزق للواقف الحي، وتثقل ميزان الحسنات للميت في الآخرة.
٣. وسيلة للتكافل والتراحم الاجتماعي: مثل بناء آبار المياه، وتشييد دور العلم، وبناء المواقع الإلكترونية النافعة التي تبث العلم والأدعية والأذكار، لتقريب الناس من ربهم وتيسير الطاعات لهم.`
        },
        {
          id: 'art2',
          title: 'بر الوالدين بعد الوفاة: كيف نكون أبناء بررة بعد رحيلهما؟',
          author: 'الشيخ عبدالرحمن القاسمي',
          date: '٢٠٢٦م / ١٤٤٧هـ',
          readTime: '٥ دقائق',
          text: `بر الوالدين فريضة إلهية عظيمة ممتدة، لا تنتهي بانتهاء حياتهما في هذه الدنيا، بل إن البر الحقيقي والاختبار الأصدق لمعدن الأبناء يبدأ بعد وفاة الوالدين أو أحدهما، لكونه برّاً خالصاً خالياً من الرياء أو الخوف، موجهاً لوجه الله تعالى فقط.

وقد سأل رجل النبي ﷺ فقال: "يا رسول الله، هل بقي من بر أبوي شيء أبرهما به بعد موتهما؟" فقال ﷺ: "نعم، الصلاة عليهما، والاستغفار لهما، وإنفاذ عهدهما من بعدهما، وصلة الرحم التي لا توصل إلا بهما، وإكرام صديقهما".

أبرز صور البر بالوالدين بعد مماتهما:
١. كثرة الدعاء والاستغفار لهما: وهو أعظم ما يرتفع به درجات الميت في الجنة، كما جاء في الحديث: "إن الرجل لترفع درجته في الجنة فيقول: أنى هذا؟ فيقال: باستغفار ولدك لك".
٢. الصدقة الجارية على روحهما: كسقاية الماء، وتوزيع المصاحف، وبث العلم والخير.
٣. صلة أرحامهما وإكرام أصدقائهما: فإن النبي ﷺ كان يكرم صواحب السيدة خديجة بعد وفاتها وفاءً لها، وهو من كمال البر بالوالدين صلة عماتك وخالاتك وأعمامك وأخوالك.`
        },
        {
          id: 'art3',
          title: 'منهج القرآن الكريم في تربية النفوس وتزكيتها وبث الطمأنينة',
          author: 'د. محمد بن صالح الدوسري',
          date: '٢٠٢٦م / ١٤٤٧هـ',
          readTime: '٦ دقائق',
          text: `تعتبر تزكية النفس وتربيتها على الأخلاق الفاضلة والفضائل الإيمانية هي الغاية الأسمى للرسالات الإلهية، وقد جعل الله تبارك وتعالى فلاح العبد معلقاً بمدى تزكيته لنفسه وتطهيرها من الدنس والآثام، فقال عز وجل في سورة الشمس: "قَدْ أَفْلَحَ مَن زَكَّاهَا * وَقَدْ خَابَ مَن دَسَّاهَا".

من معالم المنهج القرآني في التزكية:
١. التوحيد الخالص وتعظيم الله: فعندما يستشعر القلب عظمة الخالق وعلمه المحيط بكل صغيرة وكبيرة، ينبعث فيه الخوف والرجاء والمحبة الصادقة.
٢. تدبر آيات القرآن وملازمته: فإن القرآن شفاء لما في الصدور من الشكوك والأحزان والأمراض، وقراءته تضفي طمأنينة وسكينة فريدة على النفس والروح.
٣. مجاهدة الهوى والشيطان: بالاستغفار الدائم والمحافظة على الصلاة في أوقاتها، ومصاحبة الأخيار والابتعاد عن مواطن الفتن والشبهات.`
        }
      ];
    }
    const items: ArticleItem[] = [];
    snap.forEach((docSnap) => {
      items.push({ id: docSnap.id, ...docSnap.data() } as ArticleItem);
    });
    return items;
  } catch (e) {
    console.warn('Firestore fetch Articles failed:', e);
    if (e instanceof Error && (e.message.includes('permission') || e.message.includes('Permission'))) {
      handleFirestoreError(e, OperationType.LIST, 'articles');
    }
    return [];
  }
}

export async function saveArticle(item: ArticleItem): Promise<void> {
  try {
    await setDoc(doc(db, 'articles', item.id), item);
  } catch (e) {
    handleFirestoreError(e, OperationType.WRITE, `articles/${item.id}`);
  }
}

export async function removeArticle(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'articles', id));
  } catch (e) {
    handleFirestoreError(e, OperationType.DELETE, `articles/${id}`);
  }
}

// ==========================================
// 6. AUDIO RECITERS & AUDIO CONTENT LAYER
// ==========================================
export async function getReciters(): Promise<AudioReciter[]> {
  try {
    const snap = await getDocs(collection(db, 'reciters'));
    if (snap.empty) return recitersList;
    const items: AudioReciter[] = [];
    snap.forEach((docSnap) => {
      items.push({ id: docSnap.id, ...docSnap.data() } as AudioReciter);
    });
    return items;
  } catch (e) {
    console.warn('Firestore fetch Reciters failed, using static list:', e);
    if (e instanceof Error && (e.message.includes('permission') || e.message.includes('Permission'))) {
      handleFirestoreError(e, OperationType.LIST, 'reciters');
    }
    return recitersList;
  }
}

export async function saveReciter(item: AudioReciter): Promise<void> {
  try {
    await setDoc(doc(db, 'reciters', item.id), item);
  } catch (e) {
    handleFirestoreError(e, OperationType.WRITE, `reciters/${item.id}`);
  }
}

export async function removeReciter(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'reciters', id));
  } catch (e) {
    handleFirestoreError(e, OperationType.DELETE, `reciters/${id}`);
  }
}

// ==========================================
// 7. QURAN SURAH DATA LAYER (FOR Scale-out content)
// ==========================================
export async function getQuranSections(): Promise<any[]> {
  try {
    const snap = await getDocs(collection(db, 'quran_sections'));
    if (snap.empty) return surahsList;
    const items: any[] = [];
    snap.forEach((docSnap) => {
      items.push({ ...docSnap.data() });
    });
    // Sort by surah number
    return items.sort((a, b) => a.number - b.number);
  } catch (e) {
    console.warn('Firestore fetch QuranSections failed:', e);
    if (e instanceof Error && (e.message.includes('permission') || e.message.includes('Permission'))) {
      handleFirestoreError(e, OperationType.LIST, 'quran_sections');
    }
    return surahsList;
  }
}

export async function saveQuranSection(number: number, data: any): Promise<void> {
  try {
    await setDoc(doc(db, 'quran_sections', number.toString()), data);
  } catch (e) {
    handleFirestoreError(e, OperationType.WRITE, `quran_sections/${number}`);
  }
}

export async function removeQuranSection(number: number): Promise<void> {
  try {
    await deleteDoc(doc(db, 'quran_sections', number.toString()));
  } catch (e) {
    handleFirestoreError(e, OperationType.DELETE, `quran_sections/${number}`);
  }
}

// ==========================================
// GUESTBOOK / COMMEMORATIVE DUA ENTRIES PERSISTENCE
// ==========================================
export interface GuestbookEntry {
  id: string;
  name: string;
  message: string;
  dateStr: string;
  createdAt?: string;
}

export async function getGuestbookEntries(): Promise<GuestbookEntry[]> {
  try {
    const snap = await getDocs(collection(db, 'guestbook'));
    const items: GuestbookEntry[] = [];
    snap.forEach((docSnap) => {
      items.push({ id: docSnap.id, ...docSnap.data() } as GuestbookEntry);
    });
    return items;
  } catch (e) {
    console.warn('Firestore fetch guestbook entries failed:', e);
    if (e instanceof Error && (e.message.includes('permission') || e.message.includes('Permission'))) {
      handleFirestoreError(e, OperationType.LIST, 'guestbook');
    }
    // fallback to localstorage
    const local = localStorage.getItem('sadaqah_guestbook_entries');
    return local ? JSON.parse(local) : [];
  }
}

export async function addGuestbookEntry(entry: GuestbookEntry): Promise<void> {
  try {
    await setDoc(doc(db, 'guestbook', entry.id), {
      ...entry,
      createdAt: entry.createdAt || new Date().toISOString()
    });
  } catch (e) {
    console.warn('Firestore save guestbook entry failed, using localstorage:', e);
    handleFirestoreError(e, OperationType.WRITE, `guestbook/${entry.id}`);
  }
  // mirror in localstorage
  const local = localStorage.getItem('sadaqah_guestbook_entries');
  const list = local ? JSON.parse(local) : [];
  localStorage.setItem('sadaqah_guestbook_entries', JSON.stringify([entry, ...list]));
}

export async function removeGuestbookEntry(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'guestbook', id));
  } catch (e) {
    console.warn('Firestore delete guestbook entry failed:', e);
    handleFirestoreError(e, OperationType.DELETE, `guestbook/${id}`);
  }
  // mirror in localstorage
  const local = localStorage.getItem('sadaqah_guestbook_entries');
  if (local) {
    const list = JSON.parse(local).filter((item: any) => item.id !== id);
    localStorage.setItem('sadaqah_guestbook_entries', JSON.stringify(list));
  }
}
