# صدقة جارية — نسخة Android

هذا المشروع هو موقع «صدقة جارية» الأصلي مع إعداد Capacitor لتحويله إلى تطبيق Android.

> مهم: ارفع **محتويات هذا المجلد** إلى جذر مستودع GitHub، وليس ملف ZIP نفسه، حتى يتعرف GitHub على `.github/workflows/build-apk.yml` كـWorkflow.

الـWorkflow يبني الموقع ثم ينشئ مشروع Android ويخرج:
`android/app/build/outputs/apk/debug/app-debug.apk`
