/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Award, 
  RotateCcw, 
  Plus, 
  Trash2, 
  Sparkles, 
  TrendingUp, 
  Smile, 
  CheckCircle2, 
  Volume2, 
  VolumeX,
  Target
} from 'lucide-react';

interface TasbeehPhrase {
  id: string;
  text: string;
  count: number;
  limit: number;
}

export default function DigitalTasbeeh({ darkMode, incrementTasbeehCount }: { darkMode: boolean; incrementTasbeehCount: () => void }) {
  const [phrases, setPhrases] = useState<TasbeehPhrase[]>([]);
  const [activePhraseId, setActivePhraseId] = useState<string>('t1');
  const [newPhraseText, setNewPhraseText] = useState('');
  const [newPhraseGoal, setNewPhraseGoal] = useState(33);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [showGoalNotification, setShowGoalNotification] = useState(false);

  // Default initial phrases
  const defaultPhrases: TasbeehPhrase[] = [
    { id: 't1', text: 'سُبْحَانَ اللَّهِ', count: 0, limit: 33 },
    { id: 't2', text: 'الْحَمْدُ لِلَّهِ', count: 0, limit: 33 },
    { id: 't3', text: 'اللَّهُ أَكْبَرُ', count: 0, limit: 33 },
    { id: 't4', text: 'لَا إِلَهَ إِلَّا اللَّهُ', count: 0, limit: 100 },
    { id: 't5', text: 'أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ', count: 0, limit: 100 },
    { id: 't6', text: 'اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ', count: 0, limit: 100 }
  ];

  // Load from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem('sadaqah_tasbeeh_phrases');
    if (saved) {
      setPhrases(JSON.parse(saved));
    } else {
      setPhrases(defaultPhrases);
      localStorage.setItem('sadaqah_tasbeeh_phrases', JSON.stringify(defaultPhrases));
    }

    const savedActive = localStorage.getItem('sadaqah_tasbeeh_active_id');
    if (savedActive) setActivePhraseId(savedActive);
  }, []);

  const activePhrase = phrases.find(p => p.id === activePhraseId) || phrases[0] || defaultPhrases[0];

  // Helper to save phrases state
  const savePhrases = (updatedPhrases: TasbeehPhrase[]) => {
    setPhrases(updatedPhrases);
    localStorage.setItem('sadaqah_tasbeeh_phrases', JSON.stringify(updatedPhrases));
  };

  // Perform a single click/tasbeeh count
  const handleIncrement = () => {
    if (!activePhrase) return;
    
    // Play sound if enabled
    if (soundEnabled) {
      try {
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const oscillator = audioCtx.createOscillator();
        const gainNode = audioCtx.createGain();
        oscillator.connect(gainNode);
        gainNode.connect(audioCtx.destination);
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(600, audioCtx.currentTime); // high pitched tick
        gainNode.gain.setValueAtTime(0.04, audioCtx.currentTime);
        oscillator.start();
        oscillator.stop(audioCtx.currentTime + 0.05);
      } catch (e) {
        // Fallback
      }
    }

    // Gentle physical haptic vibration if supported
    if (navigator.vibrate) {
      navigator.vibrate(30);
    }

    const nextCount = activePhrase.count + 1;
    
    // Check goal achieved
    if (nextCount === activePhrase.limit) {
      setShowGoalNotification(true);
      if (navigator.vibrate) {
        navigator.vibrate([100, 50, 100]); // double vibration for goal
      }
      setTimeout(() => setShowGoalNotification(false), 3000);
    }

    const updated = phrases.map(p => {
      if (p.id === activePhrase.id) {
        return { ...p, count: nextCount };
      }
      return p;
    });

    savePhrases(updated);
    incrementTasbeehCount(); // increment global stats count
  };

  const handleResetActiveCount = () => {
    const updated = phrases.map(p => {
      if (p.id === activePhraseId) {
        return { ...p, count: 0 };
      }
      return p;
    });
    savePhrases(updated);
  };

  const handleAddNewPhrase = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPhraseText.trim()) return;

    const newPhrase: TasbeehPhrase = {
      id: `custom-${Date.now()}`,
      text: newPhraseText.trim(),
      count: 0,
      limit: Number(newPhraseGoal) || 33
    };

    const updated = [...phrases, newPhrase];
    savePhrases(updated);
    setActivePhraseId(newPhrase.id);
    localStorage.setItem('sadaqah_tasbeeh_active_id', newPhrase.id);
    
    setNewPhraseText('');
    setNewPhraseGoal(33);
  };

  const handleDeletePhrase = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    // Do not allow deleting first preloaded phrase to avoid empty state
    if (phrases.length <= 1) return;

    const updated = phrases.filter(p => p.id !== id);
    savePhrases(updated);

    if (activePhraseId === id) {
      setActivePhraseId(updated[0].id);
      localStorage.setItem('sadaqah_tasbeeh_active_id', updated[0].id);
    }
  };

  // Percentage calculations
  const progressPercent = activePhrase ? Math.min(100, Math.floor((activePhrase.count / activePhrase.limit) * 100)) : 0;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-right">
      
      {/* Header */}
      <div className="text-center mb-10">
        <h2 className="font-quran text-3xl font-extrabold text-[#D4AF37] mb-2">المسبحة الإلكترونية المطورة</h2>
        <p className={`text-sm ${darkMode ? 'text-gray-300' : 'text-emerald-900'} max-w-xl mx-auto`}>
          اذكر الله تبارك وتعالى أينما كنت وحدد أهدافك اليومية لكل تسبيحة، مع ميزة حفظ التكرارات والجوائز التشجيعية لختم الورد.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left column: Phrase Selector & Custom Adder */}
        <div className="lg:col-span-1 space-y-6">
          
          {/* List of Phrases */}
          <div className={`p-5 rounded-2xl border text-right ${
            darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950'
          }`}>
            <h3 className={`text-sm font-bold mb-4 flex items-center gap-1.5 ${darkMode ? 'text-[#D4AF37]' : 'text-emerald-950'}`}>
              <Award className="w-4 h-4 text-[#D4AF37]" />
              <span>اختر صيغة الذكر والاستغفار</span>
            </h3>

            <div className="space-y-2 max-h-72 overflow-y-auto">
              {phrases.map((phrase) => {
                const isActive = phrase.id === activePhraseId;
                return (
                  <button
                    key={phrase.id}
                    onClick={() => {
                      setActivePhraseId(phrase.id);
                      localStorage.setItem('sadaqah_tasbeeh_active_id', phrase.id);
                    }}
                    className={`w-full text-right p-3 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                      isActive 
                        ? 'bg-emerald-500/10 border-[#D4AF37] text-[#D4AF37]' 
                        : darkMode ? 'bg-emerald-950/20 border-transparent text-gray-300 hover:bg-emerald-950/40' : 'bg-slate-50 border-transparent text-emerald-950 hover:bg-slate-100'
                    }`}
                  >
                    <div className="overflow-hidden">
                      <div className="text-sm font-bold truncate font-quran">{phrase.text}</div>
                      <div className="text-[10px] text-gray-400 mt-0.5">الهدف: {phrase.limit} | المنجز: {phrase.count}</div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold font-mono text-[#D4AF37]">{phrase.count}</span>
                      {phrases.length > 1 && phrase.id.startsWith('custom-') && (
                        <button
                          onClick={(e) => handleDeletePhrase(phrase.id, e)}
                          className="p-1.5 rounded-lg text-red-500 hover:bg-red-500/10 transition-colors"
                          title="حذف الذكر"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Custom Phrase Form */}
          <form
            onSubmit={handleAddNewPhrase}
            className={`p-5 rounded-2xl border text-right ${
              darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950'
            }`}
          >
            <h3 className={`text-sm font-bold mb-4 flex items-center gap-1.5 ${darkMode ? 'text-[#D4AF37]' : 'text-emerald-950'}`}>
              <Plus className="w-4 h-4 text-[#D4AF37]" />
              <span>إضافة ذكر مخصص جديد</span>
            </h3>

            <div className="space-y-4">
              <div>
                <label className="text-[10px] text-gray-400 block mb-1 font-semibold">نص الذكر (مثال: سبحان الله وبحمده)</label>
                <input
                  type="text"
                  required
                  placeholder="اكتب الذكر هنا..."
                  value={newPhraseText}
                  onChange={(e) => setNewPhraseText(e.target.value)}
                  className={`w-full p-2.5 rounded-lg border text-sm text-right focus:outline-none focus:ring-1 focus:ring-[#D4AF37] ${
                    darkMode ? 'bg-emerald-950/30 border-[#D4AF37]/20 text-white' : 'bg-slate-50 border-emerald-100 text-emerald-950'
                  }`}
                />
              </div>

              <div>
                <label className="text-[10px] text-gray-400 block mb-1 font-semibold">الهدف اليومي المرجو (تكرار)</label>
                <input
                  type="number"
                  min="1"
                  required
                  value={newPhraseGoal}
                  onChange={(e) => setNewPhraseGoal(Number(e.target.value))}
                  className={`w-full p-2.5 rounded-lg border text-sm text-right focus:outline-none focus:ring-1 focus:ring-[#D4AF37] ${
                    darkMode ? 'bg-emerald-950/30 border-[#D4AF37]/20 text-white' : 'bg-slate-50 border-emerald-100 text-emerald-950'
                  }`}
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition-colors cursor-pointer"
              >
                حفظ وإضافة للمسبحة
              </button>
            </div>
          </form>

        </div>

        {/* Right columns: Main Interactive Rosary / Clicker */}
        <div className={`lg:col-span-2 flex flex-col items-center justify-center p-6 md:p-8 rounded-2xl border min-h-[500px] relative overflow-hidden ${
          darkMode ? 'glass-emerald-dark text-white' : 'glass-card-light text-emerald-950'
        }`}>
          
          {/* Animated background stars */}
          <div className="absolute inset-0 islamic-pattern-dense opacity-[0.03] pointer-events-none" />

          {/* Sounds Toggle */}
          <div className="absolute top-4 right-4 z-10">
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              className={`p-2.5 rounded-full transition-colors cursor-pointer ${
                soundEnabled 
                  ? 'bg-[#D4AF37]/10 text-[#D4AF37] border border-[#D4AF37]/20' 
                  : 'bg-gray-500/10 text-gray-400 border border-transparent'
              }`}
              title={soundEnabled ? "إيقاف الصوت المرافق للذكر" : "تفعيل الصوت المرافق للذكر"}
            >
              {soundEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
            </button>
          </div>

          <div className="absolute top-4 left-4 z-10">
            <button
              onClick={handleResetActiveCount}
              className="px-3 py-1.5 rounded-lg border border-red-500/15 text-red-400 hover:bg-red-500/10 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
              title="تصفير عداد الذكر الحالي"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>تصفير</span>
            </button>
          </div>

          {activePhrase ? (
            <div className="text-center w-full max-w-md relative z-10 flex flex-col items-center">
              
              {/* Display Phrase */}
              <motion.h3 
                key={activePhrase.id}
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="font-quran text-2xl sm:text-3xl font-bold text-[#D4AF37] leading-relaxed max-w-xs mx-auto mb-2 text-center"
              >
                {activePhrase.text}
              </motion.h3>
              
              <p className="text-xs text-gray-400 mb-8 font-medium">هدف التكرار اليومي الحالي: {activePhrase.limit} مرات</p>

              {/* Rosary Trigger Ring */}
              <div className="relative flex items-center justify-center w-64 h-64 mb-8">
                
                {/* SVG Progress Circle Ring */}
                <svg className="absolute w-full h-full -rotate-90">
                  <circle
                    cx="128"
                    cy="128"
                    r="110"
                    stroke={darkMode ? 'rgba(212, 175, 55, 0.05)' : 'rgba(212, 175, 55, 0.1)'}
                    strokeWidth="10"
                    fill="transparent"
                  />
                  <motion.circle
                    cx="128"
                    cy="128"
                    r="110"
                    stroke="#D4AF37"
                    strokeWidth="10"
                    fill="transparent"
                    strokeDasharray={2 * Math.PI * 110}
                    animate={{ strokeDashoffset: (2 * Math.PI * 110) * (1 - progressPercent / 100) }}
                    transition={{ duration: 0.3, ease: 'easeOut' }}
                    strokeLinecap="round"
                  />
                </svg>

                {/* Big Interactive Click Trigger Button */}
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  onClick={handleIncrement}
                  className="w-48 h-48 rounded-full bg-gradient-to-tr from-emerald-950 to-emerald-900 border-2 border-[#D4AF37]/40 shadow-2xl flex flex-col items-center justify-center cursor-pointer relative group overflow-hidden"
                >
                  <span className="absolute inset-0 bg-[#D4AF37]/5 group-hover:opacity-100 opacity-0 transition-opacity duration-300" />
                  
                  {/* Digital value */}
                  <span className="text-5xl font-mono font-bold text-white tracking-wider">
                    {activePhrase.count}
                  </span>
                  
                  {/* Label */}
                  <span className="text-[10px] text-gray-300 font-bold tracking-widest mt-2 block font-sans">
                    انقر هنا للتسبيح
                  </span>
                </motion.button>

                {/* Animated Goal Achieved Shield */}
                <AnimatePresence>
                  {showGoalNotification && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.6 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.6 }}
                      className="absolute inset-0 rounded-full bg-emerald-600/95 backdrop-blur-sm flex flex-col items-center justify-center p-4 text-center text-white"
                    >
                      <CheckCircle2 className="w-12 h-12 text-white mb-2 animate-bounce" />
                      <div className="text-base font-bold font-quran text-[#D4AF37]">تقبّل الله طاعتك!</div>
                      <div className="text-[10px] opacity-90 mt-1">أتممت الهدف المطلوب وهو {activePhrase.limit} مرة بنجاح</div>
                    </motion.div>
                  )}
                </AnimatePresence>

              </div>

              {/* Progress Percentage */}
              <div className="flex items-center gap-4 text-xs font-semibold bg-[#D4AF37]/10 px-4 py-2 rounded-full border border-[#D4AF37]/20">
                <Target className="w-4 h-4 text-[#D4AF37]" />
                <span className="text-[#D4AF37]">أنجزت {progressPercent}% من الهدف اليومي لهذا الورد</span>
              </div>

            </div>
          ) : (
            <div className="text-gray-400 text-xs">لا يوجد صيغة أذكار متاحة. الرجاء تصفير البيانات أو إعادة التعبئة.</div>
          )}

        </div>

      </div>

    </div>
  );
}
