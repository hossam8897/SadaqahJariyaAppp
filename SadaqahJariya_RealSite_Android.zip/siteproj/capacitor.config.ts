import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.sadaqahjariya.app',
  appName: 'صدقة جارية',
  webDir: 'dist',
  android: {
    allowMixedContent: true,
  },
};

export default config;
