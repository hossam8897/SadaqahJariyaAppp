/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Clock, 
  Compass, 
  MapPin, 
  Calendar, 
  Bell, 
  BellOff, 
  Volume2, 
  VolumeX, 
  AlertCircle,
  HelpCircle,
  Sun,
  Moon
} from 'lucide-react';
import { defaultCitiesData, getHijriDate, getArabicTimeCountdown, getPrayerArabicName } from '../utils/helpers';

export default function PrayerTools({ darkMode }: { darkMode: boolean }) {
  const [selectedCity, setSelectedCity] = useState('مكة المكرمة');
  const [adhanEnabled, setAdhanEnabled] = useState(true);
  const [remindersEnabled, setRemindersEnabled] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());
  
  // Qibla orientation states
  const [qiblaAngle, setQiblaAngle] = useState(215); // standard Mecca qibla angle from Cairo
  const [compassHeading, setCompassHeading] = useState(0); // device orientation if available

  // Tick the clock every second to keep countdown absolutely real-time
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Listen for device orientation to rotate the Qibla compass needle realistically on mobile
  useEffect(() => {
    const handleOrientation = (e: DeviceOrientationEvent) => {
      if (e.alpha !== null) {
        setCompassHeading(Math.floor(e.alpha));
      }
    };

    window.addEventListener('deviceorientation', handleOrientation, true);
    return () => {
      window.removeEventListener('deviceorientation', handleOrientation, true);
    };
  }, []);

  const cityTimes = defaultCitiesData[selectedCity] || defaultCitiesData['مكة المكرمة'];

  // Identify what the next prayer is and compute countdown
  const getNextPrayerInfo = () => {
    const hours = currentTime.getHours();
    const minutes = currentTime.getMinutes();
    const currentMins = hours * 60 + minutes;

    const prayerMins = Object.entries(cityTimes).map(([key, value]) => {
      const [h, m] = value.split(':').map(Number);
      return { key, mins: h * 60 + m, timeStr: value };
    });

    // Sort by chronological order
    prayerMins.sort((a, b) => a.mins - b.mins);

    // Find first prayer that is later than current time
    let next = prayerMins.find(p => p.mins > currentMins);
    
    // If none found, it means we are past Isha, so next is tomorrow's Fajr
    if (!next) {
      next = prayerMins.find(p => p.key === 'fajr');
    }

    if (!next) return { name: '', countdownText: '', activeKey: '' };

    const countdownText = getArabicTimeCountdown(next.timeStr);
    return {
      name: getPrayerArabicName(next.key),
      countdownText,
      activeKey: next.key
    };
  };

  const { name: nextPrayerName, countdownText: nextPrayerCountdown, activeKey: nextPrayerKey } = getNextPrayerInfo();
  const { text: hijriDateText, events: hijriEvents } = getHijriDate();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-right">
      
      {/* Header */}
      <div className="text-center mb-10">
        <h2 className="font-quran text-3xl font-extrabold text-[#D4AF37] mb-2">المواقيت وأدوات الصلاة</h2>
        <p className={`text-sm ${darkMode ? 'text-gray-300' : 'text-emerald-900'} max-w-xl mx-auto`}>
          احصل على مواقيت دقيقة للصلاة وبوصلة القبلة التفاعلية واتجاه الكعبة، مع عرض التقويم الهجري والمناسبات الإسلامية الهامة.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left column: Cities list and Prayer Times Grid */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Controls: City Selector & Notifications triggers */}
          <div className={`p-5 rounded-2xl border flex flex-col sm:flex-row justify-between items-center gap-4 ${
            darkMode ? 'glass-card-dark' : 'glass-card-light'
          }`}>
            {/* City Selector */}
            <div className="flex items-center gap-3 w-full sm:w-auto justify-start">
              <MapPin className="w-5 h-5 text-[#D4AF37]" />
              <span className="text-xs font-bold text-gray-400">البلد والمدينة:</span>
              <select
                value={selectedCity}
                onChange={(e) => setSelectedCity(e.target.value)}
                className={`text-sm px-3 py-1.5 rounded-lg border focus:outline-none focus:ring-1 focus:ring-[#D4AF37] ${
                  darkMode ? 'bg-emerald-950 border-[#D4AF37]/20 text-[#D4AF37]' : 'bg-slate-50 border-emerald-100 text-emerald-950'
                }`}
              >
                {Object.keys(defaultCitiesData).map((city) => (
                  <option key={city} value={city}>{city}</option>
                ))}
              </select>
            </div>

            {/* Notification and Adhan Switches */}
            <div className="flex gap-4 w-full sm:w-auto justify-end">
              {/* Adhan Sounds Toggle */}
              <button
                onClick={() => setAdhanEnabled(!adhanEnabled)}
                className={`p-2 rounded-lg border flex items-center gap-2 text-xs font-bold transition-colors cursor-pointer ${
                  adhanEnabled 
                    ? 'bg-emerald-500/10 text-[#D4AF37] border-[#D4AF37]/20' 
                    : 'border-transparent text-gray-400'
                }`}
              >
                {adhanEnabled ? <Volume2 className="w-4 h-4 text-[#D4AF37]" /> : <VolumeX className="w-4 h-4" />}
                <span>صوت الأذان {adhanEnabled ? 'مفعّل' : 'ملغى'}</span>
              </button>

              {/* Reminders Toggle */}
              <button
                onClick={() => setRemindersEnabled(!remindersEnabled)}
                className={`p-2 rounded-lg border flex items-center gap-2 text-xs font-bold transition-colors cursor-pointer ${
                  remindersEnabled 
                    ? 'bg-emerald-500/10 text-[#D4AF37] border-[#D4AF37]/20' 
                    : 'border-transparent text-gray-400'
                }`}
              >
                {remindersEnabled ? <Bell className="w-4 h-4 text-[#D4AF37]" /> : <BellOff className="w-4 h-4" />}
                <span>التذكيرات {remindersEnabled ? 'مفعلة' : 'ملغاة'}</span>
              </button>
            </div>
          </div>

          {/* Countdown & Live Clock Banner */}
          <div className="bg-gradient-to-r from-emerald-950 via-[#0a2015] to-[#07130e] border border-[#D4AF37]/20 rounded-2xl p-6 text-center text-white relative overflow-hidden">
            <div className="absolute inset-0 islamic-pattern-dense opacity-[0.02]" />
            <div className="relative z-10">
              <span className="text-[10px] text-[#D4AF37] border border-[#D4AF37]/20 px-3 py-1 rounded-full bg-emerald-500/10 font-bold mb-3 inline-block">
                الصلاة القادمة: {nextPrayerName}
              </span>
              <h3 className="font-sans text-3xl font-extrabold text-[#D4AF37] mb-1">
                {nextPrayerCountdown}
              </h3>
              <p className="text-[11px] text-gray-400 font-mono">توقيت الساعة الآن: {currentTime.toLocaleTimeString('ar-SA')}</p>
            </div>
          </div>

          {/* Grid of Prayer times */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
            {Object.entries(cityTimes).map(([key, time]) => {
              const isActive = key === nextPrayerKey;
              return (
                <div
                  key={key}
                  className={`p-4 rounded-xl border text-center flex flex-col justify-between min-h-28 transition-all ${
                    isActive 
                      ? 'bg-[#D4AF37]/15 border-[#D4AF37] shadow-md shadow-[#D4AF37]/5 scale-105 backdrop-blur-sm' 
                      : darkMode ? 'bg-white/5 border-white/10 text-white' : 'bg-white/60 border-emerald-50 text-emerald-950 backdrop-blur-sm'
                  }`}
                >
                  <div className="text-xs font-bold text-gray-400">{getPrayerArabicName(key)}</div>
                  
                  {/* Icon representations for visual cues */}
                  <div className="my-2 flex justify-center">
                    {key === 'fajr' || key === 'isha' ? (
                      <Moon className={`w-5 h-5 ${isActive ? 'text-[#D4AF37]' : 'text-gray-600'}`} />
                    ) : (
                      <Sun className={`w-5 h-5 ${isActive ? 'text-[#D4AF37]' : 'text-amber-500'}`} />
                    )}
                  </div>

                  <div className={`text-base font-bold font-mono ${isActive ? 'text-[#D4AF37]' : darkMode ? 'text-white' : 'text-emerald-950'}`}>
                    {time}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Hijri Calendar Events section */}
          <div className={`p-5 rounded-2xl border text-right ${
            darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950'
          }`}>
            <h3 className={`text-sm font-bold mb-4 flex items-center gap-2 border-b border-[#D4AF37]/10 pb-2 ${darkMode ? 'text-[#D4AF37]' : 'text-emerald-950'}`}>
              <Calendar className="w-5 h-5 text-[#D4AF37]" />
              <span>التقويم الهجري وأهم المناسبات الإسلامية</span>
            </h3>

            <div className="flex flex-col sm:flex-row justify-between items-center gap-4 bg-emerald-500/5 p-4 rounded-xl border border-[#D4AF37]/10 mb-4">
              <div>
                <div className="text-xs text-gray-400 mb-0.5">التاريخ الهجري اليوم:</div>
                <div className="text-base font-bold text-[#D4AF37]">{hijriDateText}</div>
              </div>
              <div>
                <div className="text-xs text-gray-400 mb-0.5">التاريخ الميلادي الموافق:</div>
                <div className="text-sm font-bold font-mono text-gray-300">{new Date().toLocaleDateString('ar-EG', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</div>
              </div>
            </div>

            <div className="space-y-2">
              <h4 className="text-xs font-bold text-gray-400">مناسبات ومواقيت مباركة مقبلة:</h4>
              {hijriEvents.length > 0 ? (
                hijriEvents.map((evt, idx) => (
                  <div key={idx} className="p-3 rounded-lg bg-emerald-600/10 text-emerald-400 border border-[#D4AF37]/10 text-xs font-semibold leading-relaxed">
                    {evt}
                  </div>
                ))
              ) : (
                <div className="space-y-2 text-xs">
                  <div className="p-3 rounded-lg bg-emerald-500/5 border border-emerald-500/10 flex justify-between items-center text-gray-300">
                    <span>شهر محرم الحرام - رأس السنة الهجرية الجديدة</span>
                    <span className="font-semibold text-[#D4AF37]">١ محرم ١٤٤٨ هـ</span>
                  </div>
                  <div className="p-3 rounded-lg bg-emerald-500/5 border border-emerald-500/10 flex justify-between items-center text-gray-300">
                    <span>يوم عاشوراء المبارك (صيام مستحب)</span>
                    <span className="font-semibold text-[#D4AF37]">١٠ محرم ١٤٤٨ هـ</span>
                  </div>
                  <div className="p-3 rounded-lg bg-emerald-500/5 border border-emerald-500/10 flex justify-between items-center text-gray-300">
                    <span>المولد النبوي الشريف ﷺ</span>
                    <span className="font-semibold text-[#D4AF37]">١٢ ربيع الأول ١٤٤٨ هـ</span>
                  </div>
                </div>
              )}
            </div>
          </div>

        </div>

        {/* Right column: Beautiful Qibla Compass */}
        <div className="lg:col-span-1">
          
          <div className={`p-6 rounded-2xl border text-center h-full flex flex-col justify-between items-center relative overflow-hidden ${
            darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950'
          }`}>
            <div className="absolute inset-0 islamic-pattern opacity-[0.03] pointer-events-none" />

            <div className="relative z-10 w-full mb-4">
              <h3 className={`text-sm font-bold flex items-center gap-1.5 justify-center mb-1 ${darkMode ? 'text-[#D4AF37]' : 'text-emerald-950'}`}>
                <Compass className="w-5 h-5 text-[#D4AF37]" />
                <span>مؤشر اتجاه القبلة</span>
              </h3>
              <p className="text-[10px] text-gray-400">احسب زاوية القبلة لاتجاه الكعبة المشرفة بدقة</p>
            </div>

            {/* Simulated interactive compass */}
            <div className="relative w-56 h-56 flex items-center justify-center my-6">
              
              {/* Compass Dial Outer Circle */}
              <div className="absolute inset-0 rounded-full border-2 border-dashed border-[#D4AF37]/30 flex items-center justify-center animate-pulse" />
              
              {/* Compass Card Background */}
              <div 
                className="w-48 h-48 rounded-full bg-emerald-950/40 border border-[#D4AF37]/30 flex items-center justify-center relative transition-transform duration-300"
                style={{ transform: `rotate(${-compassHeading}deg)` }}
              >
                {/* Cardinal directions */}
                <span className="absolute top-1 text-xs font-bold font-sans text-red-500">N (الشمال)</span>
                <span className="absolute bottom-1 text-[10px] font-bold text-gray-400">S (الجنوب)</span>
                <span className="absolute right-1 text-[10px] font-bold text-gray-400">E (الشرق)</span>
                <span className="absolute left-1 text-[10px] font-bold text-gray-400">W (الغرب)</span>
                
                {/* Mecca Angle Watermark */}
                <div className="absolute top-[21%] right-[22%] text-[9px] font-bold text-[#D4AF37]/30">القبلة (٢١٥°)</div>

                {/* Simulated center marker */}
                <div className="w-4 h-4 rounded-full bg-emerald-900 border border-[#D4AF37] z-20" />
              </div>

              {/* Real Qibla Arrow Pointer (Points always to Qibla angle 215°) */}
              <div 
                className="absolute inset-0 flex items-center justify-center pointer-events-none transition-transform duration-500"
                style={{ transform: `rotate(${qiblaAngle - compassHeading}deg)` }}
              >
                {/* Elegant Golden Pointer Arrow */}
                <div className="relative h-44 w-1 flex items-center justify-center">
                  {/* Top Arrow Tip (pointing to Mecca) */}
                  <div className="absolute top-0 w-4 h-4 border-t-4 border-r-4 border-yellow-400 rotate-[-45deg]" />
                  {/* Upper Golden bar */}
                  <div className="absolute top-0 bottom-1/2 w-0.5 bg-gradient-to-b from-yellow-400 to-[#D4AF37]" />
                  {/* Indicator Label */}
                  <div className="absolute top-8 bg-emerald-900/90 border border-yellow-400/50 text-[8px] font-bold text-yellow-400 px-1.5 py-0.5 rounded-full whitespace-nowrap shadow-md">القبلة للكعبة</div>
                </div>
              </div>

            </div>

            <div className="relative z-10 w-full mt-4">
              <div className="text-xs bg-emerald-500/5 border border-[#D4AF37]/10 p-3 rounded-xl text-emerald-300 font-semibold mb-2">
                زاوية القبلة المقدرة: <span className="font-mono text-[#D4AF37] font-bold">٢١٥.٤°</span> باتجاه جنوب الشرق
              </div>
              <div className="flex gap-2 text-[10px] text-gray-400 justify-center">
                <AlertCircle className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                <span>على الهواتف المحمولة، قم بتفعيل ميزة البوصلة وسيقوم المؤشر بالدوران تلقائياً باتجاه القبلة الفعلي.</span>
              </div>
            </div>

          </div>

        </div>

      </div>

    </div>
  );
}
