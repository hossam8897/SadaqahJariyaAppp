/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PrayerTimeData } from '../types';

// Standard static prayer times for fallback by city
export const defaultCitiesData: Record<string, Omit<PrayerTimeData, 'date' | 'hijriDate'>> = {
  'مكة المكرمة': { fajr: '04:22', sunrise: '05:44', dhuhr: '12:28', asr: '15:43', maghrib: '19:12', isha: '20:42' },
  'القاهرة': { fajr: '03:18', sunrise: '04:58', dhuhr: '12:01', asr: '15:39', maghrib: '19:04', isha: '20:34' },
  'الرياض': { fajr: '03:46', sunrise: '05:10', dhuhr: '11:58', asr: '15:19', maghrib: '18:45', isha: '20:15' },
  'عمان': { fajr: '03:49', sunrise: '05:32', dhuhr: '12:35', asr: '16:15', maghrib: '19:38', isha: '21:08' },
  'القدس': { fajr: '03:52', sunrise: '05:35', dhuhr: '12:38', asr: '16:18', maghrib: '19:41', isha: '21:11' }
};

export function getHijriDate(): { text: string; events: string[] } {
  // Simple Arabic-Hijri approximation for standard dates (adjusts reasonably)
  const today = new Date();
  
  // Custom formula or direct Intl usage
  try {
    const formatter = new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
    const formatted = formatter.format(today);
    
    // Check if there are important Islamic events around current Hijri months
    // e.g. Ramadan, Eid, Ashura, Mawlid
    const events: string[] = [];
    if (formatted.includes('رمضان')) {
      events.push('شهر رمضان المبارك - شهر الرحمة والغفران والقرآن');
    } else if (formatted.includes('ذو الحجة')) {
      events.push('شهر ذي الحجة - موسم الحج وعيد الأضحى المبارك');
    } else if (formatted.includes('شوال')) {
      events.push('شهر شوال - عيد الفطر السعيد');
    } else if (formatted.includes('محرم')) {
      events.push('شهر محرم الحرام - رأس السنة الهجرية وذكرى عاشوراء');
    } else if (formatted.includes('ربيع الأول')) {
      events.push('شهر ربيع الأول - ذكرى المولد النبوي الشريف ﷺ');
    }

    return { text: formatted, events };
  } catch (e) {
    // Fallback if Intl is not fully supported for UmAlQura calendar in this container
    return { 
      text: "٢٣ ذو الحجة ١٤٤٧ هـ", 
      events: ["شهر ذي الحجة الحرام - نسأل الله الرحمة والمغفرة لفقيدنا عبدالناصر عمران"] 
    };
  }
}

export function copyToClipboard(text: string): Promise<boolean> {
  return navigator.clipboard.writeText(text)
    .then(() => true)
    .catch(() => {
      // Fallback
      const textArea = document.createElement("textarea");
      textArea.value = text;
      textArea.style.position = "fixed";
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      try {
        document.execCommand('copy');
        document.body.removeChild(textArea);
        return true;
      } catch (err) {
        document.body.removeChild(textArea);
        return false;
      }
    });
}

export function getArabicTimeCountdown(nextTimeStr: string): string {
  if (!nextTimeStr) return "";
  
  const now = new Date();
  const [hours, minutes] = nextTimeStr.split(":").map(Number);
  
  const target = new Date();
  target.setHours(hours, minutes, 0, 0);
  
  if (target < now) {
    target.setDate(target.getDate() + 1); // tomorrow
  }
  
  const diffMs = target.getTime() - now.getTime();
  const diffHrs = Math.floor(diffMs / (1000 * 60 * 60));
  const diffMins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
  
  if (diffHrs === 0) {
    return `متبقي ${diffMins} دقيقة`;
  }
  return `متبقي ${diffHrs} ساعة و ${diffMins} دقيقة`;
}

export function getPrayerArabicName(key: string): string {
  const names: Record<string, string> = {
    fajr: 'الفجر',
    sunrise: 'الشروق',
    dhuhr: 'الظهر',
    asr: 'العصر',
    maghrib: 'المغرب',
    isha: 'العشاء'
  };
  return names[key] || key;
}
