/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Award, 
  Search, 
  Heart, 
  Share2, 
  Copy, 
  RefreshCw, 
  Check, 
  Eye, 
  Plus, 
  Minus,
  Info,
  Sparkles,
  BookMarked,
  Bell,
  CheckCircle,
  HelpCircle,
  TrendingUp
} from 'lucide-react';
import { azkarData as baseAzkarData } from '../data/islamicData';
import { copyToClipboard } from '../utils/helpers';
import { AzkarItem } from '../types';
import { getAzkar } from '../utils/firebase';

// Complete Azkar Library items covering all 13 required categories
const fullAzkarList: AzkarItem[] = [
  ...baseAzkarData, // Includes some morning, evening, sleep, and prayer items
  
  // Waking Up (أذكار الاستيقاظ)
  {
    id: 'wk1',
    category: 'waking',
    text: 'الْحَمْدُ للهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ.',
    count: 1,
    description: 'يقال فور الاستيقاظ من النوم مباشرة'
  },
  {
    id: 'wk2',
    category: 'waking',
    text: 'الحمد لله الذي عافاني في جسدي، وردّ عليّ روحي، وأذن لي بذكره.',
    count: 1,
    description: 'شكر النعمة ورد الروح'
  },

  // Home In/Out (أذكار دخول وخروج المنزل)
  {
    id: 'h_out',
    category: 'home_in_out',
    text: 'بِسْمِ اللَّهِ، تَوَكَّلْتُ عَلَى اللَّهِ، وَلا حَوْلَ وَلا قُوَّةَ إِلاَّ بِاللَّهِ.',
    count: 1,
    reward: 'يقال له: كُفيت وهُديت ووُقيت، وتنحى عنه الشيطان.',
    description: 'عند الخروج من المنزل'
  },
  {
    id: 'h_in',
    category: 'home_in_out',
    text: 'بِسْمِ اللهِ وَلَجْنَا، وَبِسْمِ اللهِ خَرَجْنَا، وَعَلَى اللهِ رَبِّنَا تَوَكَّلْنَا، ثُمَّ لِيُسَلِّمْ عَلَى أَهْلِهِ.',
    count: 1,
    description: 'عند دخول المنزل'
  },

  // Mosque (أذكار المسجد)
  {
    id: 'mq_in',
    category: 'mosque',
    text: 'أَعوذُ باللهِ العَظيمِ، وَبِوَجْهِهِ الكَريمِ، وَسُلْطانِهِ القَديمِ، مِنَ الشّيْطانِ الرَّجيمِ. بِسْمِ اللهِ، وَالصَّلَاةُ وَالسَّلَامُ عَلَى رَسُولِ اللهِ، اللَّهُمَّ افْتَحْ لِي أَبْوَابَ رَحْمَتِكَ.',
    count: 1,
    description: 'عند دخول المسجد'
  },
  {
    id: 'mq_out',
    category: 'mosque',
    text: 'بِسْمِ اللهِ، وَالصَّلَاةُ وَالسَّلَامُ عَلَى رَسُولِ اللهِ، اللَّهُمَّ إِنِّي أَسْأَلُكَ مِنْ فَضْلِكَ، اللَّهُمَّ اعْصِمْنِي مِنَ الشَّيْطَانِ الرَّجِيمِ.',
    count: 1,
    description: 'عند الخروج من المسجد'
  },

  // Food (أذكار الطعام)
  {
    id: 'fd1',
    category: 'food',
    text: 'بِسْمِ اللهِ (وإذا نسي في أوله): بِسْمِ اللهِ فِي أَوَّلِهِ وَآخِرِهِ.',
    count: 1,
    description: 'عند بدء الطعام'
  },
  {
    id: 'fd2',
    category: 'food',
    text: 'الْحَمْدُ للهِ الَّذِي أَطْعَمَنِي هَذَا الطَّعَامَ وَرَزَقَنِيهِ مِنْ غَيْرِ حَوْلٍ مِنِّي وَلَا قُوَّةٍ.',
    count: 1,
    reward: 'غُفِرَ له ما تقدّم من ذنبه.',
    description: 'عند الانتهاء من الطعام'
  },

  // Travel (أذكار السفر)
  {
    id: 'tr1',
    category: 'travel',
    text: 'الله أكبر، الله أكبر، الله أكبر، سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ * وَإِنَّا إِلَى رَبِّي لَمُنْقَلِبُونَ. اللهم إنا نسألك في سفرنا هذا البر والتقوى، ومن العمل ما ترضى.',
    count: 1,
    description: 'دعاء السفر والركوب'
  },

  // Sickness (أذكار المرض)
  {
    id: 'sk1',
    category: 'sickness',
    text: 'أعوذ بعزة الله وقدرته من شر ما أجد وأحاذر.',
    count: 7,
    description: 'يضع يده على موضع الألم ويقولها سبع مرات بعد البسملة ثلاثاً'
  },
  {
    id: 'sk2',
    category: 'sickness',
    text: 'اللهم رب الناس أذهب البأس، اشفِ أنت الشافي لا شفاء إلا شفاؤك، شفاءً لا يغادر سقماً.',
    count: 3,
    description: 'دعاء عيادة المريض وطلب الشفاء'
  },

  // Ruqyah (الرقية الشرعية كاملة)
  {
    id: 'rq1',
    category: 'ruqyah',
    text: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ * الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ * الرَّحْمَٰنِ الرَّحِيمِ * مَالِكِ يَوْمِ الدِّينِ * إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ * اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ * صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ.',
    count: 3,
    description: 'سورة الفاتحة (شافية وكافية)'
  },
  {
    id: 'rq2',
    category: 'ruqyah',
    text: 'اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَّهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ ۗ مَن ذَا الَّذِي يَشْفَعُ عِندَهُ إِلَّا بِإِذْنِهِ ۚ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ ۖ وَلَا يُحِيطُونَ بِشَيْءٍ مِّنْ عِلْمِهِ إِلَّا بِمَا شَاءَ ۚ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ ۖ وَلَا يَؤُودُهُ حِفْظُهُمَا ۚ وَهُوَ الْعَلِيُّ الْعَظِيمُ.',
    count: 1,
    description: 'آية الكرسي (تحصين من الشيطان)'
  },
  {
    id: 'rq3',
    category: 'ruqyah',
    text: 'قُلْ هُوَ اللَّهُ أَحَدٌ * اللَّهُ الصَّمَدُ * لَمْ يَلِدْ وَلَمْ يُولَدْ * وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ. (مع قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ وَقُلْ أَعُوذُ بِرَبِّ النَّاسِ).',
    count: 3,
    description: 'المعوذات الثلاث للمساء والصباح والنوم والرقية'
  },

  // Friday (أذكار الجمعة)
  {
    id: 'fr1',
    category: 'friday',
    text: 'اللَّهُمَّ صَلِّ وَسَلِّمْ وَبَارِكْ عَلَى نَبِيِّنَا مُحَمَّدٍ.',
    count: 100,
    reward: 'من صلى علي صلاة صلى الله عليه بها عشراً.',
    description: 'الصلاة الإبراهيمية المباركة يوم الجمعة'
  },
  {
    id: 'fr2',
    category: 'friday',
    text: 'أستغفر الله العظيم الذي لا إله إلا هو الحي القيوم وأتوب إليه.',
    count: 100,
    description: 'الاستغفار الممحص للذنوب والأوراد والخطايا'
  },

  // Ramadan (أذكار رمضان)
  {
    id: 'rm1',
    category: 'ramadan',
    text: 'ذهب الظمأ وابتلت العروق وثبت الأجر إن شاء الله.',
    count: 1,
    description: 'يقال عند الإفطار مباشرة'
  },
  {
    id: 'rm2',
    category: 'ramadan',
    text: 'اللهم إنك عفو تحب العفو فاعف عني.',
    count: 10,
    reward: 'دعاء ليلة القدر المباركة لطلب الصفح الجميل.',
    description: 'دعاء العشر الأواخر من رمضان'
  }
];

export default function AzkarLibrary({ darkMode }: { darkMode: boolean }) {
  const [azkarList, setAzkarList] = useState<AzkarItem[]>(fullAzkarList);
  const [selectedCategory, setSelectedCategory] = useState<string>('morning');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [azkarCounts, setAzkarCounts] = useState<Record<string, number>>({});
  const [favorites, setFavorites] = useState<string[]>([]);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [fontSize, setFontSize] = useState<number>(18); // default text size

  // Global completion celebration trigger
  const [celebrationToast, setCelebrationToast] = useState<string | null>(null);

  // Reading Focus Mode State
  const [isFocusMode, setIsFocusMode] = useState<boolean>(false);
  const [activeFocusIdx, setActiveFocusIdx] = useState<number>(0);

  // 13 Required Categories mapping
  const categoriesList = [
    { id: 'morning', label: '🌅 أذكار الصباح كاملة' },
    { id: 'evening', label: '🌆 أذكار المساء كاملة' },
    { id: 'sleep', label: '🛌 أذكار النوم' },
    { id: 'waking', label: '🌤️ أذكار الاستيقاظ' },
    { id: 'prayer', label: '🕌 بعد الصلاة' },
    { id: 'home_in_out', label: '🚪 دخول وخروج المنزل' },
    { id: 'mosque', label: '🕌 أذكار المسجد' },
    { id: 'food', label: '🍽️ أذكار الطعام' },
    { id: 'travel', label: '✈️ أذكار السفر' },
    { id: 'sickness', label: '🩺 أذكار المرض' },
    { id: 'ruqyah', label: '🛡️ الرقية الشرعية كاملة' },
    { id: 'friday', label: '📿 أذكار الجمعة' },
    { id: 'ramadan', label: '🌙 أذكار رمضان' },
    { id: 'favorites', label: '❤️ أذكاري المحفوظة' }
  ];

  // Load favorites from storage and load firestore azkar
  useEffect(() => {
    const saved = localStorage.getItem('sadaqah_azkar_favorites');
    if (saved) setFavorites(JSON.parse(saved));

    getAzkar().then(data => {
      if (data && data.length > 0) {
        setAzkarList(data);
      }
    });
  }, []);

  // Sync state counts on category change
  useEffect(() => {
    // prefill default counts if empty
    const counts: Record<string, number> = { ...azkarCounts };
    let altered = false;
    azkarList.forEach(item => {
      if (counts[item.id] === undefined) {
        counts[item.id] = item.count;
        altered = true;
      }
    });
    if (altered) {
      setAzkarCounts(counts);
    }
  }, [selectedCategory, azkarList]);

  const handleZikrClick = (id: string, originalCount: number) => {
    const current = azkarCounts[id] ?? originalCount;
    if (current > 0) {
      const nextVal = current - 1;
      setAzkarCounts(prev => ({ ...prev, [id]: nextVal }));

      // Soft sound/vibe feedback
      if (navigator.vibrate) {
        navigator.vibrate(30);
      }

      // Check if this was the last rep
      if (nextVal === 0) {
        setCelebrationToast('✨ بارك الله فيك! تم إكمال هذا الذكر بنجاح.');
        setTimeout(() => setCelebrationToast(null), 2500);
      }
    }
  };

  const handleResetCounts = (catId: string) => {
    const nextCounts = { ...azkarCounts };
    azkarList.forEach(item => {
      if (item.category === catId) {
        nextCounts[item.id] = item.count;
      }
    });
    setAzkarCounts(nextCounts);
    setCelebrationToast('🔄 تم إعادة تصفير عدّادات هذا القسم بنجاح.');
    setTimeout(() => setCelebrationToast(null), 2500);
  };

  const toggleFavorite = (id: string) => {
    let updated;
    if (favorites.includes(id)) {
      updated = favorites.filter(f => f !== id);
    } else {
      updated = [...favorites, id];
    }
    setFavorites(updated);
    localStorage.setItem('sadaqah_azkar_favorites', JSON.stringify(updated));
  };

  const triggerCopy = (text: string, id: string) => {
    copyToClipboard(text).then(() => {
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    });
  };

  // Filter lists
  const activeList = selectedCategory === 'favorites'
    ? azkarList.filter(item => favorites.includes(item.id))
    : azkarList.filter(item => item.category === selectedCategory);

  const finalFilteredList = activeList.filter(item =>
    item.text.includes(searchQuery) || (item.description && item.description.includes(searchQuery))
  );

  // Daily completion calculations
  const categoryTotalItems = activeList.length;
  const categoryCompletedItems = activeList.filter(item => (azkarCounts[item.id] ?? item.count) === 0).length;
  const completionPercentage = categoryTotalItems > 0 
    ? Math.round((categoryCompletedItems / categoryTotalItems) * 100) 
    : 0;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-right relative">
      
      {/* Toast Alert Notification */}
      <AnimatePresence>
        {celebrationToast && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.9 }}
            className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-[#D4AF37] text-emerald-950 font-bold px-6 py-3 rounded-full shadow-2xl flex items-center gap-2 border border-white/20 text-xs sm:text-sm"
          >
            <Bell className="w-4 h-4 text-emerald-950 animate-bounce" />
            <span>{celebrationToast}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header */}
      <div className="text-center mb-10">
        <h2 className="font-quran text-3xl sm:text-4xl font-extrabold text-[#D4AF37] mb-2 leading-tight">
          مكتبة الأذكار المتكاملة وحصن المسلم
        </h2>
        <p className={`text-sm ${darkMode ? 'text-gray-300' : 'text-emerald-900'} max-w-xl mx-auto leading-relaxed`}>
          اقرأ أذكارك اليومية كاملة مع ميزة العداد الذكي، ونظام قياس نسبة الإنجاز والورد اليومي المبارك لروح الوالد عبدالناصر عمران رحمه الله.
        </p>
      </div>

      {/* Completion Dashboard Progress Bar */}
      <div className={`p-5 rounded-2xl border mb-8 flex flex-col sm:flex-row justify-between items-center gap-4 ${
        darkMode ? 'glass-card-dark border-[#D4AF37]/15' : 'glass-card-light shadow-sm'
      }`}>
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="p-2.5 rounded-full bg-[#D4AF37]/10 text-[#D4AF37]">
            <Award className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-[#D4AF37]">نسبة إكمال ورد القسم الحالي</h4>
            <p className="text-[11px] text-gray-500">تم قراءة {categoryCompletedItems} من أصل {categoryTotalItems} أذكار في هذا التصنيف</p>
          </div>
        </div>

        {/* Progress Bar slider */}
        <div className="w-full sm:w-64 space-y-1">
          <div className="flex justify-between text-xs font-mono font-bold">
            <span className="text-[#D4AF37]">{completionPercentage}%</span>
            <span className="text-gray-400">الإنجاز</span>
          </div>
          <div className="w-full bg-gray-500/10 h-2 rounded-full overflow-hidden">
            <div 
              className="bg-gradient-to-r from-[#D4AF37] to-emerald-500 h-full rounded-full transition-all duration-500" 
              style={{ width: `${completionPercentage}%` }}
            />
          </div>
        </div>
      </div>

      {/* Toolbar / Search, Focus, font controls */}
      <div className="flex flex-col lg:flex-row justify-between items-center gap-4 mb-8">
        
        {/* Search */}
        <div className="relative w-full lg:max-w-md">
          <input
            type="text"
            placeholder="ابحث عن أذكار معينة بكلمة رئيسية..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={`w-full py-2.5 pr-12 pl-4 rounded-xl border focus:outline-none focus:ring-2 transition-all text-sm ${
              darkMode 
                ? 'bg-emerald-950/40 border-[#D4AF37]/20 text-white placeholder-emerald-300/40 focus:ring-[#D4AF37]/50' 
                : 'bg-white border-emerald-100 text-emerald-950 focus:ring-emerald-500/50 shadow-sm'
            }`}
          />
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#D4AF37]" />
        </div>

        {/* Actions panel */}
        <div className="flex flex-wrap gap-2 justify-end w-full lg:w-auto text-xs">
          
          {/* Font Controls */}
          <div className="flex items-center gap-1.5 bg-gray-500/10 p-1 rounded-xl border border-gray-500/10">
            <button 
              onClick={() => setFontSize(prev => Math.min(prev + 1, 28))}
              className="p-1 rounded bg-gray-500/10 hover:bg-[#D4AF37]/20 text-gray-300 cursor-pointer"
              title="تكبير الخط"
            >
              <Plus className="w-3 h-3" />
            </button>
            <span className="font-mono text-[10px] text-gray-400 font-bold px-1">{fontSize}px</span>
            <button 
              onClick={() => setFontSize(prev => Math.max(prev - 1, 14))}
              className="p-1 rounded bg-gray-500/10 hover:bg-[#D4AF37]/20 text-gray-300 cursor-pointer"
              title="تصغير الخط"
            >
              <Minus className="w-3 h-3" />
            </button>
          </div>

          <button
            onClick={() => handleResetCounts(selectedCategory)}
            className="px-4 py-2.5 rounded-xl border border-[#D4AF37]/25 text-[#D4AF37] hover:bg-[#D4AF37]/10 transition-colors flex items-center gap-1.5 cursor-pointer font-bold"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>تصفير أذكار القسم</span>
          </button>

          <button
            onClick={() => {
              if (finalFilteredList.length > 0) {
                setIsFocusMode(true);
                setActiveFocusIdx(0);
              }
            }}
            disabled={finalFilteredList.length === 0}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-700 hover:opacity-95 text-white transition-colors flex items-center gap-1.5 disabled:opacity-50 cursor-pointer font-bold"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>وضع التلاوة الهادئ</span>
          </button>
        </div>

      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        {/* Left Side: Category Navigator List (13 categories) */}
        <div className="lg:col-span-1 space-y-3">
          <div className={`p-4 rounded-2xl border ${darkMode ? 'glass-card-dark border-[#D4AF37]/15' : 'glass-card-light shadow-sm'}`}>
            <h3 className="text-xs font-bold text-[#D4AF37] mb-3 pb-2 border-b border-[#D4AF37]/10 flex items-center gap-1">
              <BookMarked className="w-3.5 h-3.5" />
              <span>فئات حصن المسلم</span>
            </h3>

            <div className="space-y-1.5 max-h-[500px] overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-[#D4AF37]">
              {categoriesList.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => {
                    setSelectedCategory(cat.id);
                    setSearchQuery('');
                  }}
                  className={`w-full text-right px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer border ${
                    selectedCategory === cat.id
                      ? 'bg-gradient-to-r from-emerald-900/50 to-[#D4AF37]/15 border-[#D4AF37] text-[#D4AF37]'
                      : darkMode
                        ? 'bg-emerald-950/10 border-transparent text-gray-300 hover:bg-emerald-950/40'
                        : 'bg-white border-transparent text-emerald-950 hover:bg-emerald-50 shadow-sm'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Side: Azkar Cards display */}
        <div className="lg:col-span-3 space-y-4">
          
          {finalFilteredList.length === 0 ? (
            <div className={`p-12 text-center rounded-2xl border ${darkMode ? 'glass-card-dark' : 'glass-card-light'}`}>
              <Info className="w-8 h-8 text-amber-500 mx-auto mb-2" />
              <h4 className="text-sm font-bold">لا توجد أذكار مضافة</h4>
              <p className="text-xs text-gray-400 mt-1">
                {selectedCategory === 'favorites'
                  ? 'انقر على علامة القلب على أي ذكر في الأقسام الأخرى لتجده هنا في مفضلتك الشخصية.'
                  : 'جارٍ تغذية وتجهيز هذا الورد الإسلامي قريباً.'}
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {finalFilteredList.map((item) => {
                const countRemaining = azkarCounts[item.id] ?? item.count;
                const isCompleted = countRemaining === 0;

                return (
                  <motion.div
                    key={item.id}
                    layout
                    className={`p-5 rounded-2xl border transition-all duration-300 flex flex-col md:flex-row justify-between gap-6 relative overflow-hidden ${
                      isCompleted 
                        ? darkMode ? 'bg-emerald-950/10 border-emerald-500/20 opacity-60' : 'bg-emerald-50/50 border-emerald-100 opacity-80'
                        : darkMode ? 'glass-card-dark border-[#D4AF37]/10' : 'glass-card-light shadow-sm'
                    }`}
                  >
                    {/* Zikr Content */}
                    <div className="flex-1 text-right">
                      <div className="flex items-center gap-2 mb-3">
                        <span className="text-[10px] bg-[#D4AF37]/10 text-[#D4AF37] px-2 py-0.5 rounded-full font-bold">
                          {item.description || 'أوراد إسلامية'}
                        </span>
                        {item.reward && (
                          <span className="text-[9px] bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded-full font-semibold">
                            ✨ فضل عظيم
                          </span>
                        )}
                      </div>

                      <p 
                        className="font-quran leading-loose text-emerald-950 dark:text-emerald-100 font-bold mb-4"
                        style={{ fontSize: `${fontSize}px` }}
                      >
                        {item.text}
                      </p>

                      {item.reward && (
                        <div className="text-xs text-gray-400 border-r-2 border-[#D4AF37]/30 pr-3 italic leading-relaxed">
                          {item.reward}
                        </div>
                      )}
                    </div>

                    {/* Interactive digital counter section */}
                    <div className="flex flex-row md:flex-col justify-between items-center md:justify-center gap-4 border-t md:border-t-0 md:border-r border-gray-500/10 pt-4 md:pt-0 md:pr-6 shrink-0 min-w-40">
                      
                      {/* Counter Clicker circle */}
                      <button
                        onClick={() => handleZikrClick(item.id, item.count)}
                        disabled={isCompleted}
                        className={`w-16 h-16 rounded-full flex flex-col items-center justify-center font-bold text-lg font-mono border shadow-sm transition-transform active:scale-95 cursor-pointer relative ${
                          isCompleted 
                            ? 'bg-emerald-500 border-emerald-500 text-white' 
                            : darkMode 
                              ? 'bg-emerald-950 border-[#D4AF37]/30 text-[#D4AF37] hover:bg-[#D4AF37]/10' 
                              : 'bg-emerald-50 border-emerald-100 text-emerald-800 hover:bg-emerald-100'
                        }`}
                      >
                        {isCompleted ? (
                          <Check className="w-8 h-8 text-white animate-bounce" />
                        ) : (
                          <>
                            <span className="text-base font-bold">{countRemaining}</span>
                            <span className="text-[9px] text-gray-400 font-sans">تبقّى</span>
                          </>
                        )}

                        {!isCompleted && (
                          <span className="absolute inset-0 rounded-full border border-dashed border-[#D4AF37]/20 animate-pulse" />
                        )}
                      </button>

                      {/* Controls bar */}
                      <div className="flex gap-1.5">
                        {/* Copy text */}
                        <button
                          onClick={() => triggerCopy(item.text, item.id)}
                          className="p-1.5 rounded-lg border border-[#D4AF37]/15 text-gray-400 hover:bg-[#D4AF37]/10 transition-colors cursor-pointer"
                          title="نسخ الذكر"
                        >
                          {copiedId === item.id ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                        </button>

                        {/* Favorite toggler */}
                        <button
                          onClick={() => toggleFavorite(item.id)}
                          className={`p-1.5 rounded-lg border transition-all cursor-pointer ${
                            favorites.includes(item.id)
                              ? 'bg-rose-500/10 text-rose-500 border-rose-500/30'
                              : 'border-gray-500/15 text-gray-400 hover:bg-gray-500/10'
                          }`}
                          title="حفظ"
                        >
                          <Heart className="w-3 h-3 fill-current" />
                        </button>
                      </div>

                    </div>

                  </motion.div>
                );
              })}
            </div>
          )}

        </div>

      </div>

      {/* FOCUS READING MODE OVERLAY */}
      <AnimatePresence>
        {isFocusMode && finalFilteredList.length > 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-[#020b06] z-50 flex items-center justify-center p-4 sm:p-6 text-right"
          >
            <div className="absolute top-4 right-4 flex gap-3">
              <button
                onClick={() => setIsFocusMode(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-red-600/10 border border-red-500/20 text-red-400 hover:bg-red-500/20 transition-colors cursor-pointer"
              >
                إنهاء وضع التلاوة
              </button>
            </div>

            <div className="max-w-2xl w-full flex flex-col items-center justify-between min-h-[60vh] text-center">
              
              <div className="text-xs font-bold text-[#D4AF37]/80 mb-4 font-mono tracking-wide">
                ورد الذكر: {activeFocusIdx + 1} من أصل {finalFilteredList.length}
              </div>

              {/* Focus remembrance card */}
              <motion.div
                key={activeFocusIdx}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="bg-emerald-950/20 border border-[#D4AF37]/20 p-8 sm:p-10 rounded-3xl w-full relative overflow-hidden"
              >
                <div className="absolute top-0 right-0 p-4 font-quran text-5xl opacity-5 text-[#D4AF37]">﷽</div>
                
                <span className="text-[11px] text-[#D4AF37] px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/25 mb-6 inline-block font-bold">
                  {finalFilteredList[activeFocusIdx].description || 'أوراد مباركة'}
                </span>

                <p className="font-quran text-xl sm:text-2xl md:text-3xl leading-relaxed text-emerald-100 font-semibold mb-6">
                  {finalFilteredList[activeFocusIdx].text}
                </p>

                {finalFilteredList[activeFocusIdx].reward && (
                  <p className="text-xs text-amber-300/80 italic border-t border-gray-500/10 pt-4 max-w-lg mx-auto">
                    {finalFilteredList[activeFocusIdx].reward}
                  </p>
                )}

                {/* Counter inside Focus overlay */}
                <div className="mt-8 flex justify-center">
                  <button
                    onClick={() => {
                      const item = finalFilteredList[activeFocusIdx];
                      handleZikrClick(item.id, item.count);
                    }}
                    className={`w-20 h-20 rounded-full flex flex-col items-center justify-center font-mono border transition-all duration-300 active:scale-95 cursor-pointer ${
                      (azkarCounts[finalFilteredList[activeFocusIdx].id] ?? finalFilteredList[activeFocusIdx].count) === 0
                        ? 'bg-emerald-500 border-emerald-500 text-white'
                        : 'bg-emerald-950/60 border-[#D4AF37] text-[#D4AF37] hover:bg-[#D4AF37]/10'
                    }`}
                  >
                    {(azkarCounts[finalFilteredList[activeFocusIdx].id] ?? finalFilteredList[activeFocusIdx].count) === 0 ? (
                      <Check className="w-8 h-8 text-white animate-bounce" />
                    ) : (
                      <>
                        <span className="text-xl font-bold">
                          {azkarCounts[finalFilteredList[activeFocusIdx].id] ?? finalFilteredList[activeFocusIdx].count}
                        </span>
                        <span className="text-[9px] text-gray-400">انقر هنا</span>
                      </>
                    )}
                  </button>
                </div>

              </motion.div>

              {/* Slider Controls */}
              <div className="flex gap-4 mt-8 w-full justify-center">
                <button
                  onClick={() => setActiveFocusIdx(p => Math.max(0, p - 1))}
                  disabled={activeFocusIdx === 0}
                  className="px-5 py-2 border border-[#D4AF37]/20 text-[#D4AF37] rounded-xl text-xs font-bold disabled:opacity-30 cursor-pointer"
                >
                  الذكر السابق
                </button>
                <button
                  onClick={() => {
                    if (activeFocusIdx + 1 < finalFilteredList.length) {
                      setActiveFocusIdx(p => p + 1);
                    } else {
                      setIsFocusMode(false);
                      setCelebrationToast('🎉 هنيئاً لك! لقد أتممت ورد الأذكار كاملاً.');
                      setTimeout(() => setCelebrationToast(null), 3000);
                    }
                  }}
                  className="px-6 py-2 bg-gradient-to-r from-amber-500 to-[#D4AF37] text-emerald-950 rounded-xl text-xs font-bold cursor-pointer"
                >
                  {activeFocusIdx + 1 === finalFilteredList.length ? 'أتممت الورد بنجاح' : 'الذكر التالي'}
                </button>
              </div>

            </div>

          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
