/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Tv, 
  MapPin, 
  Volume2, 
  VolumeX, 
  Video, 
  Sparkles, 
  AlertCircle,
  HelpCircle,
  Images
} from 'lucide-react';

export default function LiveContent({ darkMode }: { darkMode: boolean }) {
  const [activeStream, setActiveStream] = useState<'makkah' | 'madinah'>('makkah');
  const [useBackupMode, setUseBackupMode] = useState(false);

  // Free public embed channels for Saudi Quran and Sunnah streams
  const streams = {
    makkah: {
      title: 'البث المباشر للقناة السعودية للقرآن الكريم (الحرم المكي)',
      embedUrl: 'https://www.youtube.com/embed/l88I5mN7Eig', // standard embed for Saudi Quran TV
      location: 'مكة المكرمة، المملكة العربية السعودية',
      backupImage: 'https://images.unsplash.com/photo-1564507592333-c60657eea523?q=80&w=1000&auto=format&fit=crop', // Stunning Kaaba image
      desc: 'بث مباشر على مدار الساعة للمسجد الحرام والكعبة المشرفة وحركة الطواف، يتخللها تلاوات عطرة لكبار القراء الأفاضل.'
    },
    madinah: {
      title: 'البث المباشر لقناة السنة النبوية الشريفة (المسجد النبوي)',
      embedUrl: 'https://www.youtube.com/embed/zI06869KxDo', // Saudi Sunnah TV
      location: 'المدينة المنورة، المملكة العربية السعودية',
      backupImage: 'https://images.unsplash.com/photo-1591604129939-f1efa4d9f7fa?q=80&w=1000&auto=format&fit=crop', // Beautiful Madinah Dome image
      desc: 'بث مباشر وحي من الروضة الشريفة والمسجد النبوي بالمدينة المنورة، لنقل الصلوات وخطب الجمعة والأحاديث الشريفة.'
    }
  };

  const current = streams[activeStream];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-right">
      
      {/* Header */}
      <div className="text-center mb-10">
        <h2 className="font-quran text-3xl font-extrabold text-[#D4AF37] mb-2">البث الإسلامي المباشر</h2>
        <p className={`text-sm ${darkMode ? 'text-gray-300' : 'text-emerald-900'} max-w-xl mx-auto`}>
          شاهد بثاً حياً ومباشراً على مدار الساعة من الحرمين الشريفين لتنعم بنسمات الطمأنينة وتتابع الصلوات المكتوبة والسنن من مكة والمدينة.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        {/* Stream Info / Control panel (Left side on Desktop, top on Mobile) */}
        <div className="lg:col-span-1 space-y-6 order-2 lg:order-1">
          
          {/* Quick Stream selectors */}
          <div className={`p-5 rounded-2xl border text-right ${
            darkMode ? 'glass-card-dark' : 'glass-card-light'
          }`}>
            <h3 className="text-xs font-bold text-gray-400 mb-3">اختر القناة المباشرة:</h3>
            <div className="space-y-3">
              <button
                onClick={() => setActiveStream('makkah')}
                className={`w-full text-right p-3 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                  activeStream === 'makkah'
                    ? 'bg-[#D4AF37]/10 border-[#D4AF37] text-[#D4AF37]'
                    : darkMode ? 'bg-emerald-950/20 border-transparent text-gray-300' : 'bg-slate-50 border-transparent text-emerald-950'
                }`}
              >
                <div>
                  <div className="text-xs font-bold">🕋 بث الحرم المكي الشريف</div>
                  <div className="text-[9px] text-gray-400 mt-0.5">مكة المكرمة</div>
                </div>
              </button>

              <button
                onClick={() => setActiveStream('madinah')}
                className={`w-full text-right p-3 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                  activeStream === 'madinah'
                    ? 'bg-[#D4AF37]/10 border-[#D4AF37] text-[#D4AF37]'
                    : darkMode ? 'bg-emerald-950/20 border-transparent text-gray-300' : 'bg-slate-50 border-transparent text-emerald-950'
                }`}
              >
                <div>
                  <div className="text-xs font-bold">🕌 بث المسجد النبوي الشريف</div>
                  <div className="text-[9px] text-gray-400 mt-0.5">المدينة المنورة</div>
                </div>
              </button>
            </div>
          </div>

          {/* Toggle fallback slide view */}
          <div className={`p-5 rounded-2xl border text-right ${
            darkMode ? 'glass-card-dark' : 'glass-card-light'
          }`}>
            <h4 className="text-xs font-bold text-[#D4AF37] mb-2 flex items-center gap-1.5">
              <Images className="w-4 h-4" />
              <span>وضع المعايشة الهادئة</span>
            </h4>
            <p className="text-[10px] text-gray-400 leading-relaxed mb-3">إذا كانت سرعة الإنترنت لديك لا تسمح بتشغيل الفيديو المباشر بسلاسة، يمكنك تشغيل وضع المعايشة لعرض صور بانورامية هادئة عالية الجودة.</p>
            <button
              onClick={() => setUseBackupMode(!useBackupMode)}
              className={`w-full py-2 rounded-lg text-xs font-bold transition-all cursor-pointer border ${
                useBackupMode 
                  ? 'bg-emerald-600 border-emerald-600 text-white' 
                  : 'border-[#D4AF37]/20 text-[#D4AF37] hover:bg-[#D4AF37]/10'
              }`}
            >
              {useBackupMode ? 'العودة للبث المرئي المباشر' : 'تفعيل مشهد المعايشة البديل'}
            </button>
          </div>

        </div>

        {/* Video Player Box (Right side on Desktop, bottom on Mobile) */}
        <div className="lg:col-span-3 order-1 lg:order-2 space-y-4">
          
          <div className={`p-4 rounded-2xl border ${
            darkMode ? 'glass-emerald-dark text-white border-[#D4AF37]/30' : 'glass-card-light text-emerald-950 shadow-md'
          }`}>
            
            {/* Viewport frame */}
            <div className="relative aspect-video rounded-xl bg-black overflow-hidden shadow-inner">
              
              {useBackupMode ? (
                /* Fallback slide mode (Stunning fading backgrounds) */
                <div className="absolute inset-0">
                  <motion.img
                    key={activeStream}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 1 }}
                    src={current.backupImage}
                    alt={current.title}
                    className="w-full h-full object-cover filter brightness-[0.7] saturate-[1.1]"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30 flex flex-col justify-between p-6 text-right">
                    <span className="self-end bg-emerald-600/95 backdrop-blur-sm px-3 py-1 rounded-full text-[10px] text-white font-bold flex items-center gap-1.5 border border-[#D4AF37]/30">
                      <Sparkles className="w-3.5 h-3.5 text-yellow-400 animate-pulse" />
                      <span>مشهد المعايشة الروحاني</span>
                    </span>

                    <div>
                      <span className="text-[10px] text-[#D4AF37] font-semibold flex items-center gap-1 mb-1">
                        <MapPin className="w-3 h-3" />
                        <span>{current.location}</span>
                      </span>
                      <h4 className="font-quran text-lg sm:text-xl font-bold text-white">{current.title}</h4>
                      <p className="text-[11px] text-gray-300 max-w-md mt-1 leading-relaxed">{current.desc}</p>
                    </div>
                  </div>
                </div>
              ) : (
                /* Iframe Video Stream Player */
                <iframe
                  title={current.title}
                  src={`${current.embedUrl}?autoplay=1&mute=1&rel=0&modestbranding=1`}
                  className="w-full h-full border-0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              )}

            </div>

            {/* Bottom info caption */}
            <div className="mt-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div>
                <h4 className={`text-sm font-bold ${darkMode ? 'text-white' : 'text-emerald-950'}`}>{current.title}</h4>
                <div className="text-[11px] text-gray-400 flex items-center gap-1 mt-0.5">
                  <MapPin className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>{current.location}</span>
                </div>
              </div>

              {!useBackupMode && (
                <div className="flex gap-2 text-[10px] text-gray-400 bg-emerald-500/5 p-2 rounded-lg border border-[#D4AF37]/10">
                  <AlertCircle className="w-4 h-4 text-[#D4AF37] shrink-0" />
                  <span>البث يعمل مجاناً بالكامل بدعم من قنوات التلفزيون السعودي.</span>
                </div>
              )}
            </div>

          </div>

        </div>

      </div>

    </div>
  );
}
