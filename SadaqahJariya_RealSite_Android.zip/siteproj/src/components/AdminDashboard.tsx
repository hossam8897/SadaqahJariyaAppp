/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Lock, 
  Trash2, 
  Edit3,
  Plus,
  Save,
  CheckCircle, 
  TrendingUp, 
  UserCheck, 
  Activity, 
  Layers, 
  Eye, 
  Volume2, 
  SlidersHorizontal,
  Info,
  BookOpen,
  Award,
  BookMarked,
  FileText,
  Sparkles,
  RefreshCw,
  X,
  Compass
} from 'lucide-react';

import {
  db,
  getDuas, saveDua, removeDua,
  getAzkar, saveZikr, removeZikr,
  getHadiths, saveHadith, removeHadith,
  getStories, saveStory, removeStory,
  getArticles, saveArticle, removeArticle,
  getReciters, saveReciter, removeReciter,
  getGuestbookEntries, removeGuestbookEntry
} from '../utils/firebase';

import { DuaItem, AzkarItem, HadithItem, StoryItem, ArticleItem, AudioReciter, GuestbookEntry } from '../types';

export default function AdminDashboard({ darkMode, globalPrayCount, totalTasbeehCount }: { 
  darkMode: boolean; 
  globalPrayCount: number; 
  totalTasbeehCount: number; 
}) {
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [adminPassword, setAdminPassword] = useState('');
  const [passError, setPassError] = useState(false);
  
  // Dashboard navigation tab
  const [adminTab, setAdminTab] = useState<'overview' | 'duas' | 'azkar' | 'hadiths' | 'stories' | 'articles' | 'reciters' | 'guestbook'>('overview');

  // Firestore collections state
  const [duas, setDuas] = useState<DuaItem[]>([]);
  const [azkar, setAzkar] = useState<AzkarItem[]>([]);
  const [hadiths, setHadiths] = useState<HadithItem[]>([]);
  const [stories, setStories] = useState<StoryItem[]>([]);
  const [articles, setArticles] = useState<ArticleItem[]>([]);
  const [reciters, setReciters] = useState<AudioReciter[]>([]);
  const [guestbook, setGuestbook] = useState<GuestbookEntry[]>([]);
  const [loading, setLoading] = useState(false);

  // Settings toggles
  const [lockGuestbook, setLockGuestbook] = useState(false);
  const [enableDailyVerses, setEnableDailyVerses] = useState(true);

  // Modal / Form state for edit & add
  const [editModal, setEditModal] = useState<{
    type: 'dua' | 'azkar' | 'hadith' | 'story' | 'article' | 'reciter';
    item: any; // the active item being edited or added
    isNew: boolean;
  } | null>(null);

  // Loader function
  const loadAllCollections = async () => {
    setLoading(true);
    try {
      const [
        duasList, azkarList, hadithsList, storiesList, articlesList, recitersList, guestbookList
      ] = await Promise.all([
        getDuas(), getAzkar(), getHadiths(), getStories(), getArticles(), getReciters(), getGuestbookEntries()
      ]);
      setDuas(duasList);
      setAzkar(azkarList);
      setHadiths(hadithsList);
      setStories(storiesList);
      setArticles(articlesList);
      setReciters(recitersList);
      setGuestbook(guestbookList);
    } catch (e) {
      console.error('Error loading collections in admin:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isAdminLoggedIn) {
      loadAllCollections();
    }
  }, [isAdminLoggedIn]);

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminPassword === 'omran1960') {
      setIsAdminLoggedIn(true);
      setPassError(false);
    } else {
      setPassError(true);
      setTimeout(() => setPassError(false), 3000);
    }
  };

  const handleLogout = () => {
    setIsAdminLoggedIn(false);
    setAdminPassword('');
  };

  // CRUD Actions
  const handleOpenEdit = (type: any, item: any, isNew = false) => {
    setEditModal({ type, item, isNew });
  };

  const handleSaveItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editModal) return;

    const { type, item, isNew } = editModal;
    setLoading(true);

    try {
      if (type === 'dua') {
        const payload: DuaItem = {
          id: isNew ? `d_custom_${Date.now()}` : item.id,
          category: item.category || 'deceased',
          title: item.title || '',
          text: item.text || '',
          source: item.source || '',
          repeatCount: Number(item.repeatCount) || 1,
          explanation: item.explanation || ''
        };
        await saveDua(payload);
        setDuas(prev => isNew ? [...prev, payload] : prev.map(d => d.id === payload.id ? payload : d));
      } else if (type === 'azkar') {
        const payload: AzkarItem = {
          id: isNew ? `az_custom_${Date.now()}` : item.id,
          category: item.category || 'morning',
          text: item.text || '',
          count: Number(item.count) || 1,
          reward: item.reward || '',
          description: item.description || ''
        };
        await saveZikr(payload);
        setAzkar(prev => isNew ? [...prev, payload] : prev.map(a => a.id === payload.id ? payload : a));
      } else if (type === 'hadith') {
        const payload: HadithItem = {
          id: isNew ? `h_custom_${Date.now()}` : item.id,
          category: item.category || 'الصدقة والعمل الصالح',
          text: item.text || '',
          narrator: item.narrator || '',
          source: item.source || '',
          explanation: item.explanation || ''
        };
        await saveHadith(payload);
        setHadiths(prev => isNew ? [...prev, payload] : prev.map(h => h.id === payload.id ? payload : h));
      } else if (type === 'story') {
        const payload: StoryItem = {
          id: isNew ? `s_custom_${Date.now()}` : item.id,
          category: item.category || 'lessons',
          title: item.title || '',
          text: item.text || '',
          moral: item.moral || ''
        };
        await saveStory(payload);
        setStories(prev => isNew ? [...prev, payload] : prev.map(s => s.id === payload.id ? payload : s));
      } else if (type === 'article') {
        const payload: ArticleItem = {
          id: isNew ? `art_custom_${Date.now()}` : item.id,
          title: item.title || '',
          author: item.author || '',
          date: item.date || new Date().toLocaleDateString('ar-SA'),
          readTime: item.readTime || '٥ دقائق',
          text: item.text || ''
        };
        await saveArticle(payload);
        setArticles(prev => isNew ? [...prev, payload] : prev.map(art => art.id === payload.id ? payload : art));
      } else if (type === 'reciter') {
        const payload: AudioReciter = {
          id: isNew ? `rec_custom_${Date.now()}` : item.id,
          name: item.name || '',
          arabicName: item.arabicName || '',
          identifier: item.identifier || ''
        };
        await saveReciter(payload);
        setReciters(prev => isNew ? [...prev, payload] : prev.map(r => r.id === payload.id ? payload : r));
      }

      setEditModal(null);
    } catch (err) {
      console.error('Error saving item to database:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteItem = async (type: string, id: string) => {
    if (!window.confirm('هل أنت متأكد من رغبتك في حذف هذا العنصر نهائياً من قاعدة البيانات؟')) return;
    setLoading(true);

    try {
      if (type === 'dua') {
        await removeDua(id);
        setDuas(prev => prev.filter(d => d.id !== id));
      } else if (type === 'azkar') {
        await removeZikr(id);
        setAzkar(prev => prev.filter(a => a.id !== id));
      } else if (type === 'hadith') {
        await removeHadith(id);
        setHadiths(prev => prev.filter(h => h.id !== id));
      } else if (type === 'story') {
        await removeStory(id);
        setStories(prev => prev.filter(s => s.id !== id));
      } else if (type === 'article') {
        await removeArticle(id);
        setArticles(prev => prev.filter(art => art.id !== id));
      } else if (type === 'reciter') {
        await removeReciter(id);
        setReciters(prev => prev.filter(r => r.id !== id));
      } else if (type === 'guestbook') {
        await removeGuestbookEntry(id);
        setGuestbook(prev => prev.filter(g => g.id !== id));
      }
    } catch (err) {
      console.error('Error deleting item:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-right">
      
      {/* Header */}
      <div className="text-center mb-10">
        <h2 className="font-quran text-3xl font-extrabold text-[#D4AF37] mb-2">لوحة التحكم والإشراف الإداري</h2>
        <p className={`text-sm ${darkMode ? 'text-gray-300' : 'text-emerald-900'} max-w-xl mx-auto`}>
          تحكم كامل في قاعدة البيانات الحية للموقع. أضف، عدّل، واحذف المحتوى الروحي والتعليمي (أدعية، أذكار، أحاديث، قصص، مقالات، قراء) بكل سهولة.
        </p>
      </div>

      {!isAdminLoggedIn ? (
        /* Login screen */
        <div className="max-w-md mx-auto">
          <form
            onSubmit={handleAdminLogin}
            className={`p-6 sm:p-8 rounded-2xl border text-right space-y-4 ${
              darkMode ? 'glass-emerald-dark text-white shadow-2xl' : 'glass-card-light text-emerald-950 shadow-md'
            }`}
          >
            <div className="text-center mb-6">
              <span className="inline-block p-3 rounded-full bg-[#D4AF37]/5 border border-[#D4AF37]/20 text-[#D4AF37] mb-2">
                <Lock className="w-6 h-6" />
              </span>
              <h3 className="text-base font-bold text-gray-300">تسجيل دخول المشرف</h3>
              <p className="text-[10px] text-gray-500 mt-1">الرجاء إدخال كلمة المرور الخاصة بالإدارة للوصول لتعديل قاعدة البيانات</p>
            </div>

            <div>
              <label className="text-[10px] text-gray-400 block mb-1 font-semibold">كلمة المرور الإدارية</label>
              <input
                type="password"
                required
                placeholder="اكتب كلمة المرور هنا..."
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                className={`w-full p-2.5 rounded-lg border text-sm text-center focus:outline-none focus:ring-1 focus:ring-[#D4AF37] ${
                  darkMode ? 'bg-emerald-950/30 border-[#D4AF37]/20 text-white' : 'bg-slate-50 border-emerald-100 text-emerald-950'
                }`}
              />
              <span className="text-[9px] text-amber-500 block mt-1 leading-relaxed">كلمة المرور للمراجعة هي <span className="font-mono font-bold text-emerald-400 select-all">omran1960</span></span>
            </div>

            {passError && (
              <div className="p-2.5 rounded text-[10px] bg-red-500/10 text-red-400 font-bold text-center border border-red-500/25">
                عذراً، كلمة المرور التي أدخلتها خاطئة!
              </div>
            )}

            <button
              type="submit"
              className="w-full py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs transition-colors cursor-pointer"
            >
              تسجيل دخول وتأمين الجلسة
            </button>
          </form>
        </div>
      ) : (
        /* Logged in admin dashboard views */
        <div className="space-y-8">
          
          {/* Header logout row */}
          <div className={`flex flex-col sm:flex-row gap-4 justify-between items-center p-4 rounded-xl border ${
            darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950'
          }`}>
            <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold">
              <CheckCircle className="w-4 h-4" />
              <span>متصل بقاعدة البيانات Firestore الحية ({db.app.name})</span>
              {loading && <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#D4AF37]" />}
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={loadAllCollections}
                className="px-3 py-1.5 rounded-lg border border-[#D4AF37]/20 text-[#D4AF37] hover:bg-[#D4AF37]/10 text-xs font-bold transition-colors cursor-pointer flex items-center gap-1"
              >
                <RefreshCw className="w-3 h-3" />
                تحديث البيانات
              </button>
              <button
                onClick={handleLogout}
                className="px-3 py-1.5 rounded-lg border border-red-500/15 text-red-400 hover:bg-red-500/10 text-xs font-bold transition-colors cursor-pointer"
              >
                تسجيل خروج من الإدارة
              </button>
            </div>
          </div>

          {/* Navigation tabs for database segments */}
          <div className="flex flex-wrap gap-2 justify-center border-b border-emerald-950/40 pb-4">
            <button
              onClick={() => setAdminTab('overview')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                adminTab === 'overview' ? 'bg-[#D4AF37] text-emerald-950' : 'bg-emerald-950/20 text-gray-400 hover:text-white'
              }`}
            >
              📊 نظرة عامة
            </button>
            <button
              onClick={() => setAdminTab('duas')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                adminTab === 'duas' ? 'bg-[#D4AF37] text-emerald-950' : 'bg-emerald-950/20 text-gray-400 hover:text-white'
              }`}
            >
              🤲 الأدعية ({duas.length})
            </button>
            <button
              onClick={() => setAdminTab('azkar')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                adminTab === 'azkar' ? 'bg-[#D4AF37] text-emerald-950' : 'bg-emerald-950/20 text-gray-400 hover:text-white'
              }`}
            >
              📿 الأذكار ({azkar.length})
            </button>
            <button
              onClick={() => setAdminTab('hadiths')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                adminTab === 'hadiths' ? 'bg-[#D4AF37] text-emerald-950' : 'bg-emerald-950/20 text-gray-400 hover:text-white'
              }`}
            >
              📜 الأحاديث ({hadiths.length})
            </button>
            <button
              onClick={() => setAdminTab('stories')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                adminTab === 'stories' ? 'bg-[#D4AF37] text-emerald-950' : 'bg-emerald-950/20 text-gray-400 hover:text-white'
              }`}
            >
              🕌 القصص ({stories.length})
            </button>
            <button
              onClick={() => setAdminTab('articles')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                adminTab === 'articles' ? 'bg-[#D4AF37] text-emerald-950' : 'bg-emerald-950/20 text-gray-400 hover:text-white'
              }`}
            >
              ✍️ المقالات ({articles.length})
            </button>
            <button
              onClick={() => setAdminTab('reciters')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                adminTab === 'reciters' ? 'bg-[#D4AF37] text-emerald-950' : 'bg-emerald-950/20 text-gray-400 hover:text-white'
              }`}
            >
              🎙️ القراء والمشايخ ({reciters.length})
            </button>
            <button
              onClick={() => setAdminTab('guestbook')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                adminTab === 'guestbook' ? 'bg-[#D4AF37] text-emerald-950' : 'bg-emerald-950/20 text-gray-400 hover:text-white'
              }`}
            >
              ✍️ التعازي ({guestbook.length})
            </button>
          </div>

          <AnimatePresence mode="wait">
            
            {/* OVERVIEW TAB */}
            {adminTab === 'overview' && (
              <motion.div
                key="overview-panel"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-6"
              >
                {/* Stats cards */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                  <div className={`p-5 rounded-2xl border flex justify-between items-center ${
                    darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950 shadow-sm'
                  }`}>
                    <div>
                      <div className="text-[10px] text-gray-400 font-semibold mb-1">أدعية مهداة لعبدالناصر عمران</div>
                      <div className="text-3xl font-mono font-bold text-[#D4AF37]">{globalPrayCount}</div>
                    </div>
                    <UserCheck className="w-8 h-8 text-[#D4AF37]/50" />
                  </div>

                  <div className={`p-5 rounded-2xl border flex justify-between items-center ${
                    darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950 shadow-sm'
                  }`}>
                    <div>
                      <div className="text-[10px] text-gray-400 font-semibold mb-1">نقرات التسبيح الإجمالية</div>
                      <div className="text-3xl font-mono font-bold text-emerald-400">{totalTasbeehCount}</div>
                    </div>
                    <Activity className="w-8 h-8 text-emerald-400/50" />
                  </div>

                  <div className={`p-5 rounded-2xl border flex justify-between items-center ${
                    darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950 shadow-sm'
                  }`}>
                    <div>
                      <div className="text-[10px] text-gray-400 font-semibold mb-1">إجمالي المحتوى بقاعدة البيانات</div>
                      <div className="text-3xl font-mono font-bold text-cyan-400">{duas.length + azkar.length + hadiths.length + stories.length + articles.length}</div>
                    </div>
                    <Layers className="w-8 h-8 text-cyan-400/50" />
                  </div>

                  <div className={`p-5 rounded-2xl border flex justify-between items-center ${
                    darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950 shadow-sm'
                  }`}>
                    <div>
                      <div className="text-[10px] text-gray-400 font-semibold mb-1">عدد رسائل التعازي النشطة</div>
                      <div className="text-3xl font-mono font-bold text-amber-500">{guestbook.length}</div>
                    </div>
                    <Eye className="w-8 h-8 text-amber-500/50" />
                  </div>
                </div>

                {/* Subgrid graph + config */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  <div className="lg:col-span-1 space-y-6">
                    <div className={`p-5 rounded-2xl border ${
                      darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950 shadow-sm'
                    }`}>
                      <h3 className="text-sm font-bold text-[#D4AF37] mb-4 flex items-center gap-2 border-b border-[#D4AF37]/10 pb-2">
                        <SlidersHorizontal className="w-4 h-4" />
                        <span>ضبط وإعدادات النظام</span>
                      </h3>

                      <div className="space-y-4">
                        <div className="flex justify-between items-center">
                          <div>
                            <div className="text-xs font-bold text-white">إغلاق سجل التعازي</div>
                            <div className="text-[9px] text-gray-400 mt-0.5">منع الزوار من كتابة أدعية جديدة</div>
                          </div>
                          <button
                            onClick={() => setLockGuestbook(!lockGuestbook)}
                            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                              lockGuestbook 
                                ? 'bg-red-500/15 text-red-400 border border-red-500/30' 
                                : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            }`}
                          >
                            {lockGuestbook ? 'مقفل' : 'مفتوح'}
                          </button>
                        </div>

                        <div className="flex justify-between items-center border-t border-emerald-950/40 pt-4">
                          <div>
                            <div className="text-xs font-bold text-white">عرض الآيات اليومية بالرأس</div>
                            <div className="text-[9px] text-gray-400 mt-0.5">تبديل الآيات الروحانية التلقائية</div>
                          </div>
                          <button
                            onClick={() => setEnableDailyVerses(!enableDailyVerses)}
                            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                              enableDailyVerses 
                                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' 
                                : 'bg-red-500/15 text-red-400 border border-red-500/30'
                            }`}
                          >
                            {enableDailyVerses ? 'مفعّل' : 'ملغى'}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className={`lg:col-span-2 p-5 rounded-2xl border ${
                    darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950 shadow-sm'
                  }`}>
                    <h3 className="text-sm font-bold text-[#D4AF37] mb-4 flex items-center gap-2 border-b border-[#D4AF37]/10 pb-2">
                      <TrendingUp className="w-4 h-4" />
                      <span>نشاط قاعدة البيانات السحابية (Firestore)</span>
                    </h3>

                    {/* Pure SVG line graph */}
                    <div className="relative py-4">
                      <svg viewBox="0 0 500 150" className="w-full h-auto text-[#D4AF37]">
                        <line x1="10" y1="130" x2="490" y2="130" stroke="#052814" strokeWidth="1" />
                        <line x1="10" y1="10" x2="10" y2="130" stroke="#052814" strokeWidth="1" />
                        <path
                          d="M 10 120 L 90 95 L 170 110 L 250 50 L 330 65 L 410 30 L 490 10"
                          fill="none"
                          stroke="#D4AF37"
                          strokeWidth="3"
                          strokeLinecap="round"
                        />
                        <circle cx="250" cy="50" r="4" fill="#D4AF37" />
                        <circle cx="410" cy="30" r="4" fill="#D4AF37" />
                      </svg>
                      <div className="flex justify-between text-[8px] text-gray-500 font-bold mt-2">
                        <span>السبت</span>
                        <span>الأحد</span>
                        <span>الاثنين</span>
                        <span>الثلاثاء</span>
                        <span>الأربعاء</span>
                        <span>الخميس</span>
                        <span>الجمعة (اليوم)</span>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* DUAS MANAGEMENT */}
            {adminTab === 'duas' && (
              <motion.div
                key="duas-panel"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="space-y-4"
              >
                <div className="flex justify-between items-center">
                  <h3 className="text-base font-bold text-[#D4AF37]">قائمة الأدعية المتوفرة في قاعدة البيانات</h3>
                  <button
                    onClick={() => handleOpenEdit('dua', { category: 'deceased', title: '', text: '', source: '', repeatCount: 1, explanation: '' }, true)}
                    className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    إضافة دعاء جديد
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {duas.map(dua => (
                    <div key={dua.id} className={`p-4 rounded-xl border flex flex-col justify-between gap-3 ${
                      darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950'
                    }`}>
                      <div>
                        <div className="flex justify-between items-start">
                          <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2.5 py-0.5 rounded-full font-bold">
                            {dua.category === 'deceased' ? '🕯️ للمتوفى عبدالناصر عمران' : dua.category === 'prophet_quran' ? '✨ أنبياء' : '📖 قرآنية'}
                          </span>
                          <span className="text-[10px] text-gray-500 font-bold">تكرار: {dua.repeatCount || 1} مرات</span>
                        </div>
                        <h4 className="text-sm font-bold text-[#D4AF37] mt-2 mb-1">{dua.title}</h4>
                        <p className="text-xs text-gray-300 leading-relaxed font-medium line-clamp-3">"{dua.text}"</p>
                        {dua.source && <span className="text-[9px] text-gray-500 block mt-1">المصدر: {dua.source}</span>}
                      </div>

                      <div className="flex justify-end gap-2 border-t border-emerald-950/40 pt-2">
                        <button
                          onClick={() => handleOpenEdit('dua', dua)}
                          className="p-1.5 rounded bg-amber-500/10 text-amber-500 border border-amber-500/20 hover:bg-amber-500/20 transition-all cursor-pointer"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteItem('dua', dua.id)}
                          className="p-1.5 rounded bg-red-500/10 text-red-500 border border-red-500/20 hover:bg-red-500/20 transition-all cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* AZKAR MANAGEMENT */}
            {adminTab === 'azkar' && (
              <motion.div
                key="azkar-panel"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="space-y-4"
              >
                <div className="flex justify-between items-center">
                  <h3 className="text-base font-bold text-[#D4AF37]">قائمة الأذكار المسجلة بقاعدة البيانات</h3>
                  <button
                    onClick={() => handleOpenEdit('azkar', { category: 'morning', text: '', count: 1, reward: '', description: '' }, true)}
                    className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    إضافة ذكر جديد
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {azkar.map(zkr => (
                    <div key={zkr.id} className={`p-4 rounded-xl border flex flex-col justify-between gap-3 ${
                      darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950'
                    }`}>
                      <div>
                        <div className="flex justify-between items-start">
                          <span className="text-[10px] bg-amber-500/10 text-[#D4AF37] border border-amber-500/20 px-2.5 py-0.5 rounded-full font-bold">
                            {zkr.category === 'morning' ? '☀️ أذكار الصباح' : zkr.category === 'evening' ? '🌙 أذكار المساء' : zkr.category === 'sleep' ? '😴 أذكار النوم' : '🕌 أذكار الصلاة'}
                          </span>
                          <span className="text-[10px] text-gray-500 font-bold">التكرار المطلوب: {zkr.count} مرات</span>
                        </div>
                        <p className="text-xs text-gray-300 leading-relaxed font-semibold mt-2">"{zkr.text}"</p>
                        {zkr.reward && <p className="text-[10px] text-emerald-400 mt-1 leading-relaxed">الأجر: {zkr.reward}</p>}
                        {zkr.description && <span className="text-[9px] text-gray-500 block mt-1">الوصف: {zkr.description}</span>}
                      </div>

                      <div className="flex justify-end gap-2 border-t border-emerald-950/40 pt-2">
                        <button
                          onClick={() => handleOpenEdit('azkar', zkr)}
                          className="p-1.5 rounded bg-amber-500/10 text-amber-500 border border-amber-500/20 hover:bg-amber-500/20 transition-all cursor-pointer"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteItem('azkar', zkr.id)}
                          className="p-1.5 rounded bg-red-500/10 text-red-500 border border-red-500/20 hover:bg-red-500/20 transition-all cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* HADITHS MANAGEMENT */}
            {adminTab === 'hadiths' && (
              <motion.div
                key="hadiths-panel"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="space-y-4"
              >
                <div className="flex justify-between items-center">
                  <h3 className="text-base font-bold text-[#D4AF37]">قائمة الأحاديث الشريفة بقاعدة البيانات</h3>
                  <button
                    onClick={() => handleOpenEdit('hadith', { category: 'الصدقة والعمل الصالح', text: '', narrator: '', source: '', explanation: '' }, true)}
                    className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    إضافة حديث جديد
                  </button>
                </div>

                <div className="grid grid-cols-1 gap-4">
                  {hadiths.map(hd => (
                    <div key={hd.id} className={`p-5 rounded-xl border flex flex-col justify-between gap-4 ${
                      darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950'
                    }`}>
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-[10px] bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 px-2.5 py-0.5 rounded-full font-bold">
                            📂 {hd.category}
                          </span>
                          <span className="text-[10px] text-gray-400">الراوي: {hd.narrator || 'غير محدد'} • المصدر: {hd.source || 'غير محدد'}</span>
                        </div>
                        <p className="text-sm font-bold text-gray-200 leading-relaxed">"{hd.text}"</p>
                        {hd.explanation && (
                          <div className="mt-2.5 p-3 rounded bg-emerald-950/20 text-xs text-gray-400 border border-emerald-950/50 leading-relaxed">
                            <span className="font-extrabold text-[#D4AF37] block mb-1">💡 الشرح والفوائد:</span>
                            {hd.explanation}
                          </div>
                        )}
                      </div>

                      <div className="flex justify-end gap-2 border-t border-emerald-950/40 pt-2">
                        <button
                          onClick={() => handleOpenEdit('hadith', hd)}
                          className="p-1.5 rounded bg-amber-500/10 text-amber-500 border border-amber-500/20 hover:bg-amber-500/20 transition-all cursor-pointer flex items-center gap-1 text-[10px]"
                        >
                          <Edit3 className="w-3 h-3" />
                          <span>تعديل</span>
                        </button>
                        <button
                          onClick={() => handleDeleteItem('hadith', hd.id)}
                          className="p-1.5 rounded bg-red-500/10 text-red-500 border border-red-500/20 hover:bg-red-500/20 transition-all cursor-pointer flex items-center gap-1 text-[10px]"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>حذف</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* STORIES MANAGEMENT */}
            {adminTab === 'stories' && (
              <motion.div
                key="stories-panel"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="space-y-4"
              >
                <div className="flex justify-between items-center">
                  <h3 className="text-base font-bold text-[#D4AF37]">قائمة القصص والعبر الإسلامية</h3>
                  <button
                    onClick={() => handleOpenEdit('story', { category: 'lessons', title: '', text: '', moral: '' }, true)}
                    className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    إضافة قصة جديدة
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {stories.map(st => (
                    <div key={st.id} className={`p-4 rounded-xl border flex flex-col justify-between gap-3 ${
                      darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950'
                    }`}>
                      <div>
                        <div className="flex justify-between items-center">
                          <span className="text-[9px] bg-purple-500/10 text-purple-400 border border-purple-500/20 px-2 py-0.5 rounded-full font-bold">
                            {st.category === 'prophets' ? '🕌 الأنبياء عليهم السلام' : st.category === 'companions' ? '⚔️ الصحابة رضي الله عنهم' : '💡 عبر وعظات'}
                          </span>
                        </div>
                        <h4 className="text-sm font-bold text-white mt-2 mb-1">{st.title}</h4>
                        <p className="text-xs text-gray-300 leading-relaxed line-clamp-4">"{st.text}"</p>
                        {st.moral && <p className="text-[10px] text-[#D4AF37] font-semibold mt-1.5">الدروس المستفادة: {st.moral}</p>}
                      </div>

                      <div className="flex justify-end gap-2 border-t border-emerald-950/40 pt-2">
                        <button
                          onClick={() => handleOpenEdit('story', st)}
                          className="p-1.5 rounded bg-amber-500/10 text-amber-500 border border-amber-500/20 hover:bg-amber-500/20 transition-all cursor-pointer"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteItem('story', st.id)}
                          className="p-1.5 rounded bg-red-500/10 text-red-500 border border-red-500/20 hover:bg-red-500/20 transition-all cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* ARTICLES MANAGEMENT */}
            {adminTab === 'articles' && (
              <motion.div
                key="articles-panel"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="space-y-4"
              >
                <div className="flex justify-between items-center">
                  <h3 className="text-base font-bold text-[#D4AF37]">قائمة المقالات الوعظية والعلوم الإسلامية</h3>
                  <button
                    onClick={() => handleOpenEdit('article', { title: '', author: '', date: '', readTime: '٥ دقائق', text: '' }, true)}
                    className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    إضافة مقالة جديدة
                  </button>
                </div>

                <div className="grid grid-cols-1 gap-4">
                  {articles.map(art => (
                    <div key={art.id} className={`p-5 rounded-xl border flex flex-col justify-between gap-3 ${
                      darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950'
                    }`}>
                      <div>
                        <div className="flex justify-between items-start mb-1">
                          <h4 className="text-base font-bold text-white">{art.title}</h4>
                          <span className="text-[9px] bg-amber-500/10 text-[#D4AF37] border border-amber-500/20 px-2 py-0.5 rounded-full font-semibold">{art.readTime}</span>
                        </div>
                        <div className="text-[10px] text-gray-400 flex items-center gap-2 mb-2">
                          <span>بقلم الكاتب: {art.author}</span>
                          <span>•</span>
                          <span>تاريخ النشر: {art.date}</span>
                        </div>
                        <p className="text-xs text-gray-300 leading-relaxed font-medium line-clamp-3 whitespace-pre-line">{art.text}</p>
                      </div>

                      <div className="flex justify-end gap-2 border-t border-emerald-950/40 pt-2">
                        <button
                          onClick={() => handleOpenEdit('article', art)}
                          className="p-1.5 rounded bg-amber-500/10 text-amber-500 border border-amber-500/20 hover:bg-amber-500/20 transition-all cursor-pointer flex items-center gap-1 text-[10px]"
                        >
                          <Edit3 className="w-3 h-3" />
                          <span>تعديل المقال</span>
                        </button>
                        <button
                          onClick={() => handleDeleteItem('article', art.id)}
                          className="p-1.5 rounded bg-red-500/10 text-red-500 border border-red-500/20 hover:bg-red-500/20 transition-all cursor-pointer flex items-center gap-1 text-[10px]"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>حذف المقال</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* RECITERS MANAGEMENT */}
            {adminTab === 'reciters' && (
              <motion.div
                key="reciters-panel"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="space-y-4"
              >
                <div className="flex justify-between items-center">
                  <h3 className="text-base font-bold text-[#D4AF37]">قائمة القراء والمشايخ المعتمدين بالمكتبة الصوتية</h3>
                  <button
                    onClick={() => handleOpenEdit('reciter', { name: '', arabicName: '', identifier: '' }, true)}
                    className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    إضافة قارئ جديد
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {reciters.map(rec => (
                    <div key={rec.id} className={`p-4 rounded-xl border flex justify-between items-center gap-4 ${
                      darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950'
                    }`}>
                      <div>
                        <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                          <Volume2 className="w-4 h-4 text-[#D4AF37]" />
                          {rec.arabicName}
                        </h4>
                        <p className="text-[10px] text-gray-400 mt-1 font-mono">ID: {rec.id} | API_ID: {rec.identifier}</p>
                      </div>

                      <div className="flex gap-2 shrink-0">
                        <button
                          onClick={() => handleOpenEdit('reciter', rec)}
                          className="p-1.5 rounded bg-amber-500/10 text-amber-500 border border-amber-500/20 hover:bg-amber-500/20 transition-all cursor-pointer"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteItem('reciter', rec.id)}
                          className="p-1.5 rounded bg-red-500/10 text-red-500 border border-red-500/20 hover:bg-red-500/20 transition-all cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* GUESTBOOK MODERATION */}
            {adminTab === 'guestbook' && (
              <motion.div
                key="guestbook-panel"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="space-y-4"
              >
                <h3 className="text-sm font-bold text-[#D4AF37] flex items-center gap-2 border-b border-[#D4AF37]/10 pb-2">
                  <span>مراجعة وإشراف سجل التعازي والأدعية المكتوبة</span>
                </h3>

                {guestbook.length === 0 ? (
                  <div className="text-center py-10 text-xs text-gray-500">لا يوجد رسائل مسجلة حالياً للمراجعة بقاعدة البيانات.</div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {guestbook.map((item) => (
                      <div key={item.id} className={`p-4 rounded-xl border flex justify-between items-start gap-4 ${
                        darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950 shadow-sm'
                      }`}>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 text-xs font-bold text-[#D4AF37] mb-1">
                            <span>{item.name}</span>
                            <span className="text-[9px] text-gray-500 font-mono">({item.dateStr})</span>
                          </div>
                          <p className="text-xs text-gray-300 leading-relaxed">{item.message}</p>
                        </div>

                        <button
                          onClick={() => handleDeleteItem('guestbook', item.id)}
                          className="p-2 text-red-400 hover:bg-red-500/10 rounded-lg shrink-0 transition-colors cursor-pointer"
                          title="حذف الرسالة نهائياً"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </motion.div>
            )}

          </AnimatePresence>

          {/* EDIT/ADD MODAL (DYNAMIC FOR ALL TYPES) */}
          <AnimatePresence>
            {editModal && (
              <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className={`w-full max-w-lg p-6 rounded-2xl border text-right shadow-2xl relative max-h-[90vh] overflow-y-auto ${
                    darkMode ? 'bg-[#06120d] text-white border-[#D4AF37]/35' : 'bg-white text-emerald-950 border-emerald-100'
                  }`}
                >
                  <button
                    onClick={() => setEditModal(null)}
                    className="absolute top-4 left-4 p-1 rounded hover:bg-white/10 text-gray-400 hover:text-white cursor-pointer"
                  >
                    <X className="w-5 h-5" />
                  </button>

                  <h3 className="text-base font-extrabold text-[#D4AF37] mb-4 pb-2 border-b border-[#D4AF37]/15">
                    {editModal.isNew ? '✨ إضافة عنصر جديد لقاعدة البيانات' : '📝 تعديل بيانات العنصر'}
                  </h3>

                  <form onSubmit={handleSaveItem} className="space-y-4">
                    
                    {/* DUA FORM FIELDS */}
                    {editModal.type === 'dua' && (
                      <>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="text-[10px] text-gray-400 block mb-1 font-bold">التصنيف</label>
                            <select
                              value={editModal.item.category || 'deceased'}
                              onChange={(e) => setEditModal(prev => ({ ...prev!, item: { ...prev!.item, category: e.target.value } }))}
                              className="w-full p-2.5 rounded-lg border text-xs bg-emerald-950/20 text-white focus:outline-none"
                            >
                              <option value="deceased">🕯️ للمتوفى عبدالناصر عمران</option>
                              <option value="prophet_quran">✨ أدعية الأنبياء من القرآن</option>
                              <option value="quranic">📖 أدعية القرآن الكريم</option>
                              <option value="mercy_forgiveness">🤲 الرحمة والمغفرة</option>
                            </select>
                          </div>
                          <div>
                            <label className="text-[10px] text-gray-400 block mb-1 font-bold">مرات التكرار</label>
                            <input
                              type="number"
                              min="1"
                              value={editModal.item.repeatCount || 1}
                              onChange={(e) => setEditModal(prev => ({ ...prev!, item: { ...prev!.item, repeatCount: e.target.value } }))}
                              className="w-full p-2.5 rounded-lg border text-xs bg-emerald-950/20 text-white text-center focus:outline-none"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="text-[10px] text-gray-400 block mb-1 font-bold">عنوان الدعاء</label>
                          <input
                            type="text"
                            required
                            placeholder="مثال: طلب الرحمة والمغفرة"
                            value={editModal.item.title || ''}
                            onChange={(e) => setEditModal(prev => ({ ...prev!, item: { ...prev!.item, title: e.target.value } }))}
                            className="w-full p-2.5 rounded-lg border text-xs bg-emerald-950/20 text-white focus:outline-none"
                          />
                        </div>

                        <div>
                          <label className="text-[10px] text-gray-400 block mb-1 font-bold">نص الدعاء المبارك</label>
                          <textarea
                            required
                            rows={4}
                            placeholder="اكتب نص الدعاء هنا بالتشكيل إن أمكن..."
                            value={editModal.item.text || ''}
                            onChange={(e) => setEditModal(prev => ({ ...prev!, item: { ...prev!.item, text: e.target.value } }))}
                            className="w-full p-2.5 rounded-lg border text-xs bg-emerald-950/20 text-white focus:outline-none"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="text-[10px] text-gray-400 block mb-1 font-bold">المصدر</label>
                            <input
                              type="text"
                              placeholder="مثال: صحيح مسلم"
                              value={editModal.item.source || ''}
                              onChange={(e) => setEditModal(prev => ({ ...prev!, item: { ...prev!.item, source: e.target.value } }))}
                              className="w-full p-2.5 rounded-lg border text-xs bg-emerald-950/20 text-white focus:outline-none"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] text-gray-400 block mb-1 font-bold">تفسير وفضائل الدعاء</label>
                            <input
                              type="text"
                              placeholder="تفسير مختصر للدعاء..."
                              value={editModal.item.explanation || ''}
                              onChange={(e) => setEditModal(prev => ({ ...prev!, item: { ...prev!.item, explanation: e.target.value } }))}
                              className="w-full p-2.5 rounded-lg border text-xs bg-emerald-950/20 text-white focus:outline-none"
                            />
                          </div>
                        </div>
                      </>
                    )}

                    {/* AZKAR FORM FIELDS */}
                    {editModal.type === 'azkar' && (
                      <>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="text-[10px] text-gray-400 block mb-1 font-bold">تصنيف الأذكار</label>
                            <select
                              value={editModal.item.category || 'morning'}
                              onChange={(e) => setEditModal(prev => ({ ...prev!, item: { ...prev!.item, category: e.target.value } }))}
                              className="w-full p-2.5 rounded-lg border text-xs bg-emerald-950/20 text-white focus:outline-none"
                            >
                              <option value="morning">☀️ أذكار الصباح</option>
                              <option value="evening">🌙 أذكار المساء</option>
                              <option value="sleep">😴 أذكار النوم</option>
                              <option value="prayer">🕌 أذكار بعد الصلاة</option>
                            </select>
                          </div>
                          <div>
                            <label className="text-[10px] text-gray-400 block mb-1 font-bold">التكرار المطلوب</label>
                            <input
                              type="number"
                              min="1"
                              value={editModal.item.count || 1}
                              onChange={(e) => setEditModal(prev => ({ ...prev!, item: { ...prev!.item, count: e.target.value } }))}
                              className="w-full p-2.5 rounded-lg border text-xs bg-emerald-950/20 text-white text-center focus:outline-none"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="text-[10px] text-gray-400 block mb-1 font-bold">نص الذكر العظيم</label>
                          <textarea
                            required
                            rows={4}
                            placeholder="اكتب الذكر هنا..."
                            value={editModal.item.text || ''}
                            onChange={(e) => setEditModal(prev => ({ ...prev!, item: { ...prev!.item, text: e.target.value } }))}
                            className="w-full p-2.5 rounded-lg border text-xs bg-emerald-950/20 text-white focus:outline-none"
                          />
                        </div>

                        <div>
                          <label className="text-[10px] text-gray-400 block mb-1 font-bold">فضل وأجر الذكر</label>
                          <input
                            type="text"
                            placeholder="مثال: من قالها كفي هم يومه ونال الرضوان..."
                            value={editModal.item.reward || ''}
                            onChange={(e) => setEditModal(prev => ({ ...prev!, item: { ...prev!.item, reward: e.target.value } }))}
                            className="w-full p-2.5 rounded-lg border text-xs bg-emerald-950/20 text-white focus:outline-none"
                          />
                        </div>

                        <div>
                          <label className="text-[10px] text-gray-400 block mb-1 font-bold">الوصف والتوقيت</label>
                          <input
                            type="text"
                            placeholder="مثال: يقال ٣ مرات في الصباح والمساء..."
                            value={editModal.item.description || ''}
                            onChange={(e) => setEditModal(prev => ({ ...prev!, item: { ...prev!.item, description: e.target.value } }))}
                            className="w-full p-2.5 rounded-lg border text-xs bg-emerald-950/20 text-white focus:outline-none"
                          />
                        </div>
                      </>
                    )}

                    {/* HADITH FORM FIELDS */}
                    {editModal.type === 'hadith' && (
                      <>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="text-[10px] text-gray-400 block mb-1 font-bold">الباب والتصنيف</label>
                            <input
                              type="text"
                              required
                              placeholder="مثال: الصدقة والعمل الصالح"
                              value={editModal.item.category || ''}
                              onChange={(e) => setEditModal(prev => ({ ...prev!, item: { ...prev!.item, category: e.target.value } }))}
                              className="w-full p-2.5 rounded-lg border text-xs bg-emerald-950/20 text-white focus:outline-none"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] text-gray-400 block mb-1 font-bold">الراوي</label>
                            <input
                              type="text"
                              placeholder="مثال: أبو هريرة رضي الله عنه"
                              value={editModal.item.narrator || ''}
                              onChange={(e) => setEditModal(prev => ({ ...prev!, item: { ...prev!.item, narrator: e.target.value } }))}
                              className="w-full p-2.5 rounded-lg border text-xs bg-emerald-950/20 text-white focus:outline-none"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="text-[10px] text-gray-400 block mb-1 font-bold">نص الحديث الشريف</label>
                          <textarea
                            required
                            rows={4}
                            placeholder="قال رسول الله ﷺ: ..."
                            value={editModal.item.text || ''}
                            onChange={(e) => setEditModal(prev => ({ ...prev!, item: { ...prev!.item, text: e.target.value } }))}
                            className="w-full p-2.5 rounded-lg border text-xs bg-emerald-950/20 text-white focus:outline-none"
                          />
                        </div>

                        <div>
                          <label className="text-[10px] text-gray-400 block mb-1 font-bold">تخريج الحديث والمصدر</label>
                          <input
                            type="text"
                            placeholder="مثال: رواه مسلم في صحيحه"
                            value={editModal.item.source || ''}
                            onChange={(e) => setEditModal(prev => ({ ...prev!, item: { ...prev!.item, source: e.target.value } }))}
                            className="w-full p-2.5 rounded-lg border text-xs bg-emerald-950/20 text-white focus:outline-none"
                          />
                        </div>

                        <div>
                          <label className="text-[10px] text-gray-400 block mb-1 font-bold">شرح وفقه الحديث المبارك</label>
                          <textarea
                            rows={3}
                            placeholder="اكتب شرحاً ميسراً لفوائد الحديث..."
                            value={editModal.item.explanation || ''}
                            onChange={(e) => setEditModal(prev => ({ ...prev!, item: { ...prev!.item, explanation: e.target.value } }))}
                            className="w-full p-2.5 rounded-lg border text-xs bg-emerald-950/20 text-white focus:outline-none"
                          />
                        </div>
                      </>
                    )}

                    {/* STORY FORM FIELDS */}
                    {editModal.type === 'story' && (
                      <>
                        <div>
                          <label className="text-[10px] text-gray-400 block mb-1 font-bold">نوع القصة</label>
                          <select
                            value={editModal.item.category || 'lessons'}
                            onChange={(e) => setEditModal(prev => ({ ...prev!, item: { ...prev!.item, category: e.target.value } }))}
                            className="w-full p-2.5 rounded-lg border text-xs bg-emerald-950/20 text-white focus:outline-none"
                          >
                            <option value="prophets">🕌 قصص الأنبياء عليهم السلام</option>
                            <option value="companions">⚔️ قصص الصحابة رضي الله عنهم</option>
                            <option value="lessons">💡 عبر وعظات للمؤمنين</option>
                          </select>
                        </div>

                        <div>
                          <label className="text-[10px] text-gray-400 block mb-1 font-bold">عنوان القصة العبرة</label>
                          <input
                            type="text"
                            required
                            placeholder="مثال: قصة بئر رومة والتبرع السخي..."
                            value={editModal.item.title || ''}
                            onChange={(e) => setEditModal(prev => ({ ...prev!, item: { ...prev!.item, title: e.target.value } }))}
                            className="w-full p-2.5 rounded-lg border text-xs bg-emerald-950/20 text-white focus:outline-none"
                          />
                        </div>

                        <div>
                          <label className="text-[10px] text-gray-400 block mb-1 font-bold">أحداث وتفاصيل القصة</label>
                          <textarea
                            required
                            rows={5}
                            placeholder="اروي تفاصيل القصة والعبرة منها هنا..."
                            value={editModal.item.text || ''}
                            onChange={(e) => setEditModal(prev => ({ ...prev!, item: { ...prev!.item, text: e.target.value } }))}
                            className="w-full p-2.5 rounded-lg border text-xs bg-emerald-950/20 text-white focus:outline-none"
                          />
                        </div>

                        <div>
                          <label className="text-[10px] text-gray-400 block mb-1 font-bold">الدروس المستفادة والعبرة الأخلاقية</label>
                          <input
                            type="text"
                            placeholder="العبرة الأساسية من هذه القصة المباركة..."
                            value={editModal.item.moral || ''}
                            onChange={(e) => setEditModal(prev => ({ ...prev!, item: { ...prev!.item, moral: e.target.value } }))}
                            className="w-full p-2.5 rounded-lg border text-xs bg-emerald-950/20 text-white focus:outline-none"
                          />
                        </div>
                      </>
                    )}

                    {/* ARTICLE FORM FIELDS */}
                    {editModal.type === 'article' && (
                      <>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="text-[10px] text-gray-400 block mb-1 font-bold">الكاتب</label>
                            <input
                              type="text"
                              required
                              placeholder="مثال: الشيخ عبدالرحمن القاسمي"
                              value={editModal.item.author || ''}
                              onChange={(e) => setEditModal(prev => ({ ...prev!, item: { ...prev!.item, author: e.target.value } }))}
                              className="w-full p-2.5 rounded-lg border text-xs bg-emerald-950/20 text-white focus:outline-none"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] text-gray-400 block mb-1 font-bold">زمن القراءة المقدر</label>
                            <input
                              type="text"
                              placeholder="مثال: ٥ دقائق"
                              value={editModal.item.readTime || '٥ دقائق'}
                              onChange={(e) => setEditModal(prev => ({ ...prev!, item: { ...prev!.item, readTime: e.target.value } }))}
                              className="w-full p-2.5 rounded-lg border text-xs bg-emerald-950/20 text-white focus:outline-none"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="text-[10px] text-gray-400 block mb-1 font-bold">عنوان المقالة الإسلامية</label>
                          <input
                            type="text"
                            required
                            placeholder="أثر العلوم الإسلامية وتزكية النفس..."
                            value={editModal.item.title || ''}
                            onChange={(e) => setEditModal(prev => ({ ...prev!, item: { ...prev!.item, title: e.target.value } }))}
                            className="w-full p-2.5 rounded-lg border text-xs bg-emerald-950/20 text-white focus:outline-none"
                          />
                        </div>

                        <div>
                          <label className="text-[10px] text-gray-400 block mb-1 font-bold">نص المقالة كاملاً</label>
                          <textarea
                            required
                            rows={8}
                            placeholder="اكتب نص المقالة كاملاً هنا..."
                            value={editModal.item.text || ''}
                            onChange={(e) => setEditModal(prev => ({ ...prev!, item: { ...prev!.item, text: e.target.value } }))}
                            className="w-full p-2.5 rounded-lg border text-xs bg-emerald-950/20 text-white focus:outline-none"
                          />
                        </div>
                      </>
                    )}

                    {/* RECITER FORM FIELDS */}
                    {editModal.type === 'reciter' && (
                      <>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="text-[10px] text-gray-400 block mb-1 font-bold">الاسم بالعربية</label>
                            <input
                              type="text"
                              required
                              placeholder="مثال: مشاري العفاسي"
                              value={editModal.item.arabicName || ''}
                              onChange={(e) => setEditModal(prev => ({ ...prev!, item: { ...prev!.item, arabicName: e.target.value } }))}
                              className="w-full p-2.5 rounded-lg border text-xs bg-emerald-950/20 text-white focus:outline-none"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] text-gray-400 block mb-1 font-bold">الاسم بالإنجليزية</label>
                            <input
                              type="text"
                              required
                              placeholder="مثال: Mishary Alafasy"
                              value={editModal.item.name || ''}
                              onChange={(e) => setEditModal(prev => ({ ...prev!, item: { ...prev!.item, name: e.target.value } }))}
                              className="w-full p-2.5 rounded-lg border text-xs bg-emerald-950/20 text-white focus:outline-none"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="text-[10px] text-gray-400 block mb-1 font-bold">معرف صوتيات القارئ (Identifier)</label>
                          <input
                            type="text"
                            required
                            placeholder="مثال: ar.alafasy"
                            value={editModal.item.identifier || ''}
                            onChange={(e) => setEditModal(prev => ({ ...prev!, item: { ...prev!.item, identifier: e.target.value } }))}
                            className="w-full p-2.5 rounded-lg border text-xs bg-emerald-950/20 text-white focus:outline-none font-mono"
                          />
                          <span className="text-[9px] text-gray-500 block mt-1">يستخدم لربطه تلقائياً بملفات التلاوة المعتمدة بالموقع</span>
                        </div>
                      </>
                    )}

                    <div className="flex justify-end gap-3 pt-4 border-t border-[#D4AF37]/10">
                      <button
                        type="button"
                        onClick={() => setEditModal(null)}
                        className="px-4 py-2 border border-[#D4AF37]/20 text-[#D4AF37] rounded-lg text-xs font-bold hover:bg-[#D4AF37]/10 transition-colors cursor-pointer"
                      >
                        إلغاء الأمر
                      </button>
                      <button
                        type="submit"
                        disabled={loading}
                        className="px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold transition-colors cursor-pointer flex items-center gap-1.5"
                      >
                        <Save className="w-4 h-4" />
                        <span>حفظ في قاعدة البيانات السحابية</span>
                      </button>
                    </div>

                  </form>
                </motion.div>
              </div>
            )}
          </AnimatePresence>

        </div>
      )}

    </div>
  );
}
