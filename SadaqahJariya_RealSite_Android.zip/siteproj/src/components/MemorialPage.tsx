/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Heart, 
  Send, 
  Sparkles, 
  Calendar, 
  User, 
  BookOpen, 
  Check, 
  Award, 
  MessageSquareCode,
  Trash2,
  Info
} from 'lucide-react';
import { getGuestbookEntries, addGuestbookEntry, removeGuestbookEntry } from '../utils/firebase';

interface GuestbookEntry {
  id: string;
  name: string;
  message: string;
  dateStr: string;
}

export default function MemorialPage({ darkMode, globalPrayCount, incrementPrayCount }: { 
  darkMode: boolean; 
  globalPrayCount: number; 
  incrementPrayCount: () => void; 
}) {
  const [visitorName, setVisitorName] = useState('');
  const [visitorMsg, setVisitorMsg] = useState('');
  const [entries, setEntries] = useState<GuestbookEntry[]>([]);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [vibrateActive, setVibrateActive] = useState(false);

  // Default preloaded comforting entries for demonstration & warmth
  const defaultEntries: GuestbookEntry[] = [
    {
      id: 'm1',
      name: 'فاعل خير من بلد الحرمين',
      message: 'اللهم اغفر له وارحمه وعافه واعف عنه وأكرم نزله ووسع مدخله واغسله بالماء والثلج والبرد. في ميزان حسناته وحسنات أهله بارك الله لكم في هذا العمل الطيب المبارك.',
      dateStr: 'منذ يومين'
    },
    {
      id: 'm2',
      name: 'طالب علم',
      message: 'نسأل الله تبارك وتعالى أن يتقبل منه هذا الموقع كصدقة جارية مستمرة تضيء له قبره وتجعله في جنات الفردوس الأعلى مع النبيين والصديقين والشهداء وحسن أولئك رفيقاً.',
      dateStr: 'منذ ٣ أيام'
    }
  ];

  useEffect(() => {
    getGuestbookEntries().then(data => {
      if (data && data.length > 0) {
        setEntries(data);
      } else {
        setEntries(defaultEntries);
      }
    });
  }, []);

  const handleAddEntry = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!visitorName.trim() || !visitorMsg.trim()) return;

    const newEntry: GuestbookEntry = {
      id: `msg-${Date.now()}`,
      name: visitorName.trim(),
      message: visitorMsg.trim(),
      dateStr: new Date().toLocaleDateString('ar-SA')
    };

    try {
      await addGuestbookEntry(newEntry);
      setEntries(prev => [newEntry, ...prev]);
      setIsSubmitted(true);
      setVisitorName('');
      setVisitorMsg('');
      setTimeout(() => {
        setIsSubmitted(false);
      }, 4000);
    } catch (err) {
      console.error('Error adding guestbook entry:', err);
    }
  };

  const handlePrayClick = () => {
    incrementPrayCount();
    setVibrateActive(true);
    setTimeout(() => setVibrateActive(false), 500);

    if (navigator.vibrate) {
      navigator.vibrate(40);
    }
  };

  const handleDeleteEntry = async (id: string) => {
    try {
      await removeGuestbookEntry(id);
      setEntries(prev => prev.filter(e => e.id !== id));
    } catch (err) {
      console.error('Error removing entry:', err);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-right">
      
      {/* Golden Memorial Frame Header */}
      <div className="text-center mb-12 relative">
        <div className="inline-block p-4 rounded-full bg-[#D4AF37]/5 border border-[#D4AF37]/30 mb-4 shadow-xl">
          <span className="font-quran text-5xl font-extrabold text-[#D4AF37] block leading-none">١٩٦٠</span>
          <span className="text-[10px] text-gray-400 block mt-1 tracking-widest">تاريخ الميلاد</span>
        </div>
        <h2 className="font-quran text-4xl font-extrabold text-[#D4AF37] mb-2">عبدالناصر عمران</h2>
        <p className="text-sm text-gray-400 font-semibold italic">رحمه الله تبارك وتعالى وطيب ثراه وجعل قبره روضة من رياض الجنة</p>
        
        {/* Intention statement */}
        <div className="max-w-xl mx-auto mt-6 p-4 rounded-xl bg-emerald-500/5 border border-dashed border-[#D4AF37]/25 text-xs text-emerald-300 leading-relaxed">
          "تم تأسيس هذا الموقع المبارك كصدقة جارية ممتدة ومستمرة تبتغي مرضاة الله ومغفرته على روح الوالد والفقيد الغالي عبدالناصر عمران، نسأل الله الكريم أن يتقبلها قبولاً حسناً ويجعل كل تلاوة واستغفار وذكر فيه في ميزان حسناته."
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left columns: Profile, Bio, and Active Prayer Clicker */}
        <div className="lg:col-span-1 space-y-6">
          
          {/* Profile details */}
          <div className={`p-6 rounded-2xl border text-center relative overflow-hidden ${
            darkMode ? 'glass-card-dark' : 'glass-card-light'
          }`}>
            <div className="absolute inset-0 islamic-pattern opacity-[0.03] pointer-events-none" />
            
            <div className="relative w-28 h-28 mx-auto rounded-full bg-gradient-to-tr from-emerald-950 to-[#0a2318] border-2 border-[#D4AF37] flex items-center justify-center shadow-lg mb-4">
              <span className="font-quran text-4xl text-[#D4AF37] font-semibold select-none">ع</span>
            </div>

            <h3 className={`text-base font-bold ${darkMode ? 'text-white' : 'text-emerald-950'} mb-1`}>المغفور له بإذن الله</h3>
            <p className="text-xs text-gray-400 font-semibold mb-4">عبدالناصر عمران</p>
            
            <p className="text-xs text-gray-300 leading-relaxed border-t border-dashed border-[#D4AF37]/10 pt-4 text-right">
              رجل طيب السيرة، مخلص لوطنه وأسرته، محب للخير والقرآن وأهله. انتقل إلى رحمة الله مخلفاً وراءه أثراً طيباً وذرية صالحة تدعو له وتبره بالخير والصدقات. نسألكم صادق الدعاء له في سجودكم وخلواتكم.
            </p>
          </div>

          {/* Interactive Pray Clicker (أهديت دعاءً) */}
          <div className="bg-gradient-to-b from-[#09150f] to-[#040a07] border border-[#D4AF37]/20 rounded-2xl p-6 text-center text-white relative overflow-hidden shadow-xl">
            <div className="absolute inset-0 islamic-pattern-dense opacity-[0.03]" />
            
            <span className="text-[9px] text-[#D4AF37] border border-[#D4AF37]/25 px-2.5 py-0.5 rounded-full bg-[#D4AF37]/5 mb-3 inline-block">
              دعاء الزوار الروحي
            </span>

            <h4 className="text-xs text-gray-400 font-semibold mb-2">إجمالي الأدعية والصلوات المهدية لروحه</h4>
            
            <motion.div 
              key={globalPrayCount}
              initial={{ scale: 0.9, opacity: 0.8 }}
              animate={{ scale: 1, opacity: 1 }}
              className="text-4xl font-mono font-extrabold text-[#D4AF37] tracking-wider mb-6"
            >
              {globalPrayCount}
            </motion.div>

            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={handlePrayClick}
              className={`w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-[#D4AF37] hover:opacity-95 text-emerald-950 font-extrabold text-sm flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-[#D4AF37]/10 ${vibrateActive ? 'animate-bounce' : ''}`}
            >
              <Heart className="w-5 h-5 fill-current text-emerald-950" />
              <span>أهديتُ دعاءً وقرأتُ الفاتحة لروحه</span>
            </motion.button>
          </div>

        </div>

        {/* Right columns: Sincere Guestbook (سجل التعازي والمواساة والصلوات) */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Guestbook Form */}
          <div className={`p-6 rounded-2xl border ${
            darkMode ? 'glass-card-dark' : 'glass-card-light'
          }`}>
            <h3 className={`text-base font-bold mb-4 flex items-center gap-2 ${darkMode ? 'text-[#D4AF37]' : 'text-emerald-950'}`}>
              <MessageSquareCode className="w-5 h-5 text-[#D4AF37]" />
              <span>شاركنا دعوة صادقة أو رسالة مواساة</span>
            </h3>

            <form onSubmit={handleAddEntry} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] text-gray-400 block mb-1 font-semibold">اسمك أو كنيتك (اختياري)</label>
                  <input
                    type="text"
                    placeholder="مثال: فاعل خير، محب للفقيد..."
                    value={visitorName}
                    onChange={(e) => setVisitorName(e.target.value)}
                    className={`w-full p-2.5 rounded-lg border text-sm text-right focus:outline-none focus:ring-1 focus:ring-[#D4AF37] ${
                      darkMode ? 'bg-emerald-950/30 border-[#D4AF37]/20 text-white' : 'bg-slate-50 border-emerald-100 text-emerald-950'
                    }`}
                  />
                </div>
                <div>
                  <label className="text-[10px] text-gray-400 block mb-1 font-semibold">نوع المشاركة</label>
                  <select
                    className={`w-full p-2.5 rounded-lg border text-sm text-right focus:outline-none focus:ring-1 focus:ring-[#D4AF37] ${
                      darkMode ? 'bg-emerald-950/30 border-[#D4AF37]/20 text-[#D4AF37]' : 'bg-slate-50 border-emerald-100 text-emerald-950'
                    }`}
                  >
                    <option>دعاء واستغفار</option>
                    <option>تعزية مواساة</option>
                    <option>كلمة طيبة لروح الفقيد</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[10px] text-gray-400 block mb-1 font-semibold">نص الدعاء أو الكلمة الطيبة</label>
                <textarea
                  required
                  rows={3}
                  placeholder="اكتب دعاءك الخالص لروحه هنا..."
                  value={visitorMsg}
                  onChange={(e) => setVisitorMsg(e.target.value)}
                  className={`w-full p-2.5 rounded-lg border text-sm text-right focus:outline-none focus:ring-1 focus:ring-[#D4AF37] ${
                    darkMode ? 'bg-emerald-950/30 border-[#D4AF37]/20 text-white' : 'bg-slate-50 border-emerald-100 text-emerald-950'
                  }`}
                />
              </div>

              <div className="flex justify-between items-center">
                <div className="text-[10px] text-gray-400 flex items-center gap-1">
                  <Info className="w-3.5 h-3.5 text-amber-500" />
                  <span>ستظهر رسالتك في سجل التعازي العام للزوار فوراً.</span>
                </div>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>إرسال وتوثيق المشاركة</span>
                </button>
              </div>
            </form>

            <AnimatePresence>
              {isSubmitted && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="mt-4 p-3 rounded-lg bg-emerald-600/10 border border-emerald-500/20 text-xs text-emerald-400 font-bold text-center"
                >
                  تم تدوين رسالتك ودعائك في سجل السلف الصالح بنجاح. بارك الله فيك وعظم أجرك!
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Sincere Timeline logs list */}
          <div className="space-y-4">
            <h4 className="text-xs font-bold text-gray-400">سجل دعاء الزوار والتعازي المكتوبة:</h4>
            
            <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
              {entries.map((item) => (
                <div
                  key={item.id}
                  className={`p-4 rounded-xl border text-right relative overflow-hidden transition-all ${
                    darkMode 
                      ? 'glass-card-dark hover:border-[#D4AF37]/30' 
                      : 'glass-card-light hover:shadow-md text-emerald-950'
                  }`}
                >
                  <div className="flex justify-between items-center mb-2">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-emerald-500/10 flex items-center justify-center">
                        <User className="w-3.5 h-3.5 text-[#D4AF37]" />
                      </div>
                      <span className="text-xs font-bold text-[#D4AF37]">{item.name || 'فاعل خير'}</span>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <span className="text-[9px] text-gray-500 font-mono">{item.dateStr}</span>
                      {item.id.startsWith('msg-') && (
                        <button
                          onClick={() => handleDeleteEntry(item.id)}
                          className="p-1 text-red-400 hover:bg-red-500/10 rounded"
                          title="حذف رسالتك"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  </div>

                  <p className="text-xs sm:text-sm text-gray-300 leading-relaxed font-semibold">
                    "{item.message}"
                  </p>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
