/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Heart, 
  BookOpen, 
  Award, 
  ExternalLink, 
  MapPin, 
  Clock, 
  Sparkles, 
  UserCheck, 
  Eye, 
  Info,
  Calendar
} from 'lucide-react';

// Component imports
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import QuranReader from './components/QuranReader';
import AzkarLibrary from './components/AzkarLibrary';
import DuaLibrary from './components/DuaLibrary';
import DigitalTasbeeh from './components/DigitalTasbeeh';
import PrayerTools from './components/PrayerTools';
import HadithAndNames from './components/HadithAndNames';
import IslamicStories from './components/IslamicStories';
import AudioLibrary from './components/AudioLibrary';
import LiveContent from './components/LiveContent';
import MemorialPage from './components/MemorialPage';
import AdminDashboard from './components/AdminDashboard';
import AdditionalPages from './components/AdditionalPages';
import { seedDatabaseIfEmpty } from './utils/firebase';

export default function App() {
  const [currentTab, setCurrentTab] = useState<string>('home');
  const [darkMode, setDarkMode] = useState<boolean>(true);
  
  // Spiritual metrics counters
  const [tasbeehCount, setTasbeehCount] = useState<number>(0);
  const [quranReadCount, setQuranReadCount] = useState<number>(0);
  const [prayCount, setPrayCount] = useState<number>(142); // starts with preloaded visitor count for warmth

  // Search redirection state
  const [searchSurahId, setSearchSurahId] = useState<number | null>(null);

  // Sync states on mount from localStorage and trigger seed
  useEffect(() => {
    seedDatabaseIfEmpty();

    const savedDark = localStorage.getItem('sadaqah_dark_mode');
    if (savedDark !== null) {
      setDarkMode(savedDark === 'true');
    }

    const savedTasbeeh = localStorage.getItem('sadaqah_total_tasbeeh_count');
    if (savedTasbeeh) setTasbeehCount(Number(savedTasbeeh));

    const savedQuran = localStorage.getItem('sadaqah_total_quran_read_count');
    if (savedQuran) setQuranReadCount(Number(savedQuran));

    const savedPray = localStorage.getItem('sadaqah_global_pray_count');
    if (savedPray) setPrayCount(Number(savedPray));
  }, []);

  // Save theme on toggle
  useEffect(() => {
    localStorage.setItem('sadaqah_dark_mode', String(darkMode));
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const handleIncrementTasbeeh = () => {
    const nextVal = tasbeehCount + 1;
    setTasbeehCount(nextVal);
    localStorage.setItem('sadaqah_total_tasbeeh_count', String(nextVal));
  };

  const handleIncrementQuranRead = () => {
    const nextVal = quranReadCount + 1;
    setQuranReadCount(nextVal);
    localStorage.setItem('sadaqah_total_quran_read_count', String(nextVal));
  };

  const handleIncrementPray = () => {
    const nextVal = prayCount + 1;
    setPrayCount(nextVal);
    localStorage.setItem('sadaqah_global_pray_count', String(nextVal));
  };

  const handleSearchSelect = (type: string, id: any) => {
    if (type === 'quran') {
      setSearchSurahId(Number(id));
      setCurrentTab('quran');
    } else if (type === 'azkar') {
      setCurrentTab('azkar');
    } else if (type === 'duas') {
      setCurrentTab('duas');
    } else if (type === 'hadith') {
      setCurrentTab('hadith');
    }
  };

  return (
    <div 
      className={`min-h-screen flex flex-col font-sans transition-all duration-300 relative ${
        darkMode ? 'bg-[#040c08] text-[#f1f5f3]' : 'bg-[#faf8f4] text-[#0a2016]'
      }`}
      style={darkMode ? { backgroundImage: 'radial-gradient(circle at top left, #081a12 0%, #040c08 100%)' } : {}}
    >
      {/* Ambient geometric pattern overlay */}
      <div className={`absolute inset-0 islamic-pattern pointer-events-none z-0 ${
        darkMode ? 'opacity-[0.06]' : 'opacity-[0.04]'
      }`} />
      
      {/* Golden announcement header bar */}
      <div className="bg-gradient-to-r from-emerald-950 via-[#0a2618] to-emerald-950 text-center py-2 px-4 border-b border-[#D4AF37]/20 text-[11px] sm:text-xs font-semibold text-[#D4AF37] flex items-center justify-center gap-2 relative overflow-hidden z-50">
        <Sparkles className="w-4 h-4 text-[#D4AF37] animate-pulse" />
        <span className="font-quran">"وَمَا تُقَدِّمُوا لِأَنفُسِكُم مِّنْ خَيْرٍ تَجِدُوهُ عِندَ اللَّهِ هُوَ خَيْرًا وَأَعْظَمَ أَجْرًا"</span>
        <span className="hidden md:inline-block border-r border-[#D4AF37]/30 h-3 mx-2" />
        <span className="hidden md:inline-block font-sans">صدقة جارية ممتدة على روح الوالد عبدالناصر عمران رحمه الله</span>
      </div>

      {/* Main Navbar */}
      <Navbar 
        currentTab={currentTab} 
        setTab={(tab) => {
          setCurrentTab(tab);
          // clear previous search Surah trigger when navigating manually
          if (tab !== 'quran') setSearchSurahId(null);
        }}
        darkMode={darkMode} 
        setDarkMode={setDarkMode}
        stats={{ tasbeehCount, quranReadCount }}
      />

      {/* Content wrapper with motion rendering */}
      <main className="flex-grow">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentTab}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.25, ease: 'easeOut' }}
          >
            {currentTab === 'home' && (
              <Hero 
                darkMode={darkMode} 
                setTab={setCurrentTab} 
                onSearchSelect={handleSearchSelect} 
              />
            )}
            {currentTab === 'quran' && (
              <QuranReader 
                darkMode={darkMode} 
                activeSurahId={searchSurahId}
                incrementQuranReadCount={handleIncrementQuranRead}
              />
            )}
            {currentTab === 'azkar' && (
              <AzkarLibrary 
                darkMode={darkMode} 
              />
            )}
            {currentTab === 'duas' && (
              <DuaLibrary 
                darkMode={darkMode} 
              />
            )}
            {currentTab === 'tasbeeh' && (
              <DigitalTasbeeh 
                darkMode={darkMode} 
                incrementTasbeehCount={handleIncrementTasbeeh}
              />
            )}
            {currentTab === 'prayer' && (
              <PrayerTools 
                darkMode={darkMode} 
              />
            )}
            {currentTab === 'hadith' && (
              <HadithAndNames 
                darkMode={darkMode} 
              />
            )}
            {currentTab === 'stories' && (
              <IslamicStories 
                darkMode={darkMode} 
              />
            )}
            {currentTab === 'audio' && (
              <AudioLibrary 
                darkMode={darkMode} 
              />
            )}
            {currentTab === 'live' && (
              <LiveContent 
                darkMode={darkMode} 
              />
            )}
            {currentTab === 'memorial' && (
              <MemorialPage 
                darkMode={darkMode} 
                globalPrayCount={prayCount}
                incrementPrayCount={handleIncrementPray}
              />
            )}
            {currentTab === 'admin' && (
              <AdminDashboard 
                darkMode={darkMode} 
                globalPrayCount={prayCount}
                totalTasbeehCount={tasbeehCount}
              />
            )}
            {currentTab === 'additional' && (
              <AdditionalPages 
                darkMode={darkMode} 
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Stunning luxury Islamic Footer */}
      <footer className={`mt-16 border-t transition-all duration-300 ${
        darkMode 
          ? 'bg-[#040e08]/90 border-[#D4AF37]/10 backdrop-blur-md text-gray-400' 
          : 'bg-emerald-950 text-emerald-100 border-emerald-900'
      }`}>
        <div className="absolute inset-0 islamic-pattern opacity-[0.02] pointer-events-none" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 relative z-10 text-right">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 border-b border-gray-500/10 pb-8">
            
            {/* Column 1: Website details */}
            <div className="space-y-4">
              <h4 className="font-quran text-[#D4AF37] text-lg font-bold">صدقة جارية على روح عبدالناصر عمران</h4>
              <p className="text-xs leading-relaxed max-w-sm">
                موقع إسلامي متكامل مجاني ووقف خيري خالص مهدى لروح الوالد والفقيد الغالي عبدالناصر عمران رحمه الله وطيب ثراه، راجين من الله تبارك وتعالى القبول والمغفرة.
              </p>
            </div>

            {/* Column 2: Quick Links */}
            <div className="space-y-3">
              <h4 className="font-sans text-[#D4AF37] text-xs font-bold tracking-widest uppercase">روابط وتسهيلات سريعة</h4>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <button onClick={() => setCurrentTab('quran')} className="text-right hover:text-[#D4AF37] transition-colors cursor-pointer">📖 القرآن الكريم</button>
                <button onClick={() => setCurrentTab('azkar')} className="text-right hover:text-[#D4AF37] transition-colors cursor-pointer">🌅 الأذكار اليومية</button>
                <button onClick={() => setCurrentTab('duas')} className="text-right hover:text-[#D4AF37] transition-colors cursor-pointer">❤️ الأدعية المستجابة</button>
                <button onClick={() => setCurrentTab('tasbeeh')} className="text-right hover:text-[#D4AF37] transition-colors cursor-pointer">📿 المسبحة الإلكترونية</button>
                <button onClick={() => setCurrentTab('prayer')} className="text-right hover:text-[#D4AF37] transition-colors cursor-pointer">🕋 مواقيت الصلاة والقبلة</button>
                <button onClick={() => setCurrentTab('memorial')} className="text-right hover:text-[#D4AF37] transition-colors cursor-pointer">🕯️ صفحة الوالد الفقيد</button>
              </div>
            </div>

            {/* Column 3: Intention & Copyright */}
            <div className="space-y-4">
              <h4 className="font-sans text-[#D4AF37] text-xs font-bold tracking-widest uppercase">الورد الإيماني العام</h4>
              <p className="text-xs leading-relaxed">
                نسأل الله العلي العظيم أن يجازي كل زائر وقارئ ومستمع بالخير والبركة، وأن يجعل دعواتكم الصادقة نوراً وضياءً لقبر والدنا الحبيب.
              </p>
              <div className="flex gap-2 justify-start">
                <button 
                  onClick={() => setCurrentTab('additional')}
                  className="text-xs font-bold text-[#D4AF37] hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <span>اقرأ سياسة الأمان والاتصال</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

          </div>

          <div className="pt-8 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs">
            <div>
              © {new Date().getFullYear()} صدقة جارية على روح عبدالناصر عمران. جميع الحقوق والجهود وقوف لوجه الله تعالى ومباحة مجاناً لتعميم المنفعة.
            </div>
            
            <div className="text-gray-500 text-[10px] flex items-center gap-1 font-mono">
              <span>توقيت الخادم الموحد: {new Date().toLocaleTimeString('ar-EG', { hour12: false })} UTC</span>
            </div>
          </div>
        </div>
      </footer>

    </div>
  );
}
