/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Info, 
  Mail, 
  ShieldCheck, 
  FileText, 
  Send, 
  MapPin, 
  ExternalLink,
  Award,
  Sparkles,
  CheckCircle,
  HelpCircle
} from 'lucide-react';

export default function AdditionalPages({ darkMode }: { darkMode: boolean }) {
  const [activeTab, setActiveTab] = useState<'about' | 'contact' | 'privacy' | 'terms'>('about');
  const [email, setEmail] = useState('');
  const [msg, setMsg] = useState('');
  const [sentSuccess, setSentSuccess] = useState(false);

  const handleSendFeedback = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !msg) return;

    setSentSuccess(true);
    setEmail('');
    setMsg('');
    setTimeout(() => setSentSuccess(false), 4000);
  };

  const tabs = [
    { id: 'about', label: 'ℹ️ عن الموقع والأثر', icon: Info },
    { id: 'contact', label: '📧 راسلنا وتواصل معنا', icon: Mail },
    { id: 'privacy', label: '🔒 سياسة الخصوصية الأمان', icon: ShieldCheck },
    { id: 'terms', label: '📝 شروط الاستخدام والأحكام', icon: FileText }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-right">
      
      {/* Category selector */}
      <div className="flex gap-2 overflow-x-auto pb-4 mb-10 scrollbar-thin scrollbar-thumb-[#D4AF37]">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = tab.id === activeTab;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all duration-200 cursor-pointer whitespace-nowrap border flex items-center gap-2 ${
                isActive 
                  ? 'bg-gradient-to-r from-emerald-800 to-[#D4AF37]/20 border-[#D4AF37] text-[#D4AF37]' 
                  : darkMode 
                    ? 'bg-emerald-950/20 border-[#D4AF37]/10 text-gray-300 hover:bg-emerald-950/40' 
                    : 'bg-white border-emerald-50 text-emerald-950 hover:bg-emerald-50'
              }`}
            >
              <Icon className="w-4 h-4 text-[#D4AF37]" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Main Container Switch */}
      <div className="max-w-3xl mx-auto">
        
        {activeTab === 'about' && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`p-6 sm:p-8 rounded-2xl border space-y-6 ${
              darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950 shadow-sm'
            }`}
          >
            <div className="border-b border-[#D4AF37]/15 pb-4">
              <h3 className="font-quran text-2xl font-bold text-[#D4AF37]">صدقة جارية على روح عبدالناصر عمران</h3>
              <p className="text-xs text-gray-400 mt-1">قصة الفكرة، النية، والغاية من تشييد هذا الصرح الإيماني</p>
            </div>

            <p className="text-sm leading-relaxed text-gray-300 text-right">
              إن أعظم ما يقدمه المسلم لأخيه أو والده المتوفى هو الدعاء الصادق والعمل الصالح الممتد الذي لا ينقطع برحيله عن الدنيا. انطلاقاً من قول نبينا الكريم محمد ﷺ:
              <span className="block font-bold text-[#D4AF37] my-3 text-center italic">
                "إِذَا مَاتَ الإنْسَانُ انْقَطَعَ عنْه عَمَلُهُ إِلَّا مِن ثَلَاثٍ: إِلَّا مِن صَدَقَةٍ جَارِيَةٍ، أَوْ عِلْمٍ يُنْتَفَعُ بِهِ، أَوْ وَلَدٍ صَالِحٍ يَدْعُو له"
              </span>
              تم تشييد هذا الموقع المتكامل وتجهيزه ليكون منبراً لنشر القرآن الكريم، الأذكار، الأدعية، والمواعظ، راجين من الله تبارك وتعالى أن يتقبل ثواب كل حرف وتلاوة واستغفار كأجر ممتد وضياء متواصل ينير قبر فقيدنا الغالي الوالد <span className="font-bold text-[#D4AF37]">عبدالناصر عمران</span>.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
              <div className="p-4 rounded-xl bg-emerald-500/5 border border-emerald-500/10 text-xs">
                <span className="font-bold text-[#D4AF37] block mb-1">🎯 غايتنا السامية:</span>
                توفير منصة إسلامية نقية، راقية التصميم، خالية تماماً من الإعلانات والمشتتات، تعين المسلم على طاعته اليومية وتخليد ذكر أحبته الراحلين.
              </div>
              <div className="p-4 rounded-xl bg-emerald-500/5 border border-emerald-500/10 text-xs">
                <span className="font-bold text-[#D4AF37] block mb-1">🎁 دعوة للمشاركة:</span>
                مساهمتكم بنشر رابط الموقع بين أحبتكم وعبر شبكات التواصل هي دعم مبارك لهذا العمل الخيري لتعميم النفع وثواب الصدقة الجارية.
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === 'contact' && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`p-6 sm:p-8 rounded-2xl border space-y-6 ${
              darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950 shadow-sm'
            }`}
          >
            <div className="border-b border-[#D4AF37]/15 pb-4">
              <h3 className="font-quran text-2xl font-bold text-[#D4AF37]">تواصل معنا وشاركنا مقترحاتك</h3>
              <p className="text-xs text-gray-400 mt-1">يسعدنا تلقي طلباتكم لإضافة قراء جدد أو تصحيحات للمحتوى</p>
            </div>

            <form onSubmit={handleSendFeedback} className="space-y-4">
              <div>
                <label className="text-[10px] text-gray-400 block mb-1 font-semibold">بريدك الإلكتروني للتواصل</label>
                <input
                  type="email"
                  required
                  placeholder="name@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className={`w-full p-2.5 rounded-lg border text-sm text-right focus:outline-none focus:ring-1 focus:ring-[#D4AF37] ${
                    darkMode ? 'bg-emerald-950/30 border-[#D4AF37]/20 text-white' : 'bg-slate-50 border-emerald-100 text-emerald-950'
                  }`}
                />
              </div>

              <div>
                <label className="text-[10px] text-gray-400 block mb-1 font-semibold">تفاصيل الرسالة أو المقترح</label>
                <textarea
                  required
                  rows={4}
                  placeholder="اكتب مقترحاتك أو ملاحظاتك البناءة هنا لتطوير الوقف الخيري..."
                  value={msg}
                  onChange={(e) => setMsg(e.target.value)}
                  className={`w-full p-2.5 rounded-lg border text-sm text-right focus:outline-none focus:ring-1 focus:ring-[#D4AF37] ${
                    darkMode ? 'bg-emerald-950/30 border-[#D4AF37]/20 text-white' : 'bg-slate-50 border-emerald-100 text-emerald-950'
                  }`}
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>إرسال الرسالة للإدارة</span>
              </button>
            </form>

            <AnimatePresence>
              {sentSuccess && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="p-3 rounded-lg bg-emerald-600/10 border border-emerald-500/20 text-xs text-emerald-400 font-bold text-center"
                >
                  لقد استلمنا رسالتك المباركة بنجاح. سنقوم بالرد ومراجعة مقترحاتك الإيمانية قريباً إن شاء الله.
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}

        {activeTab === 'privacy' && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`p-6 sm:p-8 rounded-2xl border space-y-6 ${
              darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950 shadow-sm'
            }`}
          >
            <div className="border-b border-[#D4AF37]/15 pb-4">
              <h3 className="font-quran text-2xl font-bold text-[#D4AF37]">سياسة الخصوصية وأمان البيانات</h3>
              <p className="text-xs text-gray-400 mt-1">تعهدنا بالحفاظ التام على خصوصيتكم وخصوصية بيانات التصفح</p>
            </div>

            <div className="space-y-4 text-xs sm:text-sm text-gray-300 leading-relaxed text-right">
              <div className="flex gap-2 items-start">
                <CheckCircle className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
                <span><strong>بيانات محلية آمنة بنسبة ١٠٠%:</strong> نقوم بحفظ التفضيلات وقوائم المحفوظات، وعلامات قراءة القرآن وتعداد التسبيح في الذاكرة المحلية لمتصفحك فقط (localStorage) ولا نرسلها لأي خادم لضمان أقصى حماية وخصوصية.</span>
              </div>
              <div className="flex gap-2 items-start">
                <CheckCircle className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
                <span><strong>خلو تام من ملفات تعريف الارتباط التتبعية:</strong> الموقع لا يحتوي على أدوات تتبع خارجية، ولا نبيع أو نشارك بيانات التصفح مع أي طرف ثالث على الإطلاق.</span>
              </div>
              <div className="flex gap-2 items-start">
                <CheckCircle className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
                <span><strong>أمان وموثوقية الاتصال:</strong> يتم تأمين جميع الاتصالات ونقل البيانات باستخدام بروتوكول التشفير المعتمد والآمن HTTPS لحمايتكم أثناء الزيارة.</span>
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === 'terms' && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`p-6 sm:p-8 rounded-2xl border space-y-6 ${
              darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950 shadow-sm'
            }`}
          >
            <div className="border-b border-[#D4AF37]/15 pb-4">
              <h3 className="font-quran text-2xl font-bold text-[#D4AF37]">شروط وأحكام الاستخدام العامة</h3>
              <p className="text-xs text-gray-400 mt-1">الضوابط والعهود القانونية والشرعية المنظمة لتصفح الوقف الخيري</p>
            </div>

            <div className="space-y-4 text-xs sm:text-sm text-gray-300 leading-relaxed text-right">
              <div className="flex gap-2 items-start">
                <CheckCircle className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
                <span><strong>استخدام مجاني وغير تجاري مطلق:</strong> هذا الموقع وقف خيري كامل، ولا يجوز استغلال أي جزء من رموزه البرمجية أو محتوياته المكتوبة والصوتية في أغراض ربحية أو تجارية بأي شكل من الأشكال.</span>
              </div>
              <div className="flex gap-2 items-start">
                <CheckCircle className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
                <span><strong>حقوق الملكية والنشر للمحتوى:</strong> جميع النصوص مقتبسة من مصادر معتمدة وموثوقة من الكتاب والسنة المطهرة. يُسمح بنسخ ومشاركة جميع النصوص بحرية تامة رغبة في الأجر وتداول المنفعة.</span>
              </div>
              <div className="flex gap-2 items-start">
                <CheckCircle className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
                <span><strong>المسؤولية الإدارية:</strong> تسعى إدارة الموقع بكل جهدها للحفاظ على سلامة وبناء وصحة جميع النصوص والتفاسير الملحقة، ونرحب دائماً بأي تنبيهات من زوارنا الأفاضل لتصحيح أي خطأ غير مقصود فوراً.</span>
              </div>
            </div>
          </motion.div>
        )}

      </div>

    </div>
  );
}
