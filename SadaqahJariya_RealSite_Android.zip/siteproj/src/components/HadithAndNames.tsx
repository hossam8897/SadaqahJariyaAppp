/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Award, 
  Search, 
  Share2, 
  Copy, 
  Check, 
  HelpCircle, 
  Compass, 
  BookOpen, 
  Heart,
  Smile,
  ChevronDown,
  Info
} from 'lucide-react';
import { hadithsData as baseHadithsData, namesOfAllah as baseNamesOfAllah } from '../data/islamicData';
import { copyToClipboard } from '../utils/helpers';
import { getHadiths } from '../utils/firebase';

export default function HadithAndNames({ darkMode }: { darkMode: boolean }) {
  const [hadiths, setHadiths] = useState<any[]>(baseHadithsData);
  const [activeSection, setActiveSection] = useState<'hadith' | 'names'>('hadith');
  const [hadithSearch, setHadithSearch] = useState('');
  const [hadithCategory, setHadithCategory] = useState('الكل');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [hadithFavs, setHadithFavs] = useState<string[]>([]);
  
  // 99 Names states
  const [nameSearch, setNameSearch] = useState('');
  const [selectedName, setSelectedName] = useState<any | null>(null);

  useEffect(() => {
    getHadiths().then(data => {
      if (data && data.length > 0) {
        setHadiths(data);
      }
    });
  }, []);

  useEffect(() => {
    const saved = localStorage.getItem('sadaqah_hadith_favorites');
    if (saved) setHadithFavs(JSON.parse(saved));
  }, []);

  const toggleHadithFav = (id: string) => {
    let updated;
    if (hadithFavs.includes(id)) {
      updated = hadithFavs.filter(h => h !== id);
    } else {
      updated = [...hadithFavs, id];
    }
    setHadithFavs(updated);
    localStorage.setItem('sadaqah_hadith_favorites', JSON.stringify(updated));
  };

  const triggerCopy = (text: string, id: string) => {
    copyToClipboard(text).then(() => {
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    });
  };

  // 1. Hadith Categories
  const categories = ['الكل', 'الصدقة والعمل الصالح', 'فضل قراءة القرآن', 'فضل الاستغفار للمتوفى'];
  const filteredHadiths = hadiths.filter(h => {
    const matchesCat = hadithCategory === 'الكل' || h.category === hadithCategory;
    const matchesSearch = h.text.includes(hadithSearch) || h.narrator?.includes(hadithSearch) || h.explanation?.includes(hadithSearch);
    return matchesCat && matchesSearch;
  });

  // 2. Names of Allah filter
  const filteredNames = baseNamesOfAllah.filter(n => 
    n.name.includes(nameSearch) || n.meaning.includes(nameSearch) || n.explanation.includes(nameSearch)
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-right">
      
      {/* Selector tab */}
      <div className="flex justify-center mb-10">
        <div className={`p-1 rounded-xl border flex ${
          darkMode ? 'bg-emerald-950/40 border-[#D4AF37]/20' : 'bg-slate-100 border-emerald-50'
        }`}>
          <button
            onClick={() => setActiveSection('hadith')}
            className={`px-6 py-2.5 rounded-lg text-sm font-bold transition-all cursor-pointer ${
              activeSection === 'hadith'
                ? 'bg-gradient-to-r from-emerald-800 to-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/20'
                : darkMode ? 'text-gray-400 hover:text-white' : 'text-emerald-950 hover:text-emerald-800'
            }`}
          >
            الأحاديث النبوية الشريفة
          </button>
          <button
            onClick={() => setActiveSection('names')}
            className={`px-6 py-2.5 rounded-lg text-sm font-bold transition-all cursor-pointer ${
              activeSection === 'names'
                ? 'bg-gradient-to-r from-emerald-800 to-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/20'
                : darkMode ? 'text-gray-400 hover:text-white' : 'text-emerald-950 hover:text-emerald-800'
            }`}
          >
            أسماء الله الحسنى ٩٩
          </button>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {activeSection === 'hadith' ? (
          /* Hadith Section */
          <motion.div
            key="hadith-section"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="space-y-6"
          >
            {/* Search and Category Filter */}
            <div className="flex flex-col md:flex-row justify-between items-center gap-4 mb-6">
              {/* Search box */}
              <div className="relative w-full md:max-w-md">
                <input
                  type="text"
                  placeholder="ابحث عن حديث شريف..."
                  value={hadithSearch}
                  onChange={(e) => setHadithSearch(e.target.value)}
                  className={`w-full py-3 pr-12 pl-4 rounded-xl border focus:outline-none focus:ring-2 transition-all ${
                    darkMode 
                      ? 'bg-emerald-950/40 border-[#D4AF37]/20 text-white placeholder-emerald-300/40 focus:ring-[#D4AF37]/50' 
                      : 'bg-white border-emerald-100 text-emerald-950 focus:ring-emerald-500/50'
                  }`}
                />
                <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#D4AF37]" />
              </div>

              {/* Categories list */}
              <div className="flex gap-2 overflow-x-auto w-full md:w-auto scrollbar-none pb-2">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setHadithCategory(cat)}
                    className={`px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap cursor-pointer transition-all ${
                      hadithCategory === cat 
                        ? 'bg-emerald-500/15 border-[#D4AF37]/40 text-[#D4AF37]' 
                        : darkMode ? 'bg-emerald-950/20 text-gray-400 border border-transparent' : 'bg-slate-100 text-emerald-950 border border-transparent'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Hadiths Listing */}
            {filteredHadiths.length === 0 ? (
              <div className="text-center py-12 text-gray-400">
                <Info className="w-8 h-8 text-amber-500 mx-auto mb-2" />
                <span>لا توجد أحاديث تطابق بحثك حالياً.</span>
              </div>
            ) : (
              <div className="space-y-6">
                {filteredHadiths.map((h) => {
                  const hasFav = hadithFavs.includes(h.id);
                  return (
                    <motion.div
                      key={h.id}
                      layout
                      className={`p-6 rounded-2xl border text-right relative overflow-hidden ${
                        darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950'
                      }`}
                    >
                      <span className="text-xs bg-[#D4AF37]/10 text-[#D4AF37] border border-[#D4AF37]/20 px-2.5 py-0.5 rounded-full font-bold mb-3 inline-block">
                        {h.category}
                      </span>
                      
                      {/* Hadith scripture */}
                      <p className="text-base sm:text-lg leading-relaxed text-emerald-950 dark:text-emerald-100 font-bold italic mb-4 text-center border-b border-dashed border-[#D4AF37]/10 pb-4">
                        قال رسول الله ﷺ: "{h.text}"
                      </p>

                      {/* Explanation */}
                      {h.explanation && (
                        <div className="text-xs text-gray-400 leading-relaxed mb-4">
                          <span className="font-bold text-[#D4AF37]">الشرح والتفسير:</span> {h.explanation}
                        </div>
                      )}

                      <div className="flex items-center justify-between pt-3 border-t border-[#D4AF37]/10">
                        <span className="text-xs text-gray-400">الراوي: {h.narrator} | المصدر: {h.source}</span>
                        <div className="flex gap-2">
                          {/* Copy */}
                          <button
                            onClick={() => triggerCopy(`عن ${h.narrator} قال: قال رسول الله ﷺ: "${h.text}" [${h.source}]`, h.id)}
                            className="p-1.5 rounded-lg border border-[#D4AF37]/15 text-gray-400 hover:bg-[#D4AF37]/10 transition-colors cursor-pointer"
                            title="نسخ للحديث"
                          >
                            {copiedId === h.id ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                          </button>
                          {/* Fav */}
                          <button
                            onClick={() => toggleHadithFav(h.id)}
                            className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                              hasFav 
                                ? 'bg-rose-500/10 text-rose-500 border-rose-500/30' 
                                : 'border-[#D4AF37]/15 text-gray-400 hover:bg-[#D4AF37]/10'
                            }`}
                            title="حفظ"
                          >
                            <Heart className="w-4 h-4 fill-current" />
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            )}
          </motion.div>
        ) : (
          /* Names of Allah Section */
          <motion.div
            key="names-section"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="space-y-6"
          >
            {/* Search filter for Names */}
            <div className="relative max-w-md mx-auto mb-8">
              <input
                type="text"
                placeholder="ابحث عن اسم من أسماء الله الحسنى ومعناه..."
                value={nameSearch}
                onChange={(e) => setNameSearch(e.target.value)}
                className={`w-full py-3 pr-12 pl-4 rounded-xl border focus:outline-none focus:ring-2 transition-all ${
                  darkMode 
                    ? 'bg-emerald-950/40 border-[#D4AF37]/20 text-white placeholder-emerald-300/40 focus:ring-[#D4AF37]/50' 
                      : 'bg-white border-emerald-100 text-emerald-950 focus:ring-emerald-500/50'
                }`}
              />
              <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#D4AF37]" />
            </div>

            {/* Grid display */}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {filteredNames.map((item) => (
                <motion.button
                  key={item.id}
                  whileHover={{ scale: 1.03, y: -2 }}
                  onClick={() => setSelectedName(item)}
                  className={`p-5 rounded-2xl border text-center cursor-pointer flex flex-col justify-between transition-all min-h-32 relative overflow-hidden group ${
                    darkMode 
                      ? 'glass-card-dark hover:border-[#D4AF37]' 
                      : 'glass-card-light hover:border-emerald-300 text-emerald-950'
                  }`}
                >
                  <div className="absolute top-2 left-2 text-[10px] text-gray-500 font-mono">#{item.id}</div>
                  
                  {/* Big Calligraphic-looking Name */}
                  <div className="font-quran text-3xl font-extrabold text-[#D4AF37] my-3 select-none group-hover:scale-110 transition-transform duration-300">
                    {item.name}
                  </div>

                  <div>
                    <div className={`text-xs font-bold leading-relaxed truncate ${darkMode ? 'text-gray-300' : 'text-emerald-950'}`}>
                      {item.meaning}
                    </div>
                  </div>
                </motion.button>
              ))}
            </div>

            {/* Expansive Details Modal popup */}
            <AnimatePresence>
              {selectedName && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm"
                >
                  <motion.div
                    initial={{ scale: 0.95, y: 15 }}
                    animate={{ scale: 1, y: 0 }}
                    exit={{ scale: 0.95, y: 15 }}
                    className={`max-w-md w-full p-6 sm:p-8 rounded-2xl border text-center relative overflow-hidden ${
                      darkMode ? 'glass-emerald-dark text-white border-[#D4AF37]/30' : 'glass-card-light text-emerald-950 border-emerald-100'
                    }`}
                  >
                    <div className="absolute top-0 right-0 p-4 font-quran text-4xl opacity-[0.03] text-[#D4AF37]">﷽</div>
                    
                    <div className="text-center mb-6">
                      <span className="text-xs text-[#D4AF37] border border-[#D4AF37]/30 px-3 py-1 rounded-full font-mono bg-emerald-500/10 font-bold mb-3 inline-block">
                        الاسم رقم {selectedName.id}
                      </span>
                      <h4 className="font-quran text-4xl font-extrabold text-[#D4AF37] mb-2">{selectedName.name}</h4>
                      <p className={`text-sm font-bold ${darkMode ? 'text-gray-200' : 'text-emerald-950'}`}>{selectedName.meaning}</p>
                    </div>

                    <div className="text-right space-y-4 mb-6">
                      <div className="p-4 rounded-xl bg-emerald-500/5 border border-emerald-500/10 text-xs leading-relaxed text-gray-300">
                        <span className="font-bold text-[#D4AF37] block mb-1">دلالة واشتقاق الاسم:</span>
                        {selectedName.explanation}
                      </div>
                    </div>

                    <div className="flex gap-3 justify-center">
                      <button
                        onClick={() => triggerCopy(`اسم الله الحسنى: { ${selectedName.name} } ومعناه: ${selectedName.meaning}. دلالته: ${selectedName.explanation}`, 'name-copy')}
                        className="px-4 py-2 border border-[#D4AF37]/20 text-[#D4AF37] rounded-lg text-xs font-bold hover:bg-[#D4AF37]/10 transition-colors flex items-center gap-1.5 cursor-pointer"
                      >
                        <Copy className="w-3.5 h-3.5" />
                        <span>{copiedId === 'name-copy' ? 'تم النسخ' : 'نسخ التفسير'}</span>
                      </button>
                      <button
                        onClick={() => setSelectedName(null)}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer"
                      >
                        إغلاق
                      </button>
                    </div>
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>

          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
