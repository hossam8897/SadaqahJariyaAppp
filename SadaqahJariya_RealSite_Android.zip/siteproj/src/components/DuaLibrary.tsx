/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Heart, 
  Search, 
  Share2, 
  Copy, 
  Sparkles, 
  Check, 
  Info,
  Maximize2,
  Plus,
  Minus,
  RefreshCw,
  BookOpen,
  Award,
  BookMarked
} from 'lucide-react';
import { duasData as baseDuasData } from '../data/islamicData';
import { copyToClipboard } from '../utils/helpers';
import { DuaItem } from '../types';
import { getDuas } from '../utils/firebase';

export default function DuaLibrary({ darkMode }: { darkMode: boolean }) {
  const [duasData, setDuasData] = useState<DuaItem[]>(baseDuasData);
  const [selectedCategory, setSelectedCategory] = useState<string>('deceased');
  const [searchQuery, setSearchQuery] = useState('');
  const [favorites, setFavorites] = useState<string[]>([]);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Load from firestore on mount
  useEffect(() => {
    getDuas().then(data => {
      if (data && data.length > 0) {
        setDuasData(data);
      }
    });
  }, []);

  // Reading mode state
  const [activeReadingDua, setActiveReadingDua] = useState<DuaItem | null>(null);
  const [readingFontSize, setReadingFontSize] = useState<number>(24); // default 24px
  const [readingTheme, setReadingTheme] = useState<'emerald' | 'charcoal' | 'parchment'>('emerald');
  const [readingCounter, setReadingCounter] = useState<number>(0);

  // Random Dua generator state
  const [randomDua, setRandomDua] = useState<DuaItem | null>(null);
  const [showRandomModal, setShowRandomModal] = useState(false);

  // Initialize favorites on mount
  useEffect(() => {
    const saved = localStorage.getItem('sadaqah_duas_favorites');
    if (saved) setFavorites(JSON.parse(saved));
  }, []);

  const toggleFavorite = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    let updated;
    if (favorites.includes(id)) {
      updated = favorites.filter(f => f !== id);
    } else {
      updated = [...favorites, id];
    }
    setFavorites(updated);
    localStorage.setItem('sadaqah_duas_favorites', JSON.stringify(updated));
  };

  const triggerCopy = (text: string, id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    copyToClipboard(text).then(() => {
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    });
  };

  const triggerShare = (dua: DuaItem, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const shareText = `📌 *${dua.title}*\n\n"${dua.text}"\n\nالمصدر: ${dua.source || 'أدعية مأثورة'}\n\nصدقة جارية على روح عبدالناصر عمران رحمه الله. نسألكم الدعاء له بالرحمة والمغفرة.`;
    copyToClipboard(shareText).then(() => {
      setCopiedId(`share-${dua.id}`);
      setTimeout(() => setCopiedId(null), 2500);
    });
  };

  const handleGenerateRandomDua = () => {
    const randomIndex = Math.floor(Math.random() * duasData.length);
    setRandomDua(duasData[randomIndex]);
    setShowRandomModal(true);
  };

  const openReadingMode = (dua: DuaItem) => {
    setActiveReadingDua(dua);
    setReadingCounter(0);
  };

  // Grouped Categories for beautiful navigation
  const categoryGroups = [
    {
      title: '🌟 أدعية مخصصة وقرآنية',
      items: [
        { id: 'deceased', label: '🕯️ للميت (عبدالناصر عمران)', desc: 'أدعية الرحمة لفقيدنا' },
        { id: 'prophet_quran', label: '✨ أدعية الأنبياء من القرآن', desc: 'مناجاة الأنبياء لقضاء الحاجات' },
        { id: 'quranic', label: '📖 أدعية القرآن الكريم', desc: 'آيات الدعاء الجامعة' },
        { id: 'mercy_forgiveness', label: '🤲 الرحمة والمغفرة', desc: 'طلب العفو والغفران' },
      ]
    },
    {
      title: '☀️ عبادات وأوقات مخصوصة',
      items: [
        { id: 'morning_evening', label: '🌅 الصباح والمساء', desc: 'أدعية الحفظ اليومية' },
        { id: 'after_prayer', label: '🕌 بعد الصلاة', desc: 'أوراد الصلوات المكتوبة' },
        { id: 'tahajjud', label: '🌌 قيام الليل', desc: 'مناجاة الثلث الأخير' },
        { id: 'friday', label: '📿 يوم الجمعة', desc: 'ساعة الإجابة المباركة' },
        { id: 'ramadan', label: '🌙 رمضان', desc: 'دعوات الإفطار وليلة القدر' },
        { id: 'hajj_umrah', label: '🕋 الحج والعمرة', desc: 'تلبية وطواف ومناسك' },
      ]
    },
    {
      title: '🌿 الحياة اليومية والتحصين',
      items: [
        { id: 'sleep', label: '🛌 أدعية النوم', desc: 'أوراد ما قبل النوم' },
        { id: 'waking', label: '🌤️ أدعية الاستيقاظ', desc: 'أذكار الصباح الباكر' },
        { id: 'travel', label: '🚗 أدعية السفر', desc: 'تيسير المسير والترحال' },
        { id: 'protection', label: '🛡️ الحفظ والتحصين', desc: 'حماية النفس والأهل' },
        { id: 'repentance', label: '💎 أدعية التوبة', desc: 'الرجوع والإنابة لله' },
        { id: 'istighfar', label: '🌟 الاستغفار', desc: 'محو الخطايا وتيسير الرزق' },
      ]
    },
    {
      title: '❤️ تفريج الكروب والحوائج',
      items: [
        { id: 'rizq', label: '💰 أدعية الرزق', desc: 'طلب البركة والسعة' },
        { id: 'grief', label: '😔 تفريج الهم والحزن', desc: 'تفريج الغم والضيق' },
        { id: 'shifa', label: '🩺 أدعية الشفاء', desc: 'طلب العافية للمريض' },
        { id: 'parents', label: '👨‍👩‍👦 للوالدين', desc: 'بر الأبوين حيين وميتين' },
        { id: 'children', label: '👶 للأبناء', desc: 'صلاح وهداية الذرية' },
        { id: 'grave', label: '🪦 أدعية القبر', desc: 'الثبات عند السؤال' },
        { id: 'exams', label: '📝 الامتحانات', desc: 'تيسير الفهم والنجاح' },
        { id: 'marriage', label: '💍 أدعية الزواج', desc: 'طلب الشريك الصالح' },
      ]
    }
  ];

  // Helper lists
  const allCategoriesList = categoryGroups.flatMap(g => g.items);

  // Filter dataset
  const activeList = selectedCategory === 'favorites'
    ? duasData.filter(d => favorites.includes(d.id))
    : duasData.filter(d => d.category === selectedCategory);

  const finalFilteredList = activeList.filter(d =>
    d.text.includes(searchQuery) || d.title.includes(searchQuery)
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-right relative">
      
      {/* Header */}
      <div className="text-center mb-10">
        <h2 className="font-quran text-3xl sm:text-4xl font-extrabold text-[#D4AF37] mb-3 leading-snug">
          الموسوعة الإسلامية الشاملة للأدعية
        </h2>
        <p className={`text-sm sm:text-base ${darkMode ? 'text-gray-300' : 'text-emerald-900'} max-w-2xl mx-auto leading-relaxed`}>
          أكبر encyclopedia تفاعلية للأدعية النبوية والقرآنية مقسمة ومصنفة لتيسير القراءة والحفظ، مهدى كصدقة جارية متواصلة لروح <span className="text-[#D4AF37] font-bold">الوالد عبدالناصر عمران</span> غفر الله له ورحمه.
        </p>
      </div>

      {/* Toolbar / Search Engine & Random Dua trigger */}
      <div className="flex flex-col md:flex-row justify-between items-center gap-4 mb-8">
        {/* Search */}
        <div className="relative w-full md:max-w-xl">
          <input
            type="text"
            placeholder="ابحث في آلاف الأدعية الشريفة..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={`w-full py-3 pr-12 pl-4 rounded-xl border focus:outline-none focus:ring-2 transition-all ${
              darkMode 
                ? 'bg-emerald-950/40 border-[#D4AF37]/20 text-white placeholder-emerald-300/40 focus:ring-[#D4AF37]/50' 
                : 'bg-white border-emerald-100 text-emerald-950 focus:ring-emerald-500/50 shadow-sm'
            }`}
          />
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#D4AF37]" />
        </div>

        {/* Action controls */}
        <div className="flex gap-2 w-full md:w-auto">
          <button
            onClick={() => {
              setSelectedCategory('favorites');
              setSearchQuery('');
            }}
            className={`flex-1 md:flex-none px-4 py-3 rounded-xl text-sm font-bold border transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              selectedCategory === 'favorites'
                ? 'bg-rose-500 text-white border-rose-500'
                : darkMode
                  ? 'bg-emerald-950/20 border-[#D4AF37]/20 text-rose-400 hover:bg-emerald-950/50'
                  : 'bg-white border-emerald-100 text-rose-600 hover:bg-rose-50'
            }`}
          >
            <Heart className="w-4 h-4 fill-current" />
            <span>المفضلة ({favorites.length})</span>
          </button>

          <button
            onClick={handleGenerateRandomDua}
            className="flex-1 md:flex-none px-4 py-3 rounded-xl text-sm font-bold bg-gradient-to-r from-amber-500 to-[#D4AF37] hover:opacity-95 text-emerald-950 transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-lg shadow-[#D4AF37]/10"
          >
            <Sparkles className="w-4 h-4 text-emerald-950" />
            <span>دعاء عشوائي</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        {/* Navigation Sidebar: Structured 24 Categories with Grouping */}
        <div className="lg:col-span-1 space-y-6 order-2 lg:order-1">
          <div className={`p-4 rounded-2xl border ${darkMode ? 'glass-card-dark' : 'glass-card-light'}`}>
            <h3 className="font-bold text-[#D4AF37] mb-4 text-sm pb-2 border-b border-[#D4AF37]/10 flex items-center gap-1.5">
              <BookOpen className="w-4 h-4" />
              <span>تصنيفات الأدعية</span>
            </h3>

            <div className="space-y-6 max-h-[600px] overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-[#D4AF37]">
              {categoryGroups.map((group, gIdx) => (
                <div key={gIdx} className="space-y-1.5">
                  <h4 className="text-[11px] font-bold text-gray-400 tracking-wider mb-2">{group.title}</h4>
                  {group.items.map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => {
                        setSelectedCategory(cat.id);
                        setSearchQuery('');
                      }}
                      className={`w-full text-right px-3 py-2 rounded-xl text-xs flex flex-col gap-0.5 transition-all cursor-pointer border ${
                        selectedCategory === cat.id
                          ? 'bg-gradient-to-r from-emerald-900 to-[#D4AF37]/10 border-[#D4AF37] text-[#D4AF37]'
                          : darkMode
                            ? 'bg-emerald-950/10 border-transparent text-gray-300 hover:bg-emerald-950/40 hover:text-white'
                            : 'bg-white/50 border-transparent text-emerald-950 hover:bg-emerald-50'
                      }`}
                    >
                      <span className="font-bold">{cat.label}</span>
                      <span className="text-[9px] text-gray-500 font-normal">{cat.desc}</span>
                    </button>
                  ))}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Dua listing Grid / Reading Hub */}
        <div className="lg:col-span-3 order-1 lg:order-2 space-y-6">
          <div className="flex justify-between items-center bg-[#D4AF37]/10 p-4 rounded-xl border border-[#D4AF37]/20">
            <div className="text-xs font-bold text-[#D4AF37]">
              التصنيف الحالي: {allCategoriesList.find(c => c.id === selectedCategory)?.label || 'أدعيتي المفضلة'}
            </div>
            <div className="text-xs text-gray-400 font-mono">
              وجدنا {finalFilteredList.length} دعاءً مباركاً
            </div>
          </div>

          {finalFilteredList.length === 0 ? (
            <div className={`p-12 text-center rounded-2xl border ${darkMode ? 'glass-card-dark' : 'glass-card-light'}`}>
              <Info className="w-10 h-10 text-[#D4AF37] mx-auto mb-3 animate-pulse" />
              <h4 className="text-base font-bold mb-1">لا يوجد أدعية مضافة بعد</h4>
              <p className="text-xs text-gray-400">
                {selectedCategory === 'favorites' 
                  ? 'قم بحفظ أدعيتك المفضلة بالنقر على علامة القلب لتظهر هنا سريعاً.'
                  : 'جارٍ تعبئة هذا القسم في التحديث القريب مباركاً.'}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {finalFilteredList.map((item) => {
                const isFav = favorites.includes(item.id);

                return (
                  <motion.div
                    key={item.id}
                    layout
                    onClick={() => openReadingMode(item)}
                    className={`p-5 rounded-2xl border text-right relative overflow-hidden flex flex-col justify-between group cursor-pointer transition-all duration-300 ${
                      darkMode 
                        ? 'glass-card-dark border-[#D4AF37]/10 hover:border-[#D4AF37]' 
                        : 'glass-card-light border-emerald-100 hover:border-emerald-400 hover:shadow-md'
                    }`}
                  >
                    <div className="absolute top-0 right-0 p-4 font-quran text-3xl opacity-[0.03] text-[#D4AF37]">﷽</div>
                    
                    <div>
                      <div className="flex justify-between items-start gap-4 mb-3 pb-2 border-b border-gray-500/10">
                        <h4 className="text-xs font-bold text-[#D4AF37] flex items-center gap-1">
                          <BookMarked className="w-3.5 h-3.5 text-[#D4AF37]" />
                          <span>{item.title}</span>
                        </h4>
                        <span className="text-[10px] bg-[#D4AF37]/10 text-[#D4AF37] px-2 py-0.5 rounded-full font-bold">
                          {item.repeatCount ? `كرر ${item.repeatCount} مرات` : 'مرة واحدة'}
                        </span>
                      </div>

                      <p className="font-quran text-base sm:text-lg leading-relaxed text-emerald-950 dark:text-emerald-100 font-medium line-clamp-4">
                        {item.text}
                      </p>
                    </div>

                    <div className="mt-6 pt-3 border-t border-dashed border-gray-500/10 flex items-center justify-between">
                      <span className="text-[10px] text-gray-500 font-medium">المصدر: {item.source || 'الأثر المأثور'}</span>
                      <div className="flex gap-1.5">
                        {/* Copy */}
                        <button
                          onClick={(e) => triggerCopy(item.text, item.id, e)}
                          className="p-1.5 rounded-lg border border-[#D4AF37]/15 text-gray-400 hover:bg-[#D4AF37]/10 transition-colors cursor-pointer"
                          title="نسخ"
                        >
                          {copiedId === item.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>

                        {/* Share */}
                        <button
                          onClick={(e) => triggerShare(item, e)}
                          className="p-1.5 rounded-lg border border-[#D4AF37]/15 text-gray-400 hover:bg-[#D4AF37]/10 transition-colors cursor-pointer"
                          title="مشاركة"
                        >
                          {copiedId === `share-${item.id}` ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Share2 className="w-3.5 h-3.5" />}
                        </button>

                        {/* Favorite */}
                        <button
                          onClick={(e) => toggleFavorite(item.id, e)}
                          className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                            isFav 
                              ? 'bg-rose-500/10 text-rose-500 border-rose-500/30' 
                              : 'border-[#D4AF37]/15 text-gray-400 hover:bg-[#D4AF37]/10'
                          }`}
                          title="حفظ"
                        >
                          <Heart className="w-3.5 h-3.5 fill-current" />
                        </button>

                        {/* Beautiful Reading mode trigger */}
                        <button
                          onClick={() => openReadingMode(item)}
                          className="p-1.5 rounded-lg border border-[#D4AF37]/35 text-[#D4AF37] hover:bg-[#D4AF37]/20 transition-all cursor-pointer font-bold flex items-center gap-0.5 text-[10px]"
                        >
                          <Maximize2 className="w-3 h-3" />
                          <span>قراءة</span>
                        </button>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* READING MODE MODAL - Premium Interactive Experience */}
      <AnimatePresence>
        {activeReadingDua && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md"
          >
            <motion.div
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              className={`max-w-3xl w-full p-6 sm:p-8 rounded-3xl border text-right relative overflow-hidden shadow-2xl flex flex-col justify-between max-h-[90vh] ${
                readingTheme === 'emerald'
                  ? 'bg-gradient-to-br from-emerald-950 to-[#022c22] border-[#D4AF37] text-white'
                  : readingTheme === 'charcoal'
                    ? 'bg-gradient-to-br from-[#121212] to-[#1e1e1e] border-gray-600 text-gray-100'
                    : 'bg-[#faf6eb] border-amber-200 text-emerald-950'
              }`}
            >
              {/* Islamic background pattern watermark */}
              <div className="absolute inset-0 islamic-pattern opacity-[0.04] pointer-events-none" />

              {/* Modal Top Bar */}
              <div className="flex justify-between items-center border-b border-gray-500/15 pb-4 mb-6 relative z-10">
                <div>
                  <h4 className="text-sm font-bold text-[#D4AF37] mb-0.5">{activeReadingDua.title}</h4>
                  <p className="text-[10px] text-gray-400">نمط القراءة والتدبر التفاعلي</p>
                </div>

                <div className="flex items-center gap-3">
                  {/* Theme Selectors */}
                  <div className="flex gap-1.5 bg-gray-500/10 p-1 rounded-lg">
                    <button
                      onClick={() => setReadingTheme('emerald')}
                      className={`w-5 h-5 rounded-full bg-emerald-900 border ${readingTheme === 'emerald' ? 'border-[#D4AF37]' : 'border-transparent'}`}
                      title="مظهر أخضر"
                    />
                    <button
                      onClick={() => setReadingTheme('charcoal')}
                      className={`w-5 h-5 rounded-full bg-gray-800 border ${readingTheme === 'charcoal' ? 'border-white' : 'border-transparent'}`}
                      title="مظهر ليلي"
                    />
                    <button
                      onClick={() => setReadingTheme('parchment')}
                      className={`w-5 h-5 rounded-full bg-amber-50 border ${readingTheme === 'parchment' ? 'border-amber-600' : 'border-transparent'}`}
                      title="مظهر بيج ورق قديم"
                    />
                  </div>

                  {/* Font controls */}
                  <div className="flex items-center gap-1 bg-gray-500/10 rounded-lg p-0.5">
                    <button
                      onClick={() => setReadingFontSize(prev => Math.min(prev + 2, 40))}
                      className="p-1 text-gray-400 hover:text-white hover:bg-gray-500/20 rounded cursor-pointer"
                      title="تكبير الخط"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                    <span className="text-[10px] font-mono font-bold px-1 text-[#D4AF37]">{readingFontSize}px</span>
                    <button
                      onClick={() => setReadingFontSize(prev => Math.max(prev - 2, 16))}
                      className="p-1 text-gray-400 hover:text-white hover:bg-gray-500/20 rounded cursor-pointer"
                      title="تصغير الخط"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Scrollable Dua Body */}
              <div className="flex-1 overflow-y-auto my-4 py-2 relative z-10 text-center flex flex-col justify-center min-h-[180px]">
                <p 
                  className="font-quran leading-relaxed font-bold select-all transition-all mx-auto max-w-2xl px-2"
                  style={{ fontSize: `${readingFontSize}px` }}
                >
                  "{activeReadingDua.text}"
                </p>

                {activeReadingDua.explanation && (
                  <div className={`mt-6 p-4 rounded-xl border max-w-xl mx-auto text-right text-xs leading-relaxed ${
                    readingTheme === 'parchment' 
                      ? 'bg-amber-100/50 border-amber-200 text-emerald-900' 
                      : 'bg-emerald-950/40 border-[#D4AF37]/20 text-gray-300'
                  }`}>
                    <div className="font-bold text-[#D4AF37] mb-1">💡 فوائد ومأثور من شرح الدعاء:</div>
                    <p>{activeReadingDua.explanation}</p>
                  </div>
                )}
              </div>

              {/* Dynamic Repetitions Clicker */}
              <div className="my-6 text-center relative z-10">
                <div className="inline-flex flex-col items-center">
                  <div className="text-xs text-gray-400 mb-2">عدد التكرار المستهدف:</div>
                  <button
                    onClick={() => {
                      const target = activeReadingDua.repeatCount || 1;
                      if (readingCounter < target) {
                        setReadingCounter(prev => prev + 1);
                      }
                    }}
                    className={`relative w-28 h-28 rounded-full flex flex-col items-center justify-center border-3 transition-all duration-300 shadow-lg cursor-pointer ${
                      readingCounter >= (activeReadingDua.repeatCount || 1)
                        ? 'border-emerald-500 bg-emerald-500/10 text-emerald-400 scale-105'
                        : readingTheme === 'parchment'
                          ? 'border-emerald-950/20 hover:border-emerald-800 hover:bg-emerald-50 text-emerald-950'
                          : 'border-[#D4AF37]/30 hover:border-[#D4AF37] hover:bg-white/5 text-white'
                    }`}
                  >
                    {readingCounter >= (activeReadingDua.repeatCount || 1) ? (
                      <>
                        <Check className="w-8 h-8 mb-1 animate-bounce text-emerald-500" />
                        <span className="text-[11px] font-bold">تم الورد!</span>
                      </>
                    ) : (
                      <>
                        <span className="text-3xl font-mono font-bold text-[#D4AF37]">{readingCounter}</span>
                        <span className="text-[10px] text-gray-400">من أصل {activeReadingDua.repeatCount || 1}</span>
                        <span className="text-[10px] font-bold mt-1 text-[#D4AF37]/80 animate-pulse">انقر للتكرار</span>
                      </>
                    )}
                  </button>

                  {readingCounter > 0 && (
                    <button
                      onClick={() => setReadingCounter(0)}
                      className="mt-3 text-[10px] text-gray-400 hover:text-[#D4AF37] flex items-center gap-1 bg-gray-500/10 px-2 py-1 rounded-full cursor-pointer"
                    >
                      <RefreshCw className="w-2.5 h-2.5" />
                      <span>إعادة تصفير</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Modal Bottom control buttons */}
              <div className="border-t border-gray-500/15 pt-4 flex flex-col sm:flex-row justify-between items-center gap-3 relative z-10">
                <span className="text-xs text-gray-500">المصدر: {activeReadingDua.source || 'أدعية مأثورة'}</span>
                
                <div className="flex gap-2 w-full sm:w-auto">
                  {/* Share */}
                  <button
                    onClick={() => triggerShare(activeReadingDua)}
                    className="flex-1 sm:flex-none px-4 py-2 border border-gray-500/20 rounded-xl text-xs font-bold hover:bg-gray-500/10 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    <span>{copiedId === `share-${activeReadingDua.id}` ? 'تم نسخ نص المشاركة' : 'مشاركة'}</span>
                  </button>

                  {/* Copy */}
                  <button
                    onClick={() => triggerCopy(activeReadingDua.text, 'reading-copy')}
                    className="flex-1 sm:flex-none px-4 py-2 border border-[#D4AF37]/20 text-[#D4AF37] rounded-xl text-xs font-bold hover:bg-[#D4AF37]/10 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>{copiedId === 'reading-copy' ? 'تم نسخ النص' : 'نسخ النص'}</span>
                  </button>

                  {/* Favorite inside modal */}
                  <button
                    onClick={() => toggleFavorite(activeReadingDua.id)}
                    className={`px-3 py-2 border rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-1 ${
                      favorites.includes(activeReadingDua.id)
                        ? 'bg-rose-500/10 text-rose-500 border-rose-500/30'
                        : 'border-gray-500/20 text-gray-400 hover:bg-gray-500/10'
                    }`}
                  >
                    <Heart className="w-3.5 h-3.5 fill-current" />
                  </button>

                  {/* Close modal */}
                  <button
                    onClick={() => setActiveReadingDua(null)}
                    className="flex-1 sm:flex-none px-5 py-2 bg-gradient-to-r from-emerald-600 to-emerald-700 hover:opacity-95 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer text-center"
                  >
                    إغلاق المصحف
                  </button>
                </div>
              </div>

            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* RANDOM DUA POPUP MODAL */}
      <AnimatePresence>
        {showRandomModal && randomDua && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.95, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 15 }}
              className={`max-w-xl w-full p-6 sm:p-8 rounded-2xl border text-right relative overflow-hidden ${
                darkMode ? 'bg-[#0a1811] border-[#D4AF37]' : 'bg-white border-emerald-100 shadow-2xl'
              }`}
            >
              <div className="absolute top-0 right-0 p-4 font-quran text-4xl opacity-5 text-[#D4AF37]">﷽</div>
              
              <div className="text-center mb-6">
                <span className="inline-block p-2.5 rounded-full bg-amber-500/10 border border-[#D4AF37]/30 text-[#D4AF37] mb-2">
                  <Sparkles className="w-5 h-5" />
                </span>
                <h4 className="text-xs font-bold text-[#D4AF37]">{randomDua.title}</h4>
              </div>

              <p className="font-quran text-lg sm:text-xl leading-relaxed text-emerald-950 dark:text-emerald-100 font-semibold italic text-center mb-6">
                "{randomDua.text}"
              </p>

              <div className="text-center text-xs text-gray-500 mb-6">المصدر: {randomDua.source || 'أدعية مستجابة'}</div>

              <div className="flex gap-3 justify-center">
                <button
                  onClick={() => triggerCopy(randomDua.text, 'random-copy')}
                  className="px-4 py-2 border border-[#D4AF37]/20 text-[#D4AF37] rounded-lg text-xs font-bold hover:bg-[#D4AF37]/10 transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copiedId === 'random-copy' ? 'تم النسخ' : 'نسخ الدعاء'}</span>
                </button>
                <button
                  onClick={handleGenerateRandomDua}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer"
                >
                  دعاء آخر
                </button>
                <button
                  onClick={() => setShowRandomModal(false)}
                  className="px-4 py-2 border border-gray-500/20 text-gray-400 rounded-lg text-xs font-bold hover:bg-gray-500/10 transition-colors cursor-pointer"
                >
                  إغلاق
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
