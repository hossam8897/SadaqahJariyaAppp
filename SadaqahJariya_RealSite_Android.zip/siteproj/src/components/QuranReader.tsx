/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Book, 
  Play, 
  Pause, 
  ChevronLeft, 
  Search, 
  Bookmark, 
  Share2, 
  Copy, 
  Info, 
  BookOpen, 
  RotateCcw, 
  Check, 
  Volume2, 
  Eye, 
  ArrowRight,
  ListRestart
} from 'lucide-react';
import { surahsList, SurahMeta } from '../data/surahList';
import { recitersList } from '../data/islamicData';
import { copyToClipboard } from '../utils/helpers';

interface QuranReaderProps {
  darkMode: boolean;
  activeSurahId?: number | null; // loaded from search
  incrementQuranReadCount: () => void;
}

export default function QuranReader({ darkMode, activeSurahId, incrementQuranReadCount }: QuranReaderProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSurah, setSelectedSurah] = useState<SurahMeta | null>(null);
  const [loading, setLoading] = useState(false);
  const [ayahs, setAyahs] = useState<any[]>([]);
  const [translations, setTranslations] = useState<any[]>([]);
  const [tafsir, setTafsir] = useState<any[]>([]);
  
  // Settings & Toggles
  const [selectedReciter, setSelectedReciter] = useState(recitersList[0]);
  const [showTafsir, setShowTafsir] = useState(false);
  const [showTranslation, setShowTranslation] = useState(false);
  const [fontSize, setFontSize] = useState(24); // in px
  
  // Bookmarks & Continue Reading
  const [bookmarks, setBookmarks] = useState<any[]>([]);
  const [lastRead, setLastRead] = useState<any>(null);
  
  // Audio state
  const [isPlaying, setIsPlaying] = useState(false);
  const [activeAyahIndex, setActiveAyahIndex] = useState<number | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Status popups
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [bookmarkedIndex, setBookmarkedIndex] = useState<number | null>(null);

  // Sync bookmarks and continue reading
  useEffect(() => {
    const savedBookmarks = localStorage.getItem('sadaqah_quran_bookmarks');
    if (savedBookmarks) setBookmarks(JSON.parse(savedBookmarks));

    const savedLastRead = localStorage.getItem('sadaqah_quran_last_read');
    if (savedLastRead) setLastRead(JSON.parse(savedLastRead));
  }, []);

  // Handle outside loaded search results
  useEffect(() => {
    if (activeSurahId) {
      const match = surahsList.find(s => s.number === activeSurahId);
      if (match) handleSelectSurah(match);
    }
  }, [activeSurahId]);

  // Clean audio on component unmount
  useEffect(() => {
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, []);

  // Fetch Surah verses from AlQuran API
  const handleSelectSurah = async (surah: SurahMeta) => {
    setLoading(true);
    setSelectedSurah(surah);
    setAyahs([]);
    setTranslations([]);
    setTafsir([]);
    setIsPlaying(false);
    setActiveAyahIndex(null);
    if (audioRef.current) {
      audioRef.current.pause();
    }

    try {
      // Fetch Uthmani text & English translation & Jalalayn Tafsir in parallel safely
      const [textRes, transRes, tafsirRes] = await Promise.all([
        fetch(`https://api.alquran.cloud/v1/surah/${surah.number}`),
        fetch(`https://api.alquran.cloud/v1/surah/${surah.number}/en.sahih`),
        fetch(`https://api.alquran.cloud/v1/surah/${surah.number}/ar.jalalayn`)
      ]);

      const textData = await textRes.json();
      const transData = await transRes.json();
      const tafsirData = await tafsirRes.json();

      if (textData.code === 200) {
        setAyahs(textData.data.ayahs);
        incrementQuranReadCount(); // increment reading stats
      }
      if (transData.code === 200) {
        setTranslations(transData.data.ayahs);
      }
      if (tafsirData.code === 200) {
        setTafsir(tafsirData.data.ayahs);
      }

      // Save continue reading
      const lastReadInfo = {
        surahNumber: surah.number,
        surahName: surah.name,
        timestamp: new Date().toLocaleDateString('ar-SA')
      };
      localStorage.setItem('sadaqah_quran_last_read', JSON.stringify(lastReadInfo));
      setLastRead(lastReadInfo);

    } catch (e) {
      console.error("Error fetching Quran text:", e);
    } finally {
      setLoading(false);
    }
  };

  // Toggle bookmark
  const handleToggleBookmark = (ayahNumInSurah: number, text: string) => {
    if (!selectedSurah) return;
    const key = `${selectedSurah.number}-${ayahNumInSurah}`;
    
    let updated;
    const exists = bookmarks.some(b => b.key === key);
    if (exists) {
      updated = bookmarks.filter(b => b.key !== key);
    } else {
      updated = [...bookmarks, {
        key,
        surahNumber: selectedSurah.number,
        surahName: selectedSurah.name,
        verseNumber: ayahNumInSurah,
        text: text.substring(0, 60) + '...'
      }];
      setBookmarkedIndex(ayahNumInSurah);
      setTimeout(() => setBookmarkedIndex(null), 2000);
    }
    setBookmarks(updated);
    localStorage.setItem('sadaqah_quran_bookmarks', JSON.stringify(updated));
  };

  // Audio Playback Engine
  const playVerseAudio = (index: number) => {
    if (!selectedSurah || ayahs.length === 0) return;
    
    if (audioRef.current) {
      audioRef.current.pause();
    }

    const ayah = ayahs[index];
    // Formulating standard high-quality Alafasy / reciter audio URL verse by verse
    // Format: https://cdn.alquran.cloud/media/audio/ayah/{reciter}/{global_ayah_id}
    const globalAyahId = ayah.number; // absolute global number (1-6236)
    const audioUrl = `https://cdn.alquran.cloud/media/audio/ayah/${selectedReciter.identifier}/${globalAyahId}`;
    
    const audio = new Audio(audioUrl);
    audioRef.current = audio;
    setActiveAyahIndex(index);
    setIsPlaying(true);

    audio.play().catch(e => {
      console.error("Audio play error:", e);
      setIsPlaying(false);
    });

    audio.onended = () => {
      // Auto advance to next verse
      if (index + 1 < ayahs.length) {
        playVerseAudio(index + 1);
      } else {
        setIsPlaying(false);
        setActiveAyahIndex(null);
      }
    };
  };

  const togglePlaySurah = () => {
    if (isPlaying) {
      if (audioRef.current) audioRef.current.pause();
      setIsPlaying(false);
    } else {
      const startIndex = activeAyahIndex !== null ? activeAyahIndex : 0;
      playVerseAudio(startIndex);
    }
  };

  const handleCopyVerse = (text: string, reference: string, idx: number) => {
    const fullText = `قال الله تعالى: { ${text} } [${reference}]`;
    copyToClipboard(fullText).then(() => {
      setCopiedIndex(idx);
      setTimeout(() => setCopiedIndex(null), 2000);
    });
  };

  const filteredSurahs = surahsList.filter(s => 
    s.name.includes(searchTerm) || 
    s.englishName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.number.toString() === searchTerm
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-right">
      
      <AnimatePresence mode="wait">
        {!selectedSurah ? (
          /* Main Quran Dashboard / Directory */
          <motion.div
            key="directory"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            {/* Page Header */}
            <div className="text-center mb-10">
              <h2 className="font-quran text-3xl font-extrabold text-[#D4AF37] mb-2">المصحف الإلكتروني الكامل</h2>
              <p className={`text-sm ${darkMode ? 'text-gray-300' : 'text-emerald-900'} max-w-xl mx-auto`}>
                اقرأ واستمع لكتاب الله عز وجل بصوت مشاهير القراء، مع ميزة التفسير المباشر والمخطط اليومي لختمتك.
              </p>
            </div>

            {/* Quick Actions & Search */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              {/* Search box */}
              <div className="md:col-span-2 relative">
                <input
                  type="text"
                  placeholder="ابحث عن اسم السورة أو رقمها (مثال: الكهف أو 18)..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className={`w-full py-3.5 pr-12 pl-4 rounded-xl border focus:outline-none focus:ring-2 transition-all ${
                    darkMode 
                      ? 'bg-emerald-950/40 border-[#D4AF37]/20 text-white placeholder-emerald-300/40 focus:ring-[#D4AF37]/50' 
                      : 'bg-white border-emerald-100 text-emerald-950 focus:ring-emerald-500/50'
                  }`}
                />
                <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#D4AF37]" />
              </div>

              {/* Continue Reading Shortcut Card */}
              <div className={`p-4 rounded-xl border flex items-center justify-between gap-4 ${
                darkMode ? 'glass-card-dark' : 'glass-card-light'
              }`}>
                {lastRead ? (
                  <>
                    <div className="text-right">
                      <div className="text-[10px] text-gray-400">آخر ما قرأت:</div>
                      <div className="text-sm font-bold text-[#D4AF37]">سورة {lastRead.surahName}</div>
                      <div className="text-[9px] text-gray-400">تاريخ: {lastRead.timestamp}</div>
                    </div>
                    <button
                      onClick={() => {
                        const target = surahsList.find(s => s.number === lastRead.surahNumber);
                        if (target) handleSelectSurah(target);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold cursor-pointer flex items-center gap-1"
                    >
                      <span>متابعة</span>
                      <ChevronLeft className="w-3 h-3" />
                    </button>
                  </>
                ) : (
                  <div className="text-gray-400 text-xs text-center w-full flex items-center justify-center gap-2">
                    <BookOpen className="w-4 h-4 text-emerald-500" />
                    <span>ابدأ ختمتك اليومية وسيتم حفظها هنا</span>
                  </div>
                )}
              </div>
            </div>

            {/* Bookmarks Section */}
            {bookmarks.length > 0 && (
              <div className="mb-8">
                <h3 className={`text-sm font-bold mb-3 flex items-center gap-1.5 ${darkMode ? 'text-[#D4AF37]' : 'text-emerald-950'}`}>
                  <Bookmark className="w-4 h-4 text-[#D4AF37]" />
                  <span>العلامات المرجعية المحفوظة ({bookmarks.length})</span>
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                  {bookmarks.map((b, idx) => (
                    <div
                      key={idx}
                      className={`p-3.5 rounded-xl border text-right flex items-center justify-between gap-3 ${
                        darkMode ? 'glass-card-dark' : 'glass-card-light'
                      }`}
                    >
                      <div className="overflow-hidden">
                        <div className="text-xs font-bold text-[#D4AF37]">سورة {b.surahName} - الآية {b.verseNumber}</div>
                        <div className="text-[10px] text-gray-400 truncate mt-0.5">{b.text}</div>
                      </div>
                      <div className="flex gap-1.5 shrink-0">
                        <button
                          onClick={() => {
                            const target = surahsList.find(s => s.number === b.surahNumber);
                            if (target) {
                              handleSelectSurah(target).then(() => {
                                // Scroll to specific verse after brief timeout
                                setTimeout(() => {
                                  const el = document.getElementById(`verse-${b.verseNumber}`);
                                  if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                                }, 1500);
                              });
                            }
                          }}
                          className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-500 hover:bg-emerald-500/20 text-xs font-semibold cursor-pointer"
                          title="عرض الآية"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            const filtered = bookmarks.filter(bk => bk.key !== b.key);
                            setBookmarks(filtered);
                            localStorage.setItem('sadaqah_quran_bookmarks', JSON.stringify(filtered));
                          }}
                          className="p-1.5 rounded-lg bg-red-500/10 text-red-500 hover:bg-red-500/20 text-xs font-semibold cursor-pointer"
                          title="حذف"
                        >
                          حذف
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Surah List Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {filteredSurahs.map((surah) => (
                <motion.button
                  key={surah.number}
                  whileHover={{ scale: 1.02, y: -2 }}
                  onClick={() => handleSelectSurah(surah)}
                  className={`p-4 rounded-xl border text-right cursor-pointer flex flex-col justify-between transition-all duration-200 min-h-32 relative group overflow-hidden ${
                    darkMode 
                      ? 'glass-card-dark hover:border-[#D4AF37]' 
                      : 'glass-card-light hover:border-emerald-300 hover:shadow-md text-emerald-950'
                  }`}
                  id={`surah-card-${surah.number}`}
                >
                  {/* Surah Number Watermark in background */}
                  <div className="absolute -bottom-2 -left-2 text-6xl font-bold font-mono opacity-[0.03] text-[#D4AF37] group-hover:scale-110 transition-transform duration-300">
                    {surah.number}
                  </div>
                  
                  <div className="flex items-center justify-between w-full">
                    <span className="w-6 h-6 rounded-full border border-[#D4AF37]/30 flex items-center justify-center font-mono text-[10px] text-[#D4AF37] font-bold">
                      {surah.number}
                    </span>
                    <span className={`text-[9px] px-2 py-0.5 rounded-full font-bold ${
                      surah.revelationType === 'Meccan' 
                        ? 'bg-amber-500/10 text-amber-500 border border-amber-500/20' 
                        : 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20'
                    }`}>
                      {surah.revelationType === 'Meccan' ? 'مكية' : 'مدنية'}
                    </span>
                  </div>

                  <div className="mt-4">
                    <div className={`text-base font-bold ${darkMode ? 'text-white' : 'text-emerald-950'} font-quran`}>
                      سورة {surah.name}
                    </div>
                    <div className="text-[10px] text-gray-400 mt-1 flex justify-between">
                      <span>{surah.englishName}</span>
                      <span className="font-semibold">{surah.numberOfAyahs} آية</span>
                    </div>
                  </div>
                </motion.button>
              ))}
            </div>
          </motion.div>
        ) : (
          /* Active Surah Reader Panel */
          <motion.div
            key="reader"
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            className={`p-6 sm:p-8 rounded-2xl border ${
              darkMode ? 'glass-emerald-dark text-white border-[#D4AF37]/30' : 'glass-card-light text-emerald-950 shadow-lg'
            }`}
          >
            {/* Header / Surah Meta Info */}
            <div className="flex flex-col sm:flex-row justify-between items-center gap-4 pb-6 mb-6 border-b border-[#D4AF37]/20">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setSelectedSurah(null)}
                  className="p-2.5 rounded-lg border border-emerald-500/10 hover:bg-[#D4AF37]/10 transition-colors cursor-pointer"
                  title="رجوع للقائمة"
                >
                  <ArrowRight className="w-5 h-5 text-[#D4AF37]" />
                </button>
                <div>
                  <h2 className="font-quran text-2xl font-bold text-[#D4AF37]">سورة {selectedSurah.name}</h2>
                  <p className="text-xs text-gray-400">
                    {selectedSurah.englishName} | آياتها: {selectedSurah.numberOfAyahs} | نزولها: {selectedSurah.revelationType === 'Meccan' ? 'مكية' : 'مدنية'}
                  </p>
                </div>
              </div>

              {/* Reader Settings Panel */}
              <div className="flex flex-wrap items-center gap-3 justify-center">
                {/* Reciter Select Dropdown */}
                <div className="flex items-center gap-1.5">
                  <span className="text-xs text-gray-400 font-medium whitespace-nowrap">القارئ:</span>
                  <select
                    value={selectedReciter.id}
                    onChange={(e) => {
                      const rec = recitersList.find(r => r.id === e.target.value);
                      if (rec) {
                        setSelectedReciter(rec);
                        setIsPlaying(false);
                        setActiveAyahIndex(null);
                      }
                    }}
                    className={`text-xs px-2.5 py-1.5 rounded-lg border focus:outline-none ${
                      darkMode ? 'bg-emerald-950 border-[#D4AF37]/20 text-[#D4AF37]' : 'bg-emerald-50 border-emerald-100 text-emerald-950'
                    }`}
                  >
                    {recitersList.map((r) => (
                      <option key={r.id} value={r.id}>{r.arabicName}</option>
                    ))}
                  </select>
                </div>

                {/* Font Size controls */}
                <div className="flex items-center gap-1.5">
                  <span className="text-xs text-gray-400">حجم الخط:</span>
                  <button onClick={() => setFontSize(Math.max(16, fontSize - 2))} className="px-2 py-1 rounded bg-emerald-500/10 hover:bg-[#D4AF37]/20 text-xs font-bold cursor-pointer">-</button>
                  <span className="text-xs font-bold font-mono px-1">{fontSize}</span>
                  <button onClick={() => setFontSize(Math.min(38, fontSize + 2))} className="px-2 py-1 rounded bg-emerald-500/10 hover:bg-[#D4AF37]/20 text-xs font-bold cursor-pointer">+</button>
                </div>

                {/* Tafsir Toggle */}
                <button
                  onClick={() => setShowTafsir(!showTafsir)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors cursor-pointer flex items-center gap-1 ${
                    showTafsir 
                      ? 'bg-amber-500/10 text-[#D4AF37] border-[#D4AF37]' 
                      : 'border-[#D4AF37]/20 text-gray-400 hover:text-white'
                  }`}
                >
                  <BookOpen className="w-3.5 h-3.5" />
                  <span>تفسير الجلالين</span>
                </button>

                {/* Translation Toggle */}
                <button
                  onClick={() => setShowTranslation(!showTranslation)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors cursor-pointer flex items-center gap-1 ${
                    showTranslation 
                      ? 'bg-amber-500/10 text-[#D4AF37] border-[#D4AF37]' 
                      : 'border-[#D4AF37]/20 text-gray-400 hover:text-white'
                  }`}
                >
                  <Info className="w-3.5 h-3.5" />
                  <span>الترجمة الإنجليزية</span>
                </button>

                {/* Audio Play/Pause Trigger */}
                <button
                  onClick={togglePlaySurah}
                  className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                  <span>{isPlaying ? 'إيقاف مؤقت' : 'تشغيل السورة'}</span>
                </button>
              </div>
            </div>

            {/* Bismillah Banner (Show on all Surahs except At-Tawbah #9, and strip Bismillah from first verse if it exists in the fetched text to avoid double Bismillah) */}
            {selectedSurah.number !== 9 && (
              <div className="text-center my-6">
                <span className="font-quran text-2xl text-[#D4AF37] block">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</span>
              </div>
            )}

            {/* Verses Container */}
            <div className="space-y-6 mt-8">
              {loading ? (
                <div className="text-center py-10">
                  <div className="inline-block w-8 h-8 border-4 border-[#D4AF37] border-t-transparent rounded-full animate-spin"></div>
                  <p className="text-xs text-gray-400 mt-2">جاري تنزيل آيات الذكر الحكيم وتفسيرها...</p>
                </div>
              ) : (
                ayahs.map((ayah, idx) => {
                  const isVerseActive = activeAyahIndex === idx;
                  const hasBookmark = bookmarks.some(b => b.key === `${selectedSurah.number}-${ayah.numberInSurah}`);
                  
                  // Strip Bismillah from the first verse text if it starts with it and it's not Fatiha, to avoid redundant display
                  let verseText = ayah.text;
                  if (selectedSurah.number !== 1 && idx === 0 && verseText.startsWith("بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ")) {
                    verseText = verseText.replace("بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ", "").trim();
                  }

                  return (
                    <div
                      key={ayah.numberInSurah}
                      id={`verse-${ayah.numberInSurah}`}
                      className={`p-4 sm:p-5 rounded-xl transition-all duration-300 border text-right relative group ${
                        isVerseActive 
                          ? 'bg-[#0f241a] border-[#D4AF37] shadow-lg' 
                          : 'border-[#D4AF37]/5 hover:bg-emerald-500/5'
                      }`}
                    >
                      {/* Verse Text (Beautiful Amiri Quran typography) */}
                      <p 
                        className="font-quran leading-loose text-right text-emerald-950 dark:text-emerald-100 font-semibold"
                        style={{ fontSize: `${fontSize}px` }}
                      >
                        {verseText}
                        <span className="inline-flex items-center justify-center w-8 h-8 rounded-full border border-[#D4AF37]/30 text-xs font-bold text-[#D4AF37] font-mono mr-3">
                          {ayah.numberInSurah}
                        </span>
                      </p>

                      {/* English Translation */}
                      {showTranslation && translations[idx] && (
                        <p className="text-sm text-gray-400 font-sans italic mt-3 border-r-2 border-dashed border-gray-600 pr-3">
                          {translations[idx].text}
                        </p>
                      )}

                      {/* Arabic Tafsir Jalalayn */}
                      {showTafsir && tafsir[idx] && (
                        <div className="text-xs text-[#D4AF37] bg-amber-500/5 p-3 rounded-lg border border-[#D4AF37]/10 mt-3 font-sans leading-relaxed">
                          <span className="font-bold underline ml-1">التفسير (الجلالين):</span>
                          {tafsir[idx].text}
                        </div>
                      )}

                      {/* Verse Action bar (plays, copies, bookmarks, shares) */}
                      <div className="mt-4 pt-3 border-t border-dashed border-[#D4AF37]/10 flex items-center justify-between">
                        <div className="flex gap-2">
                          {/* Play Verse */}
                          <button
                            onClick={() => playVerseAudio(idx)}
                            className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                              isVerseActive 
                                ? 'bg-[#D4AF37] text-[#0f241a] border-[#D4AF37]' 
                                : 'border-[#D4AF37]/20 text-[#D4AF37] hover:bg-[#D4AF37]/10'
                            }`}
                            title="استمع للآية"
                          >
                            <Volume2 className="w-4 h-4" />
                          </button>

                          {/* Copy Verse */}
                          <button
                            onClick={() => handleCopyVerse(ayah.text, `سورة ${selectedSurah.name} - آية ${ayah.numberInSurah}`, idx)}
                            className="p-1.5 rounded-lg border border-[#D4AF37]/20 text-[#D4AF37] hover:bg-[#D4AF37]/10 transition-colors cursor-pointer"
                            title="نسخ الآية"
                          >
                            {copiedIndex === idx ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                          </button>

                          {/* Bookmark Verse */}
                          <button
                            onClick={() => handleToggleBookmark(ayah.numberInSurah, ayah.text)}
                            className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                              hasBookmark 
                                ? 'bg-amber-500/10 text-amber-500 border-amber-500/40' 
                                : 'border-[#D4AF37]/20 text-[#D4AF37] hover:bg-[#D4AF37]/10'
                            }`}
                            title="حفظ الآية كعلامة مرجعية"
                          >
                            <Bookmark className="w-4 h-4" />
                          </button>
                        </div>

                        {/* User Notification Badge for action */}
                        {bookmarkedIndex === ayah.numberInSurah && (
                          <span className="text-[10px] text-amber-400 font-semibold">تمت الإضافة للعلامات المرجعية</span>
                        )}
                        {copiedIndex === idx && (
                          <span className="text-[10px] text-emerald-400 font-semibold">تم نسخ الآية للحافظة</span>
                        )}
                      </div>

                    </div>
                  );
                })
              )}
            </div>

          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
