/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Music, 
  SkipBack, 
  SkipForward, 
  Repeat, 
  ListMusic, 
  BookOpen, 
  Award,
  ChevronLeft
} from 'lucide-react';
import { recitersList } from '../data/islamicData';
import { getReciters } from '../utils/firebase';

interface AudioTrack {
  id: string;
  title: string;
  category: 'quran' | 'lecture';
  narrator: string;
  url: string; // MP3 streaming URL
  duration?: string;
}

export default function AudioLibrary({ darkMode }: { darkMode: boolean }) {
  const [reciters, setReciters] = useState<any[]>(recitersList);
  const [activeTrack, setActiveTrack] = useState<AudioTrack | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [activeReciter, setActiveReciter] = useState(recitersList[0]);

  useEffect(() => {
    getReciters().then(data => {
      if (data && data.length > 0) {
        setReciters(data);
        setActiveReciter(data[0]);
      }
    });
  }, []);

  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.8);
  const [isMuted, setIsMuted] = useState(false);
  
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // List of high-fidelity pre-compiled streaming audio tracks (free, public domain / open library resources)
  const tracksList: AudioTrack[] = [
    {
      id: 'a_q1',
      title: 'سورة الفاتحة الكريمة',
      category: 'quran',
      narrator: 'الشيخ مشاري بن راشد العفاسي',
      url: 'https://server8.mp3quran.net/afs/001.mp3',
      duration: '01:30'
    },
    {
      id: 'a_q2',
      title: 'سورة الكهف الكريمة',
      category: 'quran',
      narrator: 'الشيخ مشاري بن راشد العفاسي',
      url: 'https://server8.mp3quran.net/afs/018.mp3',
      duration: '28:15'
    },
    {
      id: 'a_q3',
      title: 'سورة يس الكريمة',
      category: 'quran',
      narrator: 'الشيخ مشاري بن راشد العفاسي',
      url: 'https://server8.mp3quran.net/afs/036.mp3',
      duration: '14:20'
    },
    {
      id: 'a_q4',
      title: 'سورة الملك المنجية',
      category: 'quran',
      narrator: 'الشيخ مشاري بن راشد العفاسي',
      url: 'https://server8.mp3quran.net/afs/067.mp3',
      duration: '06:10'
    },
    {
      id: 'a_l1',
      title: 'محاضرة: عظيم فضل الصدقة الجارية وأثرها بعد الوفاة',
      category: 'lecture',
      narrator: 'مواعظ وعبر إسلامية هادفة',
      url: 'https://archive.org/download/IslamicLecturesArabic/sadaka_jariyah_fadel.mp3', // simulated archive.org source link
      duration: '10:45'
    },
    {
      id: 'a_l2',
      title: 'محاضرة: كيف نبر بآبائنا وأمهاتنا الراحلين عن دنيانا؟',
      category: 'lecture',
      narrator: 'الشيخ صالح المغامسي',
      url: 'https://archive.org/download/IslamicLecturesArabic/parents_after_death.mp3',
      duration: '15:30'
    }
  ];

  useEffect(() => {
    // If user changes the selected global reciter, rebuild dynamic Quran MP3 urls!
    // Example: Alafasy is "afs", Ghamdi is "ghm", Shuraim is "shur", etc. in mp3quran servers.
    // Let's map reciters to their server codes for the Quran tracks
    const reciterCodes: Record<string, string> = {
      alafasy: 'afs',
      ghamdi: 'ghm',
      shuraim: 'shur',
      sudais: 'sds',
      abdulbasit: 'basit',
      minshawi: 'minsh'
    };

    const serverCode = reciterCodes[activeReciter.id] || 'afs';
    
    // Update active track url if it's a Quran track
    if (activeTrack && activeTrack.category === 'quran') {
      const surahNumStr = activeTrack.id === 'a_q1' ? '001' : activeTrack.id === 'a_q2' ? '018' : activeTrack.id === 'a_q3' ? '036' : '067';
      const updatedUrl = `https://server8.mp3quran.net/${serverCode}/${surahNumStr}.mp3`;
      
      const wasPlaying = isPlaying;
      handlePlayTrack({ ...activeTrack, url: updatedUrl, narrator: `الشيخ ${activeReciter.arabicName}` });
      if (!wasPlaying) {
        setTimeout(() => {
          if (audioRef.current) audioRef.current.pause();
          setIsPlaying(false);
        }, 100);
      }
    }
  }, [activeReciter]);

  const handlePlayTrack = (track: AudioTrack) => {
    if (audioRef.current) {
      audioRef.current.pause();
    }

    setActiveTrack(track);
    setIsPlaying(true);
    setCurrentTime(0);

    const audio = new Audio(track.url);
    audioRef.current = audio;
    audio.volume = isMuted ? 0 : volume;

    // Listeners
    audio.addEventListener('timeupdate', () => {
      setCurrentTime(audio.currentTime);
    });

    audio.addEventListener('loadedmetadata', () => {
      setDuration(audio.duration);
    });

    audio.addEventListener('ended', () => {
      setIsPlaying(false);
    });

    audio.play().catch(e => {
      console.warn("Dynamic audio play error (likely sandbox block, continuing gracefully):", e);
      setIsPlaying(false);
    });
  };

  const togglePlayPause = () => {
    if (!audioRef.current && activeTrack) {
      handlePlayTrack(activeTrack);
      return;
    }
    
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
        setIsPlaying(false);
      } else {
        audioRef.current.play().catch(() => {});
        setIsPlaying(true);
      }
    }
  };

  const handleTimelineChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = Number(e.target.value);
    setCurrentTime(time);
    if (audioRef.current) {
      audioRef.current.currentTime = time;
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const vol = Number(e.target.value);
    setVolume(vol);
    setIsMuted(vol === 0);
    if (audioRef.current) {
      audioRef.current.volume = vol;
    }
  };

  const toggleMute = () => {
    const nextMute = !isMuted;
    setIsMuted(nextMute);
    if (audioRef.current) {
      audioRef.current.volume = nextMute ? 0 : volume;
    }
  };

  // Helper to format seconds to standard MM:SS
  const formatTime = (timeInSecs: number) => {
    if (isNaN(timeInSecs)) return '00:00';
    const mins = Math.floor(timeInSecs / 60);
    const secs = Math.floor(timeInSecs % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-right">
      
      {/* Header */}
      <div className="text-center mb-10">
        <h2 className="font-quran text-3xl font-extrabold text-[#D4AF37] mb-2">المكتبة الصوتية الإسلامية</h2>
        <p className={`text-sm ${darkMode ? 'text-gray-300' : 'text-emerald-900'} max-w-xl mx-auto`}>
          استمع لسور مباركة من القرآن الكريم بصوت القارئ المفضل لديك، ومجموعة من المحاضرات الوعظية المليئة بالإيمان والسكينة.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Playlists and Track options columns (Left side) */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Reciter quick selectors */}
          <div className={`p-5 rounded-2xl border text-right ${
            darkMode ? 'glass-card-dark' : 'glass-card-light'
          }`}>
            <label className="text-xs font-bold text-gray-400 block mb-3">اختر القارئ لتحديث بث السور:</label>
            <div className="flex flex-wrap gap-2">
              {reciters.map((rec) => (
                <button
                  key={rec.id}
                  onClick={() => setActiveReciter(rec)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all border cursor-pointer ${
                    activeReciter.id === rec.id
                      ? 'bg-[#D4AF37]/10 text-[#D4AF37] border-[#D4AF37]'
                      : darkMode ? 'bg-emerald-950/20 border-transparent text-gray-300' : 'bg-slate-50 border-transparent text-emerald-950'
                  }`}
                >
                  {rec.arabicName}
                </button>
              ))}
            </div>
          </div>

          {/* Sura tracks and Lecture tracks listings */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Sura Tracks */}
            <div className={`p-5 rounded-2xl border ${
              darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950'
            }`}>
              <h3 className="text-sm font-bold text-[#D4AF37] border-b border-[#D4AF37]/10 pb-2.5 mb-4 flex items-center gap-2">
                <BookOpen className="w-4.5 h-4.5" />
                <span>القرآن المرتل والمسموع</span>
              </h3>

              <div className="space-y-2">
                {tracksList.filter(t => t.category === 'quran').map((track) => {
                  const isCurrent = activeTrack?.id === track.id;
                  
                  // Re-format name of narrator based on active selection dynamically
                  const finalTrackName = track.title;
                  const finalNarrator = `الشيخ ${activeReciter.arabicName}`;
                  const dynamicUrl = track.url; // updated dynamically in state
                  
                  return (
                    <button
                      key={track.id}
                      onClick={() => handlePlayTrack({ ...track, narrator: finalNarrator })}
                      className={`w-full text-right p-3 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                        isCurrent 
                          ? 'bg-emerald-500/10 border-[#D4AF37] text-[#D4AF37]' 
                          : darkMode ? 'bg-emerald-950/20 border-transparent text-gray-300 hover:bg-[#060c09]' : 'bg-slate-50 border-transparent text-emerald-950 hover:bg-slate-100'
                      }`}
                    >
                      <div className="overflow-hidden">
                        <div className="text-xs font-bold truncate">{finalTrackName}</div>
                        <div className="text-[10px] text-gray-400 mt-1">{finalNarrator}</div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <span className="text-[10px] text-gray-500 font-mono">{track.duration}</span>
                        <span className="p-1.5 rounded-full bg-emerald-500/10 text-[#D4AF37]">
                          {isCurrent && isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Lecture Tracks */}
            <div className={`p-5 rounded-2xl border ${
              darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950'
            }`}>
              <h3 className="text-sm font-bold text-[#D4AF37] border-b border-[#D4AF37]/10 pb-2.5 mb-4 flex items-center gap-2">
                <Award className="w-4.5 h-4.5" />
                <span>المواعظ والمحاضرات الإسلامية</span>
              </h3>

              <div className="space-y-2">
                {tracksList.filter(t => t.category === 'lecture').map((track) => {
                  const isCurrent = activeTrack?.id === track.id;
                  return (
                    <button
                      key={track.id}
                      onClick={() => handlePlayTrack(track)}
                      className={`w-full text-right p-3 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                        isCurrent 
                          ? 'bg-emerald-500/10 border-[#D4AF37] text-[#D4AF37]' 
                          : darkMode ? 'bg-emerald-950/20 border-transparent text-gray-300 hover:bg-[#060c09]' : 'bg-slate-50 border-transparent text-emerald-950 hover:bg-slate-100'
                      }`}
                    >
                      <div className="overflow-hidden">
                        <div className="text-xs font-bold truncate">{track.title}</div>
                        <div className="text-[10px] text-gray-400 mt-1">{track.narrator}</div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <span className="text-[10px] text-gray-500 font-mono">{track.duration}</span>
                        <span className="p-1.5 rounded-full bg-emerald-500/10 text-[#D4AF37]">
                          {isCurrent && isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

          </div>

        </div>

        {/* Dynamic media player view (Right side) */}
        <div className="lg:col-span-1">
          
          <div className={`p-6 rounded-2xl border text-center h-full flex flex-col justify-between items-center relative overflow-hidden ${
            darkMode ? 'glass-card-dark text-white' : 'glass-card-light text-emerald-950'
          }`}>
            <div className="absolute inset-0 islamic-pattern opacity-[0.03] pointer-events-none" />

            <div className="w-full">
              <h3 className={`text-sm font-bold flex items-center gap-1.5 justify-center mb-1 ${darkMode ? 'text-[#D4AF37]' : 'text-emerald-950'}`}>
                <Music className="w-4.5 h-4.5 text-[#D4AF37]" />
                <span>مشغّل الميديا المباركة</span>
              </h3>
              <p className="text-[10px] text-gray-400">استمع بأعلى جودة مع نظام التحكم المدمج</p>
            </div>

            {/* Spinning Golden CD/Visualizer representation */}
            <div className="relative w-40 h-40 flex items-center justify-center my-6">
              <div className={`absolute inset-0 rounded-full border-2 border-dashed border-[#D4AF37]/30 flex items-center justify-center ${isPlaying ? 'animate-spin' : ''}`} style={{ animationDuration: '24s' }}>
                <div className="w-32 h-32 rounded-full border border-[#D4AF37]/10" />
              </div>
              <div className="w-28 h-28 rounded-full bg-emerald-950 border border-[#D4AF37]/40 flex flex-col items-center justify-center relative shadow-xl z-10">
                <Music className={`w-8 h-8 text-[#D4AF37] ${isPlaying ? 'animate-bounce' : ''}`} />
                <span className="text-[8px] text-gray-400 mt-1">SADAQAH AUDIO</span>
              </div>
            </div>

            {activeTrack ? (
              <div className="w-full space-y-4">
                
                {/* Track titles */}
                <div>
                  <h4 className={`text-sm font-bold truncate max-w-xs mx-auto ${darkMode ? 'text-white' : 'text-emerald-950'}`}>{activeTrack.title}</h4>
                  <p className="text-xs text-gray-400 mt-1">{activeTrack.narrator}</p>
                </div>

                {/* Progress bar timeline slider */}
                <div className="space-y-1">
                  <input
                    type="range"
                    min="0"
                    max={duration || 100}
                    value={currentTime}
                    onChange={handleTimelineChange}
                    className="w-full accent-[#D4AF37] h-1 bg-gray-600 rounded-lg appearance-none cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-gray-400 font-mono">
                    <span>{formatTime(currentTime)}</span>
                    <span>{formatTime(duration)}</span>
                  </div>
                </div>

                {/* Main Player controls buttons */}
                <div className="flex items-center justify-center gap-4">
                  <button
                    onClick={togglePlayPause}
                    className="w-14 h-14 rounded-full bg-[#D4AF37] hover:bg-yellow-400 text-[#09150f] flex items-center justify-center font-bold shadow-lg transition-transform active:scale-95 cursor-pointer"
                  >
                    {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 translate-x-[-1px]" />}
                  </button>
                </div>

                {/* Volume slider control */}
                <div className="flex items-center justify-center gap-3 border-t border-[#D4AF37]/10 pt-3">
                  <button
                    onClick={toggleMute}
                    className="text-[#D4AF37] hover:text-yellow-400 transition-colors"
                  >
                    {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                  </button>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.01"
                    value={isMuted ? 0 : volume}
                    onChange={handleVolumeChange}
                    className="w-20 accent-[#D4AF37] h-1 bg-gray-600 rounded-lg appearance-none cursor-pointer"
                  />
                </div>

              </div>
            ) : (
              <div className="text-center w-full">
                <div className="text-xs text-gray-400 bg-emerald-500/5 p-4 rounded-xl border border-dashed border-[#D4AF37]/10">
                  انقر على أي سورة أو درس وعظي من القائمة لتشغيله في الخلفية فوراً.
                </div>
              </div>
            )}

          </div>

        </div>

      </div>

    </div>
  );
}
